import React, { useState, useEffect } from 'react';
import { Bug, Search, Filter, RotateCw, Sparkles, CheckCircle2, ArrowRight, FileCode, Shield } from 'lucide-react';
import { api } from '../api/client';
import { Issue, Severity } from '../types';
import { SeverityBadge } from '../components/SeverityBadge';
import { CategoryBadge } from '../components/CategoryBadge';

interface IssuesPageProps {
  initialSeverityFilter?: string;
  onNavigateToIssue: (issueId: string) => void;
}

export const IssuesPage: React.FC<IssuesPageProps> = ({
  initialSeverityFilter,
  onNavigateToIssue
}) => {
  const [issues, setIssues] = useState<Issue[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [severity, setSeverity] = useState<string>(initialSeverityFilter || 'ALL');
  const [category, setCategory] = useState<string>('ALL');
  const [scanner, setScanner] = useState<string>('ALL');
  const [status, setStatus] = useState<string>('ALL');
  const [search, setSearch] = useState<string>('');
  const [sortBy, setSortBy] = useState<string>('severity');

  const fetchIssues = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await api.getIssues({
        severity: severity !== 'ALL' ? severity : undefined,
        category: category !== 'ALL' ? category : undefined,
        scanner: scanner !== 'ALL' ? scanner : undefined,
        status: status !== 'ALL' ? status : undefined,
        search: search.trim() || undefined,
        sort_by: sortBy
      });
      setIssues(res.issues);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch issues');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchIssues();
  }, [severity, category, scanner, status, sortBy]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchIssues();
  };

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-5 font-sans w-full overflow-hidden">
      {/* Page Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <Bug className="w-5 h-5 text-amber-400" />
            <h1 className="text-xl sm:text-2xl font-bold text-zinc-100 font-mono tracking-tight">
              Vulnerability Explorer
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-zinc-400 mt-1">
            Triaged security findings, automated fixes, and regression test suites across repositories
          </p>
        </div>
        <button
          onClick={fetchIssues}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 text-xs font-mono rounded-md transition-colors cursor-pointer"
        >
          <RotateCw className="w-3.5 h-3.5" />
          <span>Refresh</span>
        </button>
      </div>

      {/* Filter Controls Bar */}
      <div className="p-4 bg-[#0c1017] border border-zinc-800/90 rounded-xl space-y-3 shadow-md">
        <form onSubmit={handleSearchSubmit} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by title, file path, description, or CWE ID..."
              className="w-full pl-9 pr-4 py-2 bg-zinc-950 border border-zinc-800 rounded-md text-xs font-mono text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-zinc-700"
            />
          </div>
          <button
            type="submit"
            className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold rounded-md transition-colors cursor-pointer shrink-0"
          >
            Search
          </button>
        </form>

        <div className="flex flex-wrap items-center gap-2.5 pt-2 border-t border-zinc-800/80 font-mono text-xs">
          {/* Severity */}
          <select
            value={severity}
            onChange={(e) => setSeverity(e.target.value)}
            className="px-2.5 py-1.5 bg-zinc-950 border border-zinc-800 rounded-md text-zinc-300 focus:outline-none focus:border-zinc-700 cursor-pointer"
          >
            <option value="ALL">All Severities</option>
            <option value="CRITICAL">Critical</option>
            <option value="HIGH">High</option>
            <option value="MEDIUM">Medium</option>
            <option value="LOW">Low</option>
            <option value="INFO">Info</option>
          </select>

          {/* Category */}
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="px-2.5 py-1.5 bg-zinc-950 border border-zinc-800 rounded-md text-zinc-300 focus:outline-none focus:border-zinc-700 cursor-pointer"
          >
            <option value="ALL">All Categories</option>
            <option value="Injection">Injection</option>
            <option value="Secrets">Secrets</option>
            <option value="Authentication">Authentication</option>
            <option value="Cryptography">Cryptography</option>
            <option value="Dependencies">Dependencies</option>
            <option value="Code Quality">Code Quality</option>
          </select>

          {/* Scanner */}
          <select
            value={scanner}
            onChange={(e) => setScanner(e.target.value)}
            className="px-2.5 py-1.5 bg-zinc-950 border border-zinc-800 rounded-md text-zinc-300 focus:outline-none focus:border-zinc-700 cursor-pointer"
          >
            <option value="ALL">All Scanners</option>
            <option value="Semgrep">Semgrep</option>
            <option value="Gitleaks">Gitleaks</option>
            <option value="Bandit">Bandit</option>
            <option value="ESLint Security">ESLint</option>
            <option value="DependencyCheck">DependencyCheck</option>
          </select>

          {/* Status */}
          <select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            className="px-2.5 py-1.5 bg-zinc-950 border border-zinc-800 rounded-md text-zinc-300 focus:outline-none focus:border-zinc-700 cursor-pointer"
          >
            <option value="ALL">All Statuses</option>
            <option value="OPEN">Open</option>
            <option value="CONFIRMED">Confirmed</option>
            <option value="RESOLVED">Resolved</option>
            <option value="FALSE_POSITIVE">False Positive</option>
          </select>

          {/* Sort */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="px-2.5 py-1.5 bg-zinc-950 border border-zinc-800 rounded-md text-zinc-300 sm:ml-auto focus:outline-none focus:border-zinc-700 cursor-pointer"
          >
            <option value="severity">Sort: Severity (High to Low)</option>
            <option value="date">Sort: Date</option>
            <option value="file">Sort: File Path</option>
          </select>
        </div>
      </div>

      {/* Issues List */}
      {loading ? (
        <div className="flex flex-col items-center justify-center p-20 text-zinc-400">
          <RotateCw className="w-8 h-8 animate-spin text-emerald-500 mb-3" />
          <span className="text-xs font-mono tracking-wider">QUERYING VULNERABILITY FINDINGS...</span>
        </div>
      ) : error ? (
        <div className="p-4 bg-rose-950/50 border border-rose-800 rounded-xl text-rose-300 text-xs break-anywhere">
          {error}
        </div>
      ) : issues.length === 0 ? (
        <div className="p-12 text-center bg-[#0c1017] border border-zinc-800/80 rounded-xl space-y-3">
          <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
          <h3 className="text-sm font-bold text-zinc-200">No matching issues found</h3>
          <p className="text-xs text-zinc-500 font-mono">
            No vulnerability matches with current filter settings.
          </p>
        </div>
      ) : (
        <div className="space-y-3 w-full min-w-0">
          {issues.map((issue) => (
            <div
              key={issue.id}
              onClick={() => onNavigateToIssue(issue.id)}
              className="p-4 sm:p-5 bg-[#0c1017] border border-zinc-800/90 rounded-xl hover:border-zinc-700 hover:bg-[#10151f] transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-4 cursor-pointer shadow-md group w-full min-w-0 max-w-full overflow-hidden"
            >
              <div className="space-y-2 flex-1 min-w-0 w-full">
                <div className="flex flex-wrap items-center gap-2">
                  <SeverityBadge severity={issue.severity} size="sm" />
                  <CategoryBadge category={issue.category} />
                  <span className="px-2 py-0.5 text-[10px] font-mono bg-zinc-950 text-zinc-400 border border-zinc-800 rounded shrink-0">
                    {issue.scanner}
                  </span>
                  {issue.cwe && (
                    <span className="px-2 py-0.5 text-[10px] font-mono bg-emerald-950/50 text-emerald-300 border border-emerald-800/60 rounded break-all max-w-full">
                      {issue.cwe}
                    </span>
                  )}
                  {issue.repo_name && (
                    <span className="text-[11px] font-mono text-zinc-500 break-all max-w-full">
                      repo: <span className="text-zinc-300">{issue.repo_name}</span>
                    </span>
                  )}
                </div>

                <div className="min-w-0 w-full">
                  <h3 className="text-sm sm:text-base font-bold text-zinc-100 group-hover:text-emerald-400 transition-colors [overflow-wrap:anywhere] break-words">
                    {issue.title}
                  </h3>
                  <p className="text-xs text-zinc-400 mt-1 [overflow-wrap:anywhere] break-words">
                    {issue.description}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-zinc-500 pt-1 min-w-0 w-full">
                  <div className="flex items-center gap-1 min-w-0 max-w-full">
                    <FileCode className="w-3.5 h-3.5 text-zinc-600 shrink-0" />
                    <span className="text-emerald-400/90 [overflow-wrap:anywhere] break-all">{issue.file_path}</span>
                    <span>:</span>
                    <span className="text-zinc-300 font-bold shrink-0">{issue.line_number}</span>
                  </div>
                  <span className="shrink-0">•</span>
                  <span className={`font-semibold shrink-0 ${
                    issue.status === 'RESOLVED' ? 'text-emerald-400' :
                    issue.status === 'CONFIRMED' ? 'text-orange-400' :
                    issue.status === 'FALSE_POSITIVE' ? 'text-zinc-500' : 'text-zinc-400'
                  }`}>
                    {issue.status}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0 self-end md:self-center">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onNavigateToIssue(issue.id);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-900 group-hover:bg-emerald-950/80 border border-zinc-800 group-hover:border-emerald-700/80 text-zinc-300 group-hover:text-emerald-300 text-xs font-semibold rounded-md transition-all whitespace-nowrap"
                >
                  <span>Triage &amp; Fix</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
