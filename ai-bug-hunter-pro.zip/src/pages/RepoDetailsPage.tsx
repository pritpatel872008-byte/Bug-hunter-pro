import React, { useState, useEffect } from 'react';
import { FolderGit2, ArrowLeft, RotateCw, Play, Shield, Trash2 } from 'lucide-react';
import { api } from '../api/client';
import { Repository, Scan } from '../types';
import { ScoreGauge } from '../components/ScoreGauge';

interface RepoDetailsPageProps {
  repoId: string;
  onBack: () => void;
  onNavigateToScan: (scanId: string) => void;
  onOpenUpload: () => void;
}

export const RepoDetailsPage: React.FC<RepoDetailsPageProps> = ({
  repoId,
  onBack,
  onNavigateToScan,
  onOpenUpload
}) => {
  const [repo, setRepo] = useState<Repository | null>(null);
  const [scans, setScans] = useState<Scan[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchRepo = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await api.getRepository(repoId);
      setRepo(res.repository);
      setScans(res.scans);
    } catch (err: any) {
      setError(err.message || 'Failed to load repository');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRepo();
  }, [repoId]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center p-16 text-zinc-400">
        <RotateCw className="w-8 h-8 animate-spin text-emerald-500 mb-3" />
        <span className="text-xs font-mono">Loading repository details...</span>
      </div>
    );
  }

  if (error || !repo) {
    return (
      <div className="p-6 max-w-4xl mx-auto space-y-4">
        <button onClick={onBack} className="flex items-center gap-1 text-xs text-zinc-400 hover:text-zinc-200">
          <ArrowLeft className="w-4 h-4" /> Back
        </button>
        <div className="p-4 bg-rose-950/50 border border-rose-800 rounded-lg text-rose-300 text-xs">
          {error || 'Repository not found'}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6 font-sans">
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-1 text-xs text-zinc-400 hover:text-zinc-200 font-mono transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Repositories</span>
        </button>

        <button
          onClick={onOpenUpload}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded transition-colors"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span>Run New Scan</span>
        </button>
      </div>

      {/* Repo Header */}
      <div className="p-6 bg-zinc-900 border border-zinc-800 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <FolderGit2 className="w-5 h-5 text-emerald-400" />
            <h1 className="text-xl font-bold text-zinc-100">{repo.name}</h1>
            <span className="px-2 py-0.5 text-xs font-mono bg-zinc-950 text-zinc-400 border border-zinc-800 rounded uppercase">
              {repo.source}
            </span>
          </div>
          <p className="text-xs text-zinc-400 font-mono">
            Branch: <span className="text-zinc-200">{repo.branch || 'main'}</span> • Created {new Date(repo.created_at).toLocaleDateString()}
          </p>
        </div>

        {scans.length > 0 && (
          <div>
            <div className="text-xs font-mono text-zinc-400 uppercase mb-1">Latest Security Score</div>
            <ScoreGauge score={scans[0].security_score} size="md" />
          </div>
        )}
      </div>

      {/* Historical Scans */}
      <div className="space-y-4">
        <h2 className="text-sm font-bold text-zinc-200 uppercase font-mono tracking-wider">
          Scan History ({scans.length})
        </h2>

        {scans.length === 0 ? (
          <div className="p-8 text-center bg-zinc-900 border border-zinc-800 rounded-lg text-zinc-500 font-mono text-xs">
            No scans performed for this repository yet.
          </div>
        ) : (
          <div className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden">
            <table className="w-full text-left font-mono text-xs">
              <thead className="bg-zinc-950/80 text-zinc-400 border-b border-zinc-800">
                <tr>
                  <th className="py-3 px-4 font-semibold">Commit / Ref</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                  <th className="py-3 px-4 font-semibold">Security Score</th>
                  <th className="py-3 px-4 font-semibold">Files / Lines</th>
                  <th className="py-3 px-4 font-semibold">Duration</th>
                  <th className="py-3 px-4 font-semibold">Date</th>
                  <th className="py-3 px-4 text-right font-semibold">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800">
                {scans.map((scan) => (
                  <tr key={scan.id} className="hover:bg-zinc-800/30 transition-colors">
                    <td className="py-3 px-4 font-bold text-zinc-200">
                      {scan.commit_hash || 'main'}
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-2 py-0.5 text-[10px] font-bold rounded uppercase ${
                          scan.status === 'COMPLETED'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                            : 'bg-zinc-800 text-zinc-400'
                        }`}
                      >
                        {scan.status}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <ScoreGauge score={scan.security_score} size="sm" />
                    </td>
                    <td className="py-3 px-4 text-zinc-400">
                      {scan.files_scanned} files ({scan.lines_scanned} lines)
                    </td>
                    <td className="py-3 px-4 text-zinc-400">
                      {scan.duration ? `${scan.duration}s` : '—'}
                    </td>
                    <td className="py-3 px-4 text-zinc-500">
                      {new Date(scan.started_at).toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => onNavigateToScan(scan.id)}
                        className="px-3 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded text-xs font-semibold transition-colors"
                      >
                        View Report
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
