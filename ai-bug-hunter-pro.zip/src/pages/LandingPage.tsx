import React from 'react';
import { Shield, Bug, KeyRound, Sparkles, FileText, ArrowRight, Play, Terminal, Lock, CheckCircle2 } from 'lucide-react';
import { useDemo } from '../contexts/DemoContext';

interface LandingPageProps {
  onStartScan: () => void;
  onNavigateToDashboard: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onStartScan, onNavigateToDashboard }) => {
  const { setDemoMode } = useDemo();

  const handleViewDemo = () => {
    setDemoMode(true);
    onNavigateToDashboard();
  };

  const capabilities = [
    {
      icon: <Terminal className="w-5 h-5 text-emerald-400" />,
      title: 'Real Static Analysis (SAST)',
      description: 'Executes AST security rules for Python (Bandit), JavaScript/TypeScript (ESLint), and cross-language semantic rules (Semgrep).'
    },
    {
      icon: <KeyRound className="w-5 h-5 text-amber-400" />,
      title: 'Secret & Credential Detection',
      description: 'Identifies committed AWS access keys, GitHub tokens, Stripe API keys, Slack credentials, private keys, and hardcoded JWT secrets.'
    },
    {
      icon: <Sparkles className="w-5 h-5 text-sky-400" />,
      title: 'Gemini AI Vulnerability Triage',
      description: 'Generates deep technical impact analysis, exploit scenarios, and verified non-breaking code diffs for detected vulnerabilities.'
    },
    {
      icon: <Bug className="w-5 h-5 text-rose-400" />,
      title: 'Automated Security Test Suite',
      description: 'Generates automated regression unit tests in pytest, Jest, Vitest, and JUnit tailored to the vulnerable function.'
    },
    {
      icon: <Shield className="w-5 h-5 text-purple-400" />,
      title: 'Dependency Vulnerability Audit',
      description: 'Cross-references package.json and requirements.txt manifests against known CVE vulnerability databases.'
    },
    {
      icon: <FileText className="w-5 h-5 text-teal-400" />,
      title: 'Executive Audit Reports',
      description: 'Export comprehensive security audit reports in Markdown and JSON with severity breakdown and remediation roadmaps.'
    }
  ];

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 font-sans selection:bg-emerald-950 selection:text-emerald-200">
      {/* Hero Section */}
      <section className="max-w-6xl mx-auto px-6 pt-20 pb-16 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-zinc-900 border border-zinc-800 rounded-full text-xs font-mono text-emerald-400 mb-6">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>Real Static Analysis &amp; AI Security Platform</span>
        </div>

        <h1 className="text-4xl sm:text-6xl font-black tracking-tight text-zinc-100 max-w-4xl mx-auto leading-tight">
          Find Bugs. Detect Vulnerabilities. <br className="hidden sm:inline" />
          <span className="text-emerald-400">Fix Code Faster.</span>
        </h1>

        <p className="mt-6 text-lg text-zinc-400 max-w-2xl mx-auto leading-relaxed">
          AI-powered security analysis for real repositories. Run deterministic SAST scanners, detect exposed secrets, and generate automated AI fixes with verified code diffs.
        </p>

        <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
          <button
            onClick={onStartScan}
            className="flex items-center gap-2 px-6 py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm rounded-md shadow-lg shadow-emerald-950 transition-all cursor-pointer"
          >
            <span>Scan Repository</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={handleViewDemo}
            className="flex items-center gap-2 px-6 py-3.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 font-bold text-sm rounded-md border border-zinc-800 transition-all cursor-pointer"
          >
            <Play className="w-4 h-4 fill-current text-zinc-400" />
            <span>View Demo Mode</span>
          </button>

          <button
            onClick={onNavigateToDashboard}
            className="px-6 py-3.5 text-zinc-400 hover:text-zinc-200 font-semibold text-sm transition-colors cursor-pointer"
          >
            Open Dashboard
          </button>
        </div>

        {/* Security & Privacy Notice Banner */}
        <div className="mt-12 max-w-2xl mx-auto p-3.5 bg-zinc-900/80 border border-zinc-800 rounded-lg flex items-center justify-center gap-3 text-xs text-zinc-400 font-mono">
          <Lock className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>Your source code is analyzed locally inside a sandboxed workspace. Raw code is not automatically broadcasted.</span>
        </div>
      </section>

      {/* Features Grid */}
      <section className="max-w-6xl mx-auto px-6 py-16 border-t border-zinc-900">
        <div className="text-center mb-12">
          <h2 className="text-2xl font-bold text-zinc-100">Enterprise-Grade Security Pipeline</h2>
          <p className="text-sm text-zinc-400 mt-2">
            Deterministic static scanners paired with intelligent contextual AI remediation
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {capabilities.map((item, idx) => (
            <div
              key={idx}
              className="p-6 bg-zinc-900/60 border border-zinc-800/80 rounded-lg hover:border-zinc-700 transition-colors flex flex-col justify-between"
            >
              <div>
                <div className="p-2.5 bg-zinc-950 border border-zinc-800 rounded-md w-fit mb-4">
                  {item.icon}
                </div>
                <h3 className="text-base font-bold text-zinc-200 mb-2">{item.title}</h3>
                <p className="text-xs text-zinc-400 leading-relaxed">{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Supported Scanners Section */}
      <section className="max-w-6xl mx-auto px-6 py-16 border-t border-zinc-900">
        <div className="p-8 bg-zinc-900 border border-zinc-800 rounded-xl">
          <h3 className="text-lg font-bold text-zinc-100 mb-2">Integrated Static Analysis Engines</h3>
          <p className="text-xs text-zinc-400 mb-6">
            Multi-engine coverage ensures comprehensive static detection across multiple programming paradigms.
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 font-mono text-xs">
            <div className="p-3 bg-zinc-950 border border-zinc-800 rounded flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span className="font-semibold text-zinc-200">Semgrep SAST</span>
            </div>
            <div className="p-3 bg-zinc-950 border border-zinc-800 rounded flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span className="font-semibold text-zinc-200">Gitleaks Secrets</span>
            </div>
            <div className="p-3 bg-zinc-950 border border-zinc-800 rounded flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span className="font-semibold text-zinc-200">Bandit Python</span>
            </div>
            <div className="p-3 bg-zinc-950 border border-zinc-800 rounded flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span className="font-semibold text-zinc-200">ESLint JS/TS</span>
            </div>
            <div className="p-3 bg-zinc-950 border border-zinc-800 rounded flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span className="font-semibold text-zinc-200">Dependency CVE</span>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="max-w-6xl mx-auto px-6 py-8 border-t border-zinc-900 text-center text-xs text-zinc-500 font-mono">
        AI BUG HUNTER PRO — Production Developer Security &amp; SAST Platform
      </footer>
    </div>
  );
};
