import React, { useState, useEffect } from 'react';
import {
  Settings,
  Sparkles,
  Server,
  CheckCircle2,
  XCircle,
  RotateCw,
  User,
  Mail,
  ShieldCheck,
  KeyRound,
  LogOut,
  AlertTriangle,
  Lock
} from 'lucide-react';
import { api } from '../api/client';
import { useAuth } from '../contexts/AuthContext';

interface SettingsPageProps {
  onOpenAuth?: (mode: 'login' | 'register' | 'forgot-password') => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({ onOpenAuth }) => {
  const { user, logout } = useAuth();
  const [aiStatus, setAiStatus] = useState<any>(null);
  const [emailConfig, setEmailConfig] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [switching, setSwitching] = useState(false);
  const [providerType, setProviderType] = useState<'gemini' | 'ollama'>('gemini');
  const [ollamaUrl, setOllamaUrl] = useState('http://localhost:11434');
  const [ollamaModel, setOllamaModel] = useState('codellama');
  const [message, setMessage] = useState<string | null>(null);

  const fetchStatus = async () => {
    try {
      setLoading(true);
      const [aiRes, emailRes] = await Promise.allSettled([
        api.getAIStatus(),
        api.getEmailConfig()
      ]);

      if (aiRes.status === 'fulfilled') {
        setAiStatus(aiRes.value);
        if (aiRes.value.provider.toLowerCase().includes('ollama')) {
          setProviderType('ollama');
        } else {
          setProviderType('gemini');
        }
      }

      if (emailRes.status === 'fulfilled') {
        setEmailConfig(emailRes.value);
      }
    } catch {
      // Ignored
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStatus();
  }, []);

  const handleSaveProvider = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSwitching(true);
      setMessage(null);
      const res = await fetch('/api/ai/configure', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          provider: providerType,
          ollamaUrl,
          model: ollamaModel
        })
      });
      const data = await res.json();
      setMessage(data.message || 'AI provider configured');
      fetchStatus();
    } catch (err: any) {
      setMessage(`Error: ${err.message}`);
    } finally {
      setSwitching(false);
    }
  };

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto space-y-6 font-sans w-full min-w-0 max-w-full overflow-hidden">
      <div>
        <h1 className="text-xl font-bold text-zinc-100">System &amp; Security Settings</h1>
        <p className="text-xs text-zinc-400 mt-0.5">
          Manage your authenticated profile, secure email delivery, and AI static analysis engines
        </p>
      </div>

      {/* Authenticated User Account Card */}
      <div className="p-5 sm:p-6 bg-[#0c1017] border border-zinc-800 rounded-xl space-y-4 w-full min-w-0">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <User className="w-5 h-5 text-emerald-400" />
            <h2 className="text-sm font-bold text-zinc-200 uppercase font-mono tracking-wider">
              User Profile &amp; Isolation
            </h2>
          </div>
          <span className="px-2.5 py-0.5 text-xs font-mono bg-emerald-950/80 text-emerald-300 border border-emerald-800 rounded-full font-semibold">
            STRICT MULTI-TENANT ISOLATION ACTIVE
          </span>
        </div>

        {user ? (
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 min-w-0">
            <div className="flex items-center gap-3.5 min-w-0">
              <div className="w-12 h-12 rounded-xl bg-emerald-950/80 border border-emerald-700/80 text-emerald-300 flex items-center justify-center font-mono font-bold text-lg shrink-0 shadow-[0_0_12px_rgba(16,185,129,0.2)]">
                {user.name.split(' ').map((n) => n[0]).join('').substring(0, 2).toUpperCase() || 'U'}
              </div>
              <div className="space-y-0.5 min-w-0">
                <div className="text-sm font-bold text-zinc-100 truncate flex items-center gap-2">
                  <span>{user.name}</span>
                  <span className="text-[10px] font-mono px-2 py-0.2 bg-zinc-800 text-zinc-300 rounded">
                    {user.role || 'Security Analyst'}
                  </span>
                </div>
                <div className="text-xs text-zinc-400 font-mono [overflow-wrap:anywhere] break-all">
                  {user.email}
                </div>
                <div className="text-[11px] text-zinc-500 font-mono">
                  Owner ID: <span className="text-zinc-400">{user.id}</span>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 pt-2 sm:pt-0">
              <button
                onClick={() => onOpenAuth && onOpenAuth('forgot-password')}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-200 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
              >
                <KeyRound className="w-3.5 h-3.5 text-amber-400" />
                <span>Reset Password</span>
              </button>
              <button
                onClick={logout}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/80 text-rose-300 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="text-xs text-zinc-400">
              You are currently browsing with a guest session. Sign in or register to persist your scan history securely.
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => onOpenAuth && onOpenAuth('login')}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold transition-colors cursor-pointer"
              >
                Sign In
              </button>
              <button
                onClick={() => onOpenAuth && onOpenAuth('register')}
                className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
              >
                Create Account
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Secure Email Delivery (SMTP / Reset Token) Status */}
      <div className="p-5 sm:p-6 bg-[#0c1017] border border-zinc-800 rounded-xl space-y-4 w-full min-w-0">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <Mail className="w-5 h-5 text-sky-400" />
            <h2 className="text-sm font-bold text-zinc-200 uppercase font-mono tracking-wider">
              Authentication Email Delivery
            </h2>
          </div>
          {emailConfig?.configured ? (
            <div className="flex items-center gap-1.5 text-xs font-mono text-emerald-400 font-semibold">
              <CheckCircle2 className="w-4 h-4" />
              <span>SMTP Ready ({emailConfig.provider})</span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 text-xs font-mono text-amber-400 font-semibold">
              <AlertTriangle className="w-4 h-4" />
              <span>Development Fallback Mode</span>
            </div>
          )}
        </div>

        <div className="space-y-2 text-xs text-zinc-400">
          <p>
            The authentication system generates SHA-256 hashed, short-lived (1-hour) password reset tokens.
          </p>
          <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-lg font-mono text-[11px] space-y-1">
            <div className="flex items-center justify-between text-zinc-300">
              <span>Delivery Status:</span>
              <span className={emailConfig?.configured ? 'text-emerald-400' : 'text-amber-300'}>
                {emailConfig?.configured ? `Live SMTP (${emailConfig.user})` : 'Dev Console / Direct UI Link'}
              </span>
            </div>
            <div className="flex items-center justify-between text-zinc-300">
              <span>Token Encryption:</span>
              <span className="text-emerald-400">SHA-256 with Expiration &amp; Single-Use Invalidation</span>
            </div>
          </div>
        </div>
      </div>

      {/* AI Provider Configuration */}
      <div className="p-5 sm:p-6 bg-[#0c1017] border border-zinc-800 rounded-xl space-y-5 w-full min-w-0">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-emerald-400" />
            <h2 className="text-sm font-bold text-zinc-200 uppercase font-mono tracking-wider">
              AI Security Engine
            </h2>
          </div>

          {loading ? (
            <RotateCw className="w-4 h-4 animate-spin text-zinc-500" />
          ) : (
            <div className="flex items-center gap-2 text-xs font-mono">
              {aiStatus?.available ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span className="text-emerald-400 font-bold">Online: {aiStatus.provider}</span>
                </>
              ) : (
                <>
                  <XCircle className="w-4 h-4 text-amber-400" />
                  <span className="text-amber-400 font-semibold">Offline / Key Unset</span>
                </>
              )}
            </div>
          )}
        </div>

        {message && (
          <div className="p-3 bg-zinc-950 border border-zinc-800 rounded text-xs font-mono text-emerald-300 [overflow-wrap:anywhere] break-words">
            {message}
          </div>
        )}

        <form onSubmit={handleSaveProvider} className="space-y-4 text-xs font-sans">
          <div className="space-y-2">
            <label className="block font-semibold text-zinc-300">Active AI Provider</label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label
                className={`p-3 border rounded-lg flex items-center gap-2 cursor-pointer transition-colors ${
                  providerType === 'gemini'
                    ? 'bg-zinc-950 border-emerald-500 text-zinc-100'
                    : 'bg-zinc-950/40 border-zinc-800 text-zinc-400 hover:border-zinc-700'
                }`}
              >
                <input
                  type="radio"
                  name="provider"
                  value="gemini"
                  checked={providerType === 'gemini'}
                  onChange={() => setProviderType('gemini')}
                  className="hidden"
                />
                <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
                <div className="min-w-0">
                  <div className="font-bold">Google Gemini</div>
                  <div className="text-[11px] text-zinc-500 font-mono">gemini-3.6-flash (Cloud)</div>
                </div>
              </label>

              <label
                className={`p-3 border rounded-lg flex items-center gap-2 cursor-pointer transition-colors ${
                  providerType === 'ollama'
                    ? 'bg-zinc-950 border-emerald-500 text-zinc-100'
                    : 'bg-zinc-950/40 border-zinc-800 text-zinc-400 hover:border-zinc-700'
                }`}
              >
                <input
                  type="radio"
                  name="provider"
                  value="ollama"
                  checked={providerType === 'ollama'}
                  onChange={() => setProviderType('ollama')}
                  className="hidden"
                />
                <Server className="w-4 h-4 text-sky-400 shrink-0" />
                <div className="min-w-0">
                  <div className="font-bold">Ollama</div>
                  <div className="text-[11px] text-zinc-500 font-mono">Local Private Model</div>
                </div>
              </label>
            </div>
          </div>

          {providerType === 'ollama' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-zinc-950 border border-zinc-800 rounded-lg">
              <div>
                <label className="block text-[11px] font-mono text-zinc-400 mb-1">Ollama Base URL</label>
                <input
                  type="text"
                  value={ollamaUrl}
                  onChange={(e) => setOllamaUrl(e.target.value)}
                  className="w-full px-3 py-1.5 bg-zinc-900 border border-zinc-800 rounded font-mono text-xs text-zinc-200"
                />
              </div>
              <div>
                <label className="block text-[11px] font-mono text-zinc-400 mb-1">Target Model</label>
                <input
                  type="text"
                  value={ollamaModel}
                  onChange={(e) => setOllamaModel(e.target.value)}
                  className="w-full px-3 py-1.5 bg-zinc-900 border border-zinc-800 rounded font-mono text-xs text-zinc-200"
                />
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={switching}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold rounded-lg text-xs transition-colors cursor-pointer shadow-md"
          >
            {switching ? 'Applying...' : 'Save AI Configuration'}
          </button>
        </form>
      </div>

      {/* Static Analysis Engines Info */}
      <div className="p-5 sm:p-6 bg-[#0c1017] border border-zinc-800 rounded-xl space-y-4 w-full min-w-0">
        <h2 className="text-sm font-bold text-zinc-200 uppercase font-mono tracking-wider">
          Integrated Analysis Engines
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 font-mono text-xs">
          <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-lg">
            <div className="font-bold text-zinc-200">Semgrep Rules Engine</div>
            <div className="text-[11px] text-zinc-500 font-sans mt-1">
              Semantic pattern matcher with SQLi, command execution, path traversal, and SSRF rules.
            </div>
          </div>

          <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-lg">
            <div className="font-bold text-zinc-200">Gitleaks Rules Engine</div>
            <div className="text-[11px] text-zinc-500 font-sans mt-1">
              Regex and entropy analyzer for API keys, AWS credentials, Slack webhooks, and private keys.
            </div>
          </div>

          <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-lg">
            <div className="font-bold text-zinc-200">Bandit Python Analyzer</div>
            <div className="text-[11px] text-zinc-500 font-sans mt-1">
              Python AST analyzer detecting pickle, eval, weak crypto hashes, and insecure bindings.
            </div>
          </div>

          <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-lg">
            <div className="font-bold text-zinc-200">ESLint Security Plugin</div>
            <div className="text-[11px] text-zinc-500 font-sans mt-1">
              JavaScript and TypeScript vulnerability engine detecting DOM XSS and loose equality.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

