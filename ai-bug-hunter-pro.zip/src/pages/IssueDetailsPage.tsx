import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  Shield,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  RotateCw,
  Copy,
  Check,
  Code2,
  Terminal,
  FileCheck,
  AlertCircle,
  Download,
  ShieldAlert,
  Info,
  ChevronLeft,
  ChevronRight,
  Plus,
  KeyRound,
  Lock,
  Zap,
  Globe,
  Database,
  Eye,
  FileCode
} from 'lucide-react';
import { api } from '../api/client';
import { Issue } from '../types';
import { SeverityBadge } from '../components/SeverityBadge';
import { CategoryBadge } from '../components/CategoryBadge';
import { DiffViewer } from '../components/DiffViewer';

interface IssueDetailsPageProps {
  issueId: string;
  onBack: () => void;
  onOpenUpload?: () => void;
}

export const IssueDetailsPage: React.FC<IssueDetailsPageProps> = ({
  issueId,
  onBack,
  onOpenUpload
}) => {
  const [issue, setIssue] = useState<Issue | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Active AI Tab / View in the Copilot section
  const [aiActiveTab, setAiActiveTab] = useState<'explain' | 'fix' | 'tests'>('explain');

  // AI Operation States
  const [explaining, setExplaining] = useState(false);
  const [aiExplanation, setAiExplanation] = useState<any>(null);
  const [aiExplainError, setAiExplainError] = useState<string | null>(null);

  const [fixing, setFixing] = useState(false);
  const [aiFix, setAiFix] = useState<any>(null);
  const [aiFixError, setAiFixError] = useState<string | null>(null);

  const [generatingTests, setGeneratingTests] = useState(false);
  const [aiTests, setAiTests] = useState<any>(null);
  const [aiTestsError, setAiTestsError] = useState<string | null>(null);
  const [testFramework, setTestFramework] = useState<string>('pytest');

  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedTest, setCopiedTest] = useState(false);
  const [copiedFix, setCopiedFix] = useState(false);

  const fetchIssue = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await api.getIssue(issueId);
      setIssue(res.issue);

      // Auto-detect framework based on file extension
      const ext = res.issue.file_path.split('.').pop()?.toLowerCase() || '';
      if (ext === 'py') {
        setTestFramework('pytest');
      } else if (ext === 'ts' || ext === 'tsx') {
        setTestFramework('vitest');
      } else if (ext === 'js' || ext === 'jsx') {
        setTestFramework('jest');
      } else if (ext === 'java') {
        setTestFramework('junit');
      }

      // Populate pre-saved AI analysis if present
      if (res.issue.ai_explanation) {
        setAiExplanation({
          explanation: res.issue.ai_explanation,
          impact: res.issue.ai_impact || 'Impact details recorded in audit log',
          recommendation: res.issue.recommendation,
          suggested_fix: res.issue.ai_fix || '// Safe refactoring'
        });
      }

      if (res.issue.ai_fix) {
        setAiFix({
          originalCode: res.issue.code_snippet,
          suggestedCode: res.issue.ai_fix,
          explanation: 'Verified automated remediation fix'
        });
      }

      if (res.issue.ai_tests) {
        setAiTests({
          testCode: res.issue.ai_tests,
          test_code: res.issue.ai_tests,
          testExplanation: 'Automated test suite verifying prevention of attack payload',
          explanation: 'Automated test suite verifying prevention of attack payload',
          framework: testFramework
        });
      }
    } catch (err: any) {
      setError(err.message || 'Failed to fetch issue details');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchIssue();
  }, [issueId]);

  const handleStatusChange = async (newStatus: Issue['status']) => {
    if (!issue) return;
    try {
      await api.updateIssueStatus(issue.id, newStatus);
      setIssue({ ...issue, status: newStatus });
    } catch (err: any) {
      alert(err.message || 'Failed to update issue status');
    }
  };

  const handleRunAiExplain = async () => {
    try {
      setExplaining(true);
      setAiActiveTab('explain');
      setAiExplainError(null);
      const res = await api.explainIssue(issueId);
      setAiExplanation(res.analysis);
    } catch (err: any) {
      setAiExplainError(err.message || 'AI analysis unavailable. Scanner finding is still available.');
    } finally {
      setExplaining(false);
    }
  };

  const handleRunAiFix = async () => {
    try {
      setFixing(true);
      setAiActiveTab('fix');
      setAiFixError(null);
      const res = await api.generateFix(issueId);
      setAiFix(res.fix);
    } catch (err: any) {
      setAiFixError(err.message || 'AI fix generator unavailable.');
    } finally {
      setFixing(false);
    }
  };

  const handleRunAiTests = async () => {
    try {
      setGeneratingTests(true);
      setAiActiveTab('tests');
      setAiTestsError(null);
      const res = await api.generateTests(issueId, testFramework);
      setAiTests(res.tests);
    } catch (err: any) {
      const errMsg = err.message || '';
      if (errMsg.toLowerCase().includes('json') || errMsg.toLowerCase().includes('position') || errMsg.toLowerCase().includes('escape')) {
        setAiTestsError('Gemini returned an invalid structured response. Please retry.');
      } else {
        setAiTestsError(errMsg || 'AI test generator unavailable.');
      }
    } finally {
      setGeneratingTests(false);
    }
  };

  const handleCopyVulnerableCode = () => {
    if (!issue) return;
    navigator.clipboard.writeText(issue.code_snippet);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleDownloadTest = () => {
    if (!aiTests) return;
    const code = aiTests.test_code || aiTests.testCode || '';
    let filename = 'test_security_remediation.py';

    const fw = (aiTests.framework || testFramework).toLowerCase();
    if (fw.includes('vitest')) {
      filename = 'test_security_remediation.test.ts';
    } else if (fw.includes('jest')) {
      filename = 'test_security_remediation.test.js';
    } else if (fw.includes('junit') || fw === 'java') {
      filename = 'SecurityRemediationTest.java';
    }

    const blob = new Blob([code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleDownloadFix = () => {
    if (!aiFix?.suggestedCode) return;
    const code = aiFix.suggestedCode;
    const filename = `remediated_${issue?.file_path.split('/').pop() || 'file'}`;

    const blob = new Blob([code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center p-20 text-zinc-400">
        <RotateCw className="w-8 h-8 animate-spin text-emerald-500 mb-3" />
        <span className="text-xs font-mono tracking-wider">LOADING VULNERABILITY CONTEXT...</span>
      </div>
    );
  }

  if (error || !issue) {
    return (
      <div className="p-6 max-w-4xl mx-auto space-y-4">
        <button onClick={onBack} className="flex items-center gap-1.5 text-xs text-zinc-400 hover:text-zinc-200">
          <ArrowLeft className="w-4 h-4" /> Back to Findings
        </button>
        <div className="p-4 bg-rose-950/50 border border-rose-800 rounded-lg text-rose-300 text-xs">
          {error || 'Finding not found in database'}
        </div>
      </div>
    );
  }

  const activeTestCode = aiTests ? (aiTests.test_code || aiTests.testCode) : null;
  const activeTestExplanation = aiTests ? (aiTests.explanation || aiTests.testExplanation) : null;
  const fileExtension = issue.file_path.split('.').pop()?.toUpperCase() || 'CODE';

  // Format code snippet into line numbers
  const codeLines = (issue.code_snippet || '').split('\n');
  const startLineNumber = Math.max(1, issue.line_number - Math.floor(codeLines.length / 2));

  // Determine potential impact items based on category
  const impactItems = [
    { icon: Lock, label: 'Data Breach', desc: 'Exfiltration of sensitive assets' },
    { icon: KeyRound, label: 'Unauthorized Access', desc: 'Bypass authentication boundaries' },
    { icon: Zap, label: 'Privilege Escalation', desc: 'Attain higher execution privileges' },
    { icon: Shield, label: 'Reputation Damage', desc: 'Compliance & security exposure' }
  ];

  return (
    <div className="p-4 sm:p-6 max-w-6xl mx-auto space-y-5 font-sans w-full overflow-hidden">
      {/* Top Action Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-1 border-b border-zinc-800/80">
        {/* Left: Back Button */}
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-900/80 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-zinc-100 text-xs font-semibold rounded-md transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Findings</span>
        </button>

        {/* Center/Right: Status selector, Prev/Next, Scan Button */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Status Dropdown */}
          <div className="flex items-center gap-1.5 bg-zinc-900 border border-zinc-800 px-2.5 py-1 rounded-md text-xs font-mono">
            <span className="text-zinc-400 font-sans text-xs">Status:</span>
            <span className={`w-2 h-2 rounded-full ${
              issue.status === 'RESOLVED' ? 'bg-emerald-400' :
              issue.status === 'CONFIRMED' ? 'bg-orange-400' :
              issue.status === 'FALSE_POSITIVE' ? 'bg-zinc-500' : 'bg-emerald-400'
            }`} />
            <select
              value={issue.status}
              onChange={(e) => handleStatusChange(e.target.value as any)}
              className="bg-transparent text-zinc-100 font-bold focus:outline-none cursor-pointer pr-1"
            >
              <option value="OPEN" className="bg-zinc-900 text-zinc-100">OPEN</option>
              <option value="CONFIRMED" className="bg-zinc-900 text-orange-400">CONFIRMED</option>
              <option value="RESOLVED" className="bg-zinc-900 text-emerald-400">RESOLVED</option>
              <option value="FALSE_POSITIVE" className="bg-zinc-900 text-zinc-400">FALSE POSITIVE</option>
            </select>
          </div>

          {/* Prev/Next Buttons */}
          <div className="flex items-center bg-zinc-900 border border-zinc-800 rounded-md overflow-hidden text-xs">
            <button
              onClick={onBack}
              className="px-2.5 py-1.5 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200 border-r border-zinc-800 transition-colors flex items-center gap-1"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              <span>Prev</span>
            </button>
            <button
              onClick={onBack}
              className="px-2.5 py-1.5 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200 transition-colors flex items-center gap-1"
            >
              <span>Next</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Quick Scan Button */}
          {onOpenUpload && (
            <button
              onClick={onOpenUpload}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-md shadow-sm transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Scan Repository</span>
              <span className="sm:hidden">Scan</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Finding Overview Card */}
      <div className="p-5 sm:p-6 bg-[#0c1017] border border-zinc-800/90 rounded-xl relative overflow-hidden shadow-lg w-full min-w-0 max-w-full">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 min-w-0 w-full">
          {/* Left Content Area */}
          <div className="space-y-3 flex-1 min-w-0 w-full">
            {/* Badges Bar */}
            <div className="flex flex-wrap items-center gap-2">
              <SeverityBadge severity={issue.severity} size="md" />
              <CategoryBadge category={issue.category} />
              <span className="px-2.5 py-1 text-xs font-mono bg-zinc-900 text-zinc-300 border border-zinc-800 rounded shrink-0">
                Scanner: <span className="text-emerald-400 font-semibold">{issue.scanner}</span>
              </span>
              {issue.cwe && (
                <span className="px-2.5 py-1 text-xs font-mono bg-emerald-950/60 text-emerald-300 border border-emerald-800/80 rounded font-semibold break-all">
                  {issue.cwe}
                </span>
              )}
              <span className="px-2.5 py-1 text-xs font-mono bg-zinc-900 text-zinc-400 border border-zinc-800 rounded shrink-0">
                Confidence: <span className="text-zinc-200 font-semibold">{issue.confidence || 'MEDIUM'}</span>
              </span>
            </div>

            {/* Title & Description */}
            <div className="min-w-0 w-full">
              <h1 className="text-xl sm:text-2xl font-bold text-zinc-100 tracking-tight [overflow-wrap:anywhere] break-words">
                {issue.title}
              </h1>
              <p className="text-xs sm:text-sm text-zinc-400 mt-1.5 leading-relaxed max-w-3xl [overflow-wrap:anywhere] break-words">
                {issue.description}
              </p>
            </div>

            {/* Finding Location Meta Bar */}
            <div className="flex flex-wrap items-center gap-y-2 gap-x-4 pt-2 text-xs font-mono text-zinc-400 border-t border-zinc-800/60 min-w-0 w-full">
              <div className="flex items-center gap-1.5 min-w-0 max-w-full">
                <FileCode className="w-3.5 h-3.5 text-zinc-500 shrink-0" />
                <span className="text-zinc-500 font-sans shrink-0">File:</span>
                <span className="text-emerald-400 font-semibold [overflow-wrap:anywhere] break-all">{issue.file_path}</span>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <span className="text-zinc-500 font-sans">Line:</span>
                <span className="text-zinc-200 font-bold bg-zinc-900 px-2 py-0.5 rounded border border-zinc-800">
                  {issue.line_number}
                </span>
              </div>
              <div className="flex items-center gap-1.5 text-zinc-500 shrink-0">
                <span>First Seen:</span>
                <span className="text-zinc-400">
                  {new Date(issue.created_at || Date.now()).toLocaleDateString('en-US', {
                    month: 'short',
                    day: 'numeric',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </span>
              </div>
            </div>
          </div>

          {/* Right Glowing Shield Graphic */}
          <div className="hidden lg:flex items-center justify-center shrink-0">
            <div className="relative w-28 h-28 flex items-center justify-center">
              <div className="absolute inset-0 bg-gradient-to-tr from-amber-500/20 via-orange-500/10 to-transparent rounded-full blur-xl" />
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-amber-950/60 via-[#16120b] to-zinc-950 border border-amber-500/40 flex items-center justify-center text-amber-400 shadow-[0_0_20px_rgba(245,158,11,0.2)]">
                <KeyRound className="w-9 h-9 text-amber-400" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 3-Section Triaging Layout: What is the problem? / Why does it matter? / How to fix it? */}
      <div className="space-y-3.5 w-full min-w-0">
        {/* 1. What is the problem? */}
        <div className="p-4 sm:p-5 bg-[#0c1017] border border-rose-900/40 rounded-xl space-y-2 relative overflow-hidden w-full min-w-0">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-full bg-rose-950/80 border border-rose-800 flex items-center justify-center text-rose-400 shrink-0">
              <Info className="w-3.5 h-3.5" />
            </div>
            <h3 className="text-xs font-bold font-mono text-rose-400 uppercase tracking-wider">
              1. What is the problem?
            </h3>
          </div>
          <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed pl-8 [overflow-wrap:anywhere] break-words">
            {aiExplanation?.explanation || issue.description || 'A security vulnerability was identified by the static analysis engine.'}
          </p>
        </div>

        {/* 2. Why does it matter? */}
        <div className="p-4 sm:p-5 bg-[#0c1017] border border-amber-900/40 rounded-xl relative overflow-hidden w-full min-w-0">
          <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4 min-w-0">
            <div className="space-y-2 flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-amber-950/80 border border-amber-800 flex items-center justify-center text-amber-400 shrink-0">
                  <AlertTriangle className="w-3.5 h-3.5" />
                </div>
                <h3 className="text-xs font-bold font-mono text-amber-400 uppercase tracking-wider">
                  2. Why does it matter?
                </h3>
              </div>
              <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed pl-8 [overflow-wrap:anywhere] break-words">
                {aiExplanation?.impact ||
                  'Attackers can leverage this vulnerability to bypass access controls, extract sensitive secrets, or execute unauthorized operations against backend infrastructure.'}
              </p>
            </div>

            {/* Potential Impact Checklist */}
            <div className="lg:w-80 p-3 bg-zinc-950/80 border border-zinc-800/80 rounded-lg shrink-0 w-full lg:w-80 min-w-0">
              <div className="text-[10px] font-mono font-bold text-amber-400/90 uppercase tracking-wider mb-2">
                Potential Impact
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-1.5">
                {impactItems.map((item, idx) => {
                  const Icon = item.icon;
                  return (
                    <div key={idx} className="flex items-center gap-2 text-xs text-zinc-300 min-w-0">
                      <Icon className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span className="truncate">{item.label}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* 3. How to fix it? */}
        <div className="p-4 sm:p-5 bg-[#0c1017] border border-emerald-900/40 rounded-xl relative overflow-hidden w-full min-w-0">
          <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4 min-w-0">
            <div className="space-y-2 flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-emerald-950/80 border border-emerald-800 flex items-center justify-center text-emerald-400 shrink-0">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                </div>
                <h3 className="text-xs font-bold font-mono text-emerald-400 uppercase tracking-wider">
                  3. How to fix it?
                </h3>
              </div>
              <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed pl-8 [overflow-wrap:anywhere] break-words">
                {issue.recommendation || aiExplanation?.recommendation || 'Move sensitive credentials to environment variables or use secure parameterized APIs.'}
              </p>
            </div>

            {/* Example Snippet Box */}
            <div className="w-full lg:w-80 p-3 bg-zinc-950/90 border border-zinc-800 rounded-lg shrink-0 font-mono text-xs min-w-0 overflow-hidden">
              <div className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5 flex items-center justify-between">
                <span>Recommended (.env / config)</span>
                <span className="text-emerald-400 text-[9px]">SECURE</span>
              </div>
              <pre className="text-emerald-300 text-[11px] leading-relaxed overflow-x-auto min-w-0 max-w-full">
{`API_KEY=your_real_api_key_here
DB_PASSWORD=your_secure_password`}
              </pre>
            </div>
          </div>
        </div>
      </div>

      {/* Vulnerable Code Context */}
      <div className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-2">
            <FileCode className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-mono font-bold text-zinc-200 uppercase tracking-wider">
              Vulnerable Code Context
            </span>
          </div>
          <span className="text-xs font-mono text-zinc-500">
            {issue.file_path}:{issue.line_number}
          </span>
        </div>

        {/* Code Editor Container */}
        <div className="border border-zinc-800 rounded-xl overflow-hidden bg-[#090d13] font-mono text-xs shadow-inner">
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-2.5 bg-zinc-900/90 border-b border-zinc-800 text-zinc-400">
            <div className="flex items-center gap-2 truncate">
              <span className="truncate font-semibold text-zinc-200">{issue.file_path}</span>
              <span className="px-1.5 py-0.5 bg-zinc-800 text-zinc-400 text-[10px] font-bold rounded">
                {fileExtension}
              </span>
            </div>

            <button
              onClick={handleCopyVulnerableCode}
              className="flex items-center gap-1.5 px-2.5 py-1 text-[11px] bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded transition-colors cursor-pointer"
            >
              {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedCode ? 'Copied' : 'Copy'}</span>
            </button>
          </div>

          {/* Line Numbers & Code content */}
          <div className="overflow-x-auto p-4 select-text">
            <table className="w-full border-collapse">
              <tbody>
                {codeLines.map((lineText, idx) => {
                  const currentLineNumber = startLineNumber + idx;
                  const isVulnerableLine = currentLineNumber === issue.line_number;

                  return (
                    <tr
                      key={idx}
                      className={`leading-relaxed ${
                        isVulnerableLine
                          ? 'bg-rose-950/60 text-rose-200 border-l-2 border-rose-500 font-bold'
                          : 'text-zinc-300 hover:bg-zinc-900/30'
                      }`}
                    >
                      <td className="pr-4 pl-1 text-right select-none text-zinc-600 w-10 text-[11px] align-top font-mono">
                        {currentLineNumber}
                      </td>
                      <td className="whitespace-pre font-mono pl-3">
                        {lineText || ' '}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* GEMINI AI SECURITY COPILOT / AI SECURITY ASSISTANCE */}
      <div className="p-5 sm:p-6 bg-[#0c1017] border border-zinc-800/90 rounded-xl space-y-5 shadow-xl">
        {/* Copilot Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-emerald-400" />
            <div>
              <h2 className="text-sm font-bold text-zinc-100 uppercase font-mono tracking-wider flex items-center gap-2">
                <span>✦ Gemini AI Security Copilot</span>
                <span className="text-[10px] px-2 py-0.5 bg-emerald-950 text-emerald-400 border border-emerald-800 rounded font-normal">
                  AI READY
                </span>
              </h2>
            </div>
          </div>

          {/* Action Trigger Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handleRunAiExplain}
              disabled={explaining}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md border transition-all cursor-pointer ${
                aiActiveTab === 'explain' && aiExplanation
                  ? 'bg-zinc-800 text-zinc-100 border-zinc-600 shadow-sm'
                  : 'bg-zinc-900/80 hover:bg-zinc-800 text-zinc-300 border-zinc-700'
              } disabled:opacity-50`}
            >
              {explaining ? <RotateCw className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5 text-emerald-400" />}
              <span>{explaining ? 'Analyzing with Gemini...' : 'Deep AI Explanation'}</span>
            </button>

            <button
              onClick={handleRunAiFix}
              disabled={fixing}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                aiActiveTab === 'fix' && aiFix
                  ? 'bg-emerald-600 text-white shadow-[0_0_12px_rgba(16,185,129,0.3)]'
                  : 'bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 border border-emerald-800'
              } disabled:opacity-50`}
            >
              {fixing ? <RotateCw className="w-3.5 h-3.5 animate-spin" /> : <Code2 className="w-3.5 h-3.5" />}
              <span>{fixing ? 'Generating Fix...' : 'Generate AI Fix'}</span>
            </button>

            <button
              onClick={() => setAiActiveTab('tests')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                aiActiveTab === 'tests'
                  ? 'bg-sky-900 text-sky-100 border border-sky-600 shadow-[0_0_12px_rgba(14,165,233,0.3)]'
                  : 'bg-sky-950/80 hover:bg-sky-900 text-sky-300 border border-sky-800'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>Generate Defensive Tests</span>
            </button>
          </div>
        </div>

        {/* AI Explain Error */}
        {aiExplainError && (
          <div className="p-3.5 bg-amber-950/40 border border-amber-800/80 rounded-lg text-amber-300 text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{aiExplainError}</span>
          </div>
        )}

        {/* AI Fix Error */}
        {aiFixError && (
          <div className="p-3.5 bg-amber-950/40 border border-amber-800/80 rounded-lg text-amber-300 text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{aiFixError}</span>
          </div>
        )}

        {/* Active Tab View 1: Deep AI Explanation Result */}
        {aiActiveTab === 'explain' && aiExplanation && (
          <div className="p-4 sm:p-5 bg-zinc-950/90 border border-zinc-800 rounded-xl space-y-4 text-xs font-sans">
            <div className="flex items-center justify-between pb-2 border-b border-zinc-800 text-zinc-300">
              <span className="font-bold uppercase font-mono tracking-wider text-emerald-400 text-xs">
                Gemini Security Triaging Assessment
              </span>
              <span className="text-[11px] font-mono text-zinc-500">
                Confidence: {Math.round((Number(aiExplanation.confidence) || 0.95) * 100)}%
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <span className="font-bold text-zinc-200 block">Vulnerability Mechanism</span>
                <p className="text-zinc-400 leading-relaxed">{aiExplanation.explanation}</p>
              </div>

              <div className="space-y-1.5">
                <span className="font-bold text-rose-300 block">Exploit Threat Vector</span>
                <p className="text-zinc-400 leading-relaxed">
                  {aiExplanation.exploitScenario || aiExplanation.impact}
                </p>
              </div>
            </div>

            <div className="pt-2 border-t border-zinc-800/80 space-y-1.5">
              <span className="font-bold text-emerald-400 block">Recommended Architecture Changes</span>
              <p className="text-zinc-300 leading-relaxed">
                {aiExplanation.recommendation || aiExplanation.remediation}
              </p>
            </div>
          </div>
        )}

        {/* Active Tab View 2: AI Suggested Code Fix */}
        {aiActiveTab === 'fix' && aiFix && (
          <div className="space-y-3">
            <div className="flex items-center justify-between px-1">
              <span className="text-xs font-mono font-bold text-emerald-400 uppercase tracking-wider">
                Automated Remediation Patch
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(aiFix.suggestedCode);
                    setCopiedFix(true);
                    setTimeout(() => setCopiedFix(false), 2000);
                  }}
                  className="flex items-center gap-1 text-[11px] px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded transition-colors cursor-pointer"
                >
                  {copiedFix ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedFix ? 'Copied Fix' : 'Copy Fix'}</span>
                </button>
                <button
                  onClick={handleDownloadFix}
                  className="flex items-center gap-1 text-[11px] px-2.5 py-1 bg-emerald-950 hover:bg-emerald-900 border border-emerald-800 text-emerald-300 rounded transition-colors cursor-pointer"
                >
                  <Download className="w-3 h-3" />
                  <span>Download Fix</span>
                </button>
              </div>
            </div>

            <DiffViewer
              originalCode={aiFix.originalCode || issue.code_snippet}
              suggestedCode={aiFix.suggestedCode}
              explanation={aiFix.explanation}
              potentialSideEffects={aiFix.potentialSideEffects}
              recommendedTests={aiFix.recommendedTests}
            />
          </div>
        )}

        {/* Active Tab View 3: Defensive Test Suite Generator */}
        <div className="pt-3 border-t border-zinc-800/80 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 bg-zinc-950/80 border border-zinc-800 rounded-lg">
            <div>
              <div className="text-xs font-mono font-bold text-zinc-200 uppercase tracking-wider">
                Generate Defensive Security Tests
              </div>
              <div className="text-[11px] text-zinc-400 font-sans mt-0.5">
                Generate executable unit tests tailored to verify this vulnerability is prevented
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 shrink-0">
              <select
                value={testFramework}
                onChange={(e) => setTestFramework(e.target.value)}
                className="px-3 py-1.5 bg-zinc-900 border border-zinc-700 rounded-md text-xs font-mono text-zinc-200 focus:outline-none focus:border-zinc-500 cursor-pointer"
              >
                <option value="pytest">pytest (Python)</option>
                <option value="jest">Jest (JS/TS)</option>
                <option value="vitest">Vitest (JS/TS)</option>
                <option value="junit">JUnit (Java)</option>
              </select>

              <button
                onClick={handleRunAiTests}
                disabled={generatingTests}
                className="flex items-center gap-1.5 px-3.5 py-1.5 bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white text-xs font-semibold rounded-md transition-colors shadow-sm cursor-pointer"
              >
                {generatingTests ? <RotateCw className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                <span>{generatingTests ? 'Generating...' : 'Generate Defensive Tests'}</span>
              </button>
            </div>
          </div>

          {/* Test Error Message */}
          {aiTestsError && (
            <div className="p-4 bg-amber-950/40 border border-amber-800/80 rounded-lg text-xs space-y-3">
              <div className="flex items-start gap-2 text-amber-300">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{aiTestsError}</span>
              </div>
              <div>
                <button
                  onClick={handleRunAiTests}
                  disabled={generatingTests}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-900/60 hover:bg-amber-800/80 text-amber-100 font-semibold rounded text-xs transition-colors cursor-pointer"
                >
                  <RotateCw className={`w-3.5 h-3.5 ${generatingTests ? 'animate-spin' : ''}`} />
                  <span>Retry Test Generation</span>
                </button>
              </div>
            </div>
          )}

          {/* Generated Test Code Display */}
          {activeTestCode && (
            <div className="border border-zinc-800 rounded-xl overflow-hidden bg-zinc-950 font-mono text-xs space-y-0 shadow-lg">
              {/* Review Before Execution Notice */}
              <div className="px-4 py-2 bg-amber-950/30 border-b border-amber-900/40 flex items-center justify-between text-[11px] text-amber-300 font-sans">
                <div className="flex items-center gap-1.5">
                  <ShieldAlert className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span className="font-semibold">AI-generated test — review before execution</span>
                </div>
                <span className="font-mono text-amber-400/80 uppercase text-[10px]">
                  Framework: {aiTests?.framework || testFramework}
                </span>
              </div>

              {/* Action Toolbar */}
              <div className="flex items-center justify-between px-4 py-2.5 bg-zinc-900 border-b border-zinc-800 text-zinc-400">
                <span className="font-semibold text-zinc-200">
                  Target Test Suite ({aiTests?.framework || testFramework})
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(activeTestCode);
                      setCopiedTest(true);
                      setTimeout(() => setCopiedTest(false), 2000);
                    }}
                    className="flex items-center gap-1 text-[11px] px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded transition-colors cursor-pointer"
                  >
                    {copiedTest ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedTest ? 'Copied' : 'Copy Test'}</span>
                  </button>

                  <button
                    onClick={handleDownloadTest}
                    className="flex items-center gap-1 text-[11px] px-2.5 py-1 bg-sky-950 hover:bg-sky-900 border border-sky-800 text-sky-300 rounded transition-colors cursor-pointer"
                  >
                    <Download className="w-3 h-3" />
                    <span>Download Test</span>
                  </button>
                </div>
              </div>

              {/* Code display */}
              <pre className="p-4 overflow-x-auto text-sky-200/90 whitespace-pre leading-relaxed font-mono select-text">
                {activeTestCode}
              </pre>

              {/* Test Cases Summary List */}
              {Array.isArray(aiTests?.test_cases) && aiTests.test_cases.length > 0 && (
                <div className="p-3.5 bg-zinc-900/80 border-t border-zinc-800 text-[11px] font-sans space-y-2">
                  <div className="font-mono font-bold text-zinc-300 uppercase tracking-wider text-[10px]">
                    Covered Test Scenarios ({aiTests.test_cases.length}):
                  </div>
                  <div className="space-y-1.5">
                    {aiTests.test_cases.map((tc: any, idx: number) => (
                      <div key={idx} className="flex items-start gap-2 bg-zinc-950 p-2.5 rounded border border-zinc-800/80">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                        <div>
                          <div className="font-mono font-bold text-zinc-200 text-[11px]">{tc.name}</div>
                          <div className="text-zinc-400 text-[11px] mt-0.5">{tc.description}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Explanation & Run Instructions */}
              {(activeTestExplanation || aiTests?.runInstructions) && (
                <div className="p-3.5 bg-zinc-900 border-t border-zinc-800 text-[11px] text-zinc-400 font-sans space-y-1.5">
                  {activeTestExplanation && (
                    <div>
                      <span className="text-zinc-500 font-mono">Purpose: </span>
                      <span className="text-zinc-300">{activeTestExplanation}</span>
                    </div>
                  )}
                  {aiTests?.runInstructions && (
                    <div className="font-mono pt-1">
                      <span className="text-zinc-500">Run Command: </span>
                      <code className="text-emerald-400 bg-zinc-950 px-2.5 py-1 rounded border border-zinc-800">
                        {aiTests.runInstructions}
                      </code>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Bottom Metadata Audit Footer */}
      <div className="p-4 bg-[#0c1017] border border-zinc-800/80 rounded-xl flex flex-wrap items-center justify-between gap-3 text-xs font-mono text-zinc-500">
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 rounded-full bg-emerald-950 border border-emerald-800 flex items-center justify-center text-emerald-400">
            <Check className="w-3 h-3" />
          </div>
          <div>
            <span className="text-zinc-400">Finding ID: </span>
            <span className="text-zinc-200 font-bold">FIND-{issue.id.slice(0, 16)}</span>
          </div>
        </div>

        <div className="text-right">
          <div>Scan ID: SCAN-{issue.scan_id ? issue.scan_id.slice(0, 16) : 'AUDIT-001'}</div>
          <div className="text-[10px] text-zinc-600">Verified by Static Analyzer &amp; Gemini AI Copilot</div>
        </div>
      </div>
    </div>
  );
};
