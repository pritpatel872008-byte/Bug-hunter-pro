import React, { useState, useEffect } from 'react';
import { FileText, Download, Printer, RotateCw, ArrowLeft, Copy, Check } from 'lucide-react';
import { api } from '../api/client';

interface ReportsPageProps {
  scanId: string;
  onBack: () => void;
}

export const ReportsPage: React.FC<ReportsPageProps> = ({ scanId, onBack }) => {
  const [reportMarkdown, setReportMarkdown] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const fetchReport = async () => {
      try {
        setLoading(true);
        setError(null);
        const res = await fetch(`/api/reports/${scanId}?format=markdown`);
        if (!res.ok) throw new Error('Failed to load markdown report');
        const text = await res.text();
        setReportMarkdown(text);
      } catch (err: any) {
        setError(err.message || 'Failed to fetch report');
      } finally {
        setLoading(false);
      }
    };
    fetchReport();
  }, [scanId]);

  const handleCopy = () => {
    navigator.clipboard.writeText(reportMarkdown);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6 font-sans">
      {/* Header */}
      <div className="flex items-center justify-between no-print">
        <button
          onClick={onBack}
          className="flex items-center gap-1 text-xs text-zinc-400 hover:text-zinc-200 font-mono transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Scan Details</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 text-xs font-semibold rounded transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy Markdown'}</span>
          </button>

          <a
            href={`/api/reports/${scanId}?format=markdown&download=true`}
            download
            className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 text-xs font-semibold rounded transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download MD</span>
          </a>

          <a
            href={`/api/reports/${scanId}?format=json&download=true`}
            download
            className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 text-xs font-semibold rounded transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download JSON</span>
          </a>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded transition-colors"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Report</span>
          </button>
        </div>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center p-16 text-zinc-400">
          <RotateCw className="w-8 h-8 animate-spin text-emerald-500 mb-3" />
          <span className="text-xs font-mono">Generating formal audit documentation...</span>
        </div>
      ) : error ? (
        <div className="p-4 bg-rose-950/50 border border-rose-800 rounded-lg text-rose-300 text-xs">
          {error}
        </div>
      ) : (
        <div className="p-8 bg-zinc-900 border border-zinc-800 rounded-lg font-mono text-xs text-zinc-300 space-y-4 shadow-xl">
          <pre className="whitespace-pre-wrap font-mono leading-relaxed select-text">
            {reportMarkdown}
          </pre>
        </div>
      )}
    </div>
  );
};
