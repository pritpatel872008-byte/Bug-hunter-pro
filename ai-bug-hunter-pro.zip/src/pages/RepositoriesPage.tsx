import React, { useState, useEffect } from 'react';
import { FolderGit2, Upload, Trash2, Play, Plus, RotateCw, ExternalLink } from 'lucide-react';
import { api } from '../api/client';
import { Repository } from '../types';
import { ScoreGauge } from '../components/ScoreGauge';

interface RepositoriesPageProps {
  onOpenUpload: () => void;
  onNavigateToScan: (scanId: string) => void;
  onNavigateToRepo: (repoId: string) => void;
}

export const RepositoriesPage: React.FC<RepositoriesPageProps> = ({
  onOpenUpload,
  onNavigateToScan,
  onNavigateToRepo
}) => {
  const [repositories, setRepositories] = useState<Repository[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchRepositories = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await api.getRepositories();
      setRepositories(res.repositories);
    } catch (err: any) {
      setError(err.message || 'Failed to load repositories');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRepositories();
  }, []);

  const handleDelete = async (id: string, name: string) => {
    if (confirm(`Are you sure you want to delete repository "${name}" and all its historical scans?`)) {
      try {
        await api.deleteRepository(id);
        fetchRepositories();
      } catch (err: any) {
        alert(err.message || 'Failed to delete repository');
      }
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6 font-sans">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-zinc-100">Repositories</h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Manage analyzed repositories, branch tracking, and historical scan results
          </p>
        </div>
        <button
          onClick={onOpenUpload}
          className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>New Repository Scan</span>
        </button>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center p-16 text-zinc-400">
          <RotateCw className="w-6 h-6 animate-spin text-emerald-500 mb-2" />
          <span className="text-xs font-mono">Loading repositories...</span>
        </div>
      ) : error ? (
        <div className="p-4 bg-rose-950/50 border border-rose-800 rounded-lg text-rose-300 text-xs">
          {error}
        </div>
      ) : repositories.length === 0 ? (
        <div className="p-12 text-center bg-zinc-900 border border-zinc-800 rounded-lg space-y-4">
          <FolderGit2 className="w-12 h-12 text-zinc-600 mx-auto" />
          <div>
            <h3 className="text-sm font-bold text-zinc-200">No repositories connected yet.</h3>
            <p className="text-xs text-zinc-500 mt-1 max-w-md mx-auto">
              Upload a source code ZIP archive or connect a public GitHub repository to perform static analysis.
            </p>
          </div>
          <button
            onClick={onOpenUpload}
            className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded transition-colors"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Upload Archive</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {repositories.map((repo) => (
            <div
              key={repo.id}
              className="p-5 bg-zinc-900 border border-zinc-800 rounded-lg hover:border-zinc-700 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2">
                    <FolderGit2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span className="font-bold text-zinc-100 text-sm truncate" title={repo.name}>
                      {repo.name}
                    </span>
                  </div>
                  <span className="px-2 py-0.5 text-[10px] font-mono bg-zinc-950 text-zinc-400 border border-zinc-800 rounded uppercase">
                    {repo.source}
                  </span>
                </div>

                <div className="space-y-2 font-mono text-xs text-zinc-400 my-4">
                  <div className="flex justify-between">
                    <span className="text-zinc-500">Branch:</span>
                    <span className="text-zinc-300 font-semibold">{repo.branch || 'main'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-500">Scans Executed:</span>
                    <span className="text-zinc-300">{repo.scan_count || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-500">Open Findings:</span>
                    <span className="text-zinc-300 font-bold">{repo.total_issues ?? 0}</span>
                  </div>
                  <div className="flex justify-between items-center pt-2 border-t border-zinc-800">
                    <span className="text-zinc-500">Security Score:</span>
                    <ScoreGauge score={repo.last_security_score ?? null} size="sm" />
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-zinc-800/80 flex items-center justify-between gap-2">
                <button
                  onClick={() => onNavigateToRepo(repo.id)}
                  className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded text-xs font-semibold transition-colors"
                >
                  View Scans
                </button>

                <div className="flex items-center gap-1.5">
                  {repo.last_scan_id && (
                    <button
                      onClick={() => onNavigateToScan(repo.last_scan_id!)}
                      className="px-3 py-1.5 bg-emerald-950 hover:bg-emerald-900 border border-emerald-800 text-emerald-300 rounded text-xs font-semibold transition-colors"
                    >
                      Latest Scan
                    </button>
                  )}
                  <button
                    onClick={() => handleDelete(repo.id, repo.name)}
                    className="p-1.5 text-zinc-500 hover:text-rose-400 rounded transition-colors"
                    title="Delete Repository"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
