import React, { useState, useEffect } from 'react';
import {
  Shield,
  Upload,
  Play,
  RotateCw,
  FolderGit2,
  Bug,
  KeyRound,
  CheckCircle2,
  AlertTriangle,
  FileCode,
  ArrowUpRight,
  Sparkles,
  Layers,
  Check
} from 'lucide-react';
import { api } from '../api/client';
import { DashboardStats } from '../types';
import { ScoreGauge } from '../components/ScoreGauge';
import { SeverityBadge } from '../components/SeverityBadge';
import { useDemo } from '../contexts/DemoContext';

interface DashboardPageProps {
  onOpenUpload: () => void;
  onNavigateToScan: (scanId: string) => void;
  onNavigateToIssues: (severityFilter?: string) => void;
  onNavigateToRepo: (repoId: string) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  onOpenUpload,
  onNavigateToScan,
  onNavigateToIssues,
  onNavigateToRepo
}) => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { isDemoMode } = useDemo();

  const fetchStats = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await api.getStats();
      setStats(data);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch dashboard statistics.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center p-20 text-zinc-400">
        <RotateCw className="w-8 h-8 animate-spin text-emerald-500 mb-3" />
        <span className="text-xs font-mono tracking-wider">QUERYING SOC TELEMETRY...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 max-w-4xl mx-auto">
        <div className="p-4 bg-rose-950/50 border border-rose-800 rounded-lg text-rose-300 text-xs">
          <div className="font-bold mb-1">Database Query Error:</div>
          <div>{error}</div>
          <button
            onClick={fetchStats}
            className="mt-3 px-3 py-1.5 bg-rose-900 hover:bg-rose-800 text-white rounded font-semibold transition-colors"
          >
            Retry Connection
          </button>
        </div>
      </div>
    );
  }

  const hasScans = stats && stats.totalScans > 0;

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-6 font-sans w-full overflow-hidden">
      {/* Demo mode indicator banner */}
      {isDemoMode && (
        <div className="p-3 bg-amber-950/80 border border-amber-700/80 rounded-lg flex flex-wrap items-center justify-between gap-2 text-amber-200 text-xs font-mono">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
            <span className="font-bold uppercase tracking-wider">Synthetic Demo Data Mode Active</span>
          </div>
          <span className="text-amber-400/80 text-[11px]">Toggle in top bar to switch to real repository scanning</span>
        </div>
      )}

      {/* Main Stats Header Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Security Score Card */}
        <div className="p-5 bg-[#0c1017] border border-zinc-800/90 rounded-xl flex flex-col justify-between shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-semibold text-zinc-400 uppercase tracking-wider">
              Security Health
            </span>
            <Shield className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="my-2">
            {hasScans && stats?.securityScore !== null ? (
              <ScoreGauge score={stats.securityScore} size="md" />
            ) : (
              <div className="text-sm font-mono text-zinc-500 py-3">No scans yet</div>
            )}
          </div>
          <div className="text-[11px] text-zinc-500 font-mono">
            {hasScans ? 'Deterministic score across analyzed repos' : 'Awaiting first repository scan'}
          </div>
        </div>

        {/* Repositories & Scans Metrics */}
        <div className="p-5 bg-[#0c1017] border border-zinc-800/90 rounded-xl flex flex-col justify-between shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-semibold text-zinc-400 uppercase tracking-wider">
              Repositories &amp; Runs
            </span>
            <FolderGit2 className="w-4 h-4 text-sky-400" />
          </div>
          <div className="my-2 flex items-baseline gap-4">
            <div>
              <span className="text-3xl font-mono font-bold text-zinc-100">
                {stats?.totalRepositories || 0}
              </span>
              <span className="text-xs text-zinc-500 font-mono ml-1">Repos</span>
            </div>
            <div>
              <span className="text-3xl font-mono font-bold text-zinc-100">
                {stats?.totalScans || 0}
              </span>
              <span className="text-xs text-zinc-500 font-mono ml-1">Scans</span>
            </div>
          </div>
          <div className="text-[11px] text-zinc-500 font-mono">
            {stats?.completedScans || 0} completed security scans
          </div>
        </div>

        {/* Verified Vulnerabilities Card */}
        <div className="p-5 bg-[#0c1017] border border-zinc-800/90 rounded-xl flex flex-col justify-between shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-semibold text-zinc-400 uppercase tracking-wider">
              Total Findings
            </span>
            <Bug className="w-4 h-4 text-amber-400" />
          </div>
          <div className="my-2">
            <span className="text-3xl font-mono font-bold text-zinc-100">
              {stats?.findings.total || 0}
            </span>
            <span className="text-xs text-zinc-500 font-mono ml-2">verified findings</span>
          </div>
          <div className="flex items-center gap-2 text-[11px] font-mono text-zinc-400">
            <KeyRound className="w-3.5 h-3.5 text-amber-400" />
            <span>{stats?.findings.secrets || 0} exposed secrets</span>
          </div>
        </div>

        {/* Quick Scan Action Card */}
        <div className="p-5 bg-[#0c1017] border border-zinc-800/90 rounded-xl flex flex-col justify-between shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-semibold text-zinc-400 uppercase tracking-wider">
              Quick Actions
            </span>
            <Sparkles className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="my-2 space-y-2">
            <button
              onClick={onOpenUpload}
              className="w-full flex items-center justify-center gap-1.5 py-1.5 px-3 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded-md shadow-sm transition-colors cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Scan Source Archive</span>
            </button>
            <button
              onClick={async () => {
                const res = await api.scanTestProject();
                onNavigateToScan(res.scanId);
              }}
              className="w-full flex items-center justify-center gap-1.5 py-1.5 px-3 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 font-semibold text-xs rounded-md border border-zinc-700/80 transition-colors cursor-pointer"
            >
              <FileCode className="w-3.5 h-3.5 text-emerald-400" />
              <span>Scan Test Suite</span>
            </button>
          </div>
          <div className="text-[11px] text-zinc-500 font-mono text-center">
            Upload .zip or connect GitHub repo
          </div>
        </div>
      </div>

      {/* Severity Breakdown Bar */}
      {hasScans && (
        <div className="p-5 bg-[#0c1017] border border-zinc-800/90 rounded-xl space-y-3 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-zinc-300 uppercase tracking-wider">
              Vulnerability Severity Distribution
            </span>
            <button
              onClick={() => onNavigateToIssues()}
              className="text-xs font-mono text-emerald-400 hover:text-emerald-300 flex items-center gap-1 cursor-pointer transition-colors"
            >
              <span>Explore All Issues</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <button
              onClick={() => onNavigateToIssues('CRITICAL')}
              className="p-3.5 bg-zinc-950/80 border border-red-900/40 hover:border-red-700 rounded-lg text-left transition-colors cursor-pointer"
            >
              <div className="text-[11px] font-mono font-bold text-red-400 uppercase tracking-wider">Critical</div>
              <div className="text-2xl font-mono font-black text-red-300 mt-1">
                {stats?.findings.critical || 0}
              </div>
            </button>

            <button
              onClick={() => onNavigateToIssues('HIGH')}
              className="p-3.5 bg-zinc-950/80 border border-orange-900/40 hover:border-orange-700 rounded-lg text-left transition-colors cursor-pointer"
            >
              <div className="text-[11px] font-mono font-bold text-orange-400 uppercase tracking-wider">High</div>
              <div className="text-2xl font-mono font-black text-orange-300 mt-1">
                {stats?.findings.high || 0}
              </div>
            </button>

            <button
              onClick={() => onNavigateToIssues('MEDIUM')}
              className="p-3.5 bg-zinc-950/80 border border-amber-900/40 hover:border-amber-700 rounded-lg text-left transition-colors cursor-pointer"
            >
              <div className="text-[11px] font-mono font-bold text-amber-400 uppercase tracking-wider">Medium</div>
              <div className="text-2xl font-mono font-black text-amber-300 mt-1">
                {stats?.findings.medium || 0}
              </div>
            </button>

            <button
              onClick={() => onNavigateToIssues('LOW')}
              className="p-3.5 bg-zinc-950/80 border border-sky-900/40 hover:border-sky-700 rounded-lg text-left transition-colors cursor-pointer"
            >
              <div className="text-[11px] font-mono font-bold text-sky-400 uppercase tracking-wider">Low</div>
              <div className="text-2xl font-mono font-black text-sky-300 mt-1">
                {stats?.findings.low || 0}
              </div>
            </button>
          </div>
        </div>
      )}

      {/* Main Content: Recent Scans and Scanner Engines */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Scans Table */}
        <div className="lg:col-span-2 p-5 bg-[#0c1017] border border-zinc-800/90 rounded-xl space-y-4 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-zinc-300 uppercase tracking-wider">
              Recent Security Scans
            </span>
          </div>

          {!stats?.recentScans || stats.recentScans.length === 0 ? (
            <div className="p-8 text-center text-zinc-500 font-mono text-xs border border-dashed border-zinc-800 rounded-lg">
              No repositories scanned yet. Click "Scan Source Archive" to begin.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono text-xs">
                <thead>
                  <tr className="border-b border-zinc-800 text-zinc-500">
                    <th className="pb-2 font-medium">Repository</th>
                    <th className="pb-2 font-medium">Engine</th>
                    <th className="pb-2 font-medium">Status</th>
                    <th className="pb-2 font-medium">Findings</th>
                    <th className="pb-2 font-medium text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/60">
                  {stats.recentScans.map((scan) => (
                    <tr key={scan.id} className="hover:bg-zinc-900/40 transition-colors">
                      <td className="py-3 font-semibold text-zinc-200">
                        {scan.repo_name || 'archive.zip'}
                      </td>
                      <td className="py-3 text-zinc-400">
                        <span className="px-1.5 py-0.5 bg-zinc-900 rounded border border-zinc-800 text-[10px]">
                          {scan.scanner_type || 'TRI-ENGINE'}
                        </span>
                      </td>
                      <td className="py-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            scan.status === 'COMPLETED'
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                              : scan.status === 'RUNNING'
                              ? 'bg-sky-950 text-sky-400 border border-sky-800 animate-pulse'
                              : 'bg-zinc-900 text-zinc-400'
                          }`}
                        >
                          {scan.status}
                        </span>
                      </td>
                      <td className="py-3 font-bold text-zinc-300">
                        {scan.total_findings}
                      </td>
                      <td className="py-3 text-right">
                        <button
                          onClick={() => onNavigateToScan(scan.id)}
                          className="px-2.5 py-1 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white rounded border border-zinc-700 text-xs transition-colors cursor-pointer"
                        >
                          View Report
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Security Engine Health & CWE Categories */}
        <div className="p-5 bg-[#0c1017] border border-zinc-800/90 rounded-xl space-y-4 shadow-md">
          <div className="text-xs font-mono font-bold text-zinc-300 uppercase tracking-wider">
            Scanner Engine Status
          </div>

          <div className="space-y-2.5">
            <div className="p-3 bg-zinc-950/80 border border-zinc-800/80 rounded-lg flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span className="text-xs font-semibold text-zinc-200">Gitleaks Engine</span>
              </div>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
                ACTIVE
              </span>
            </div>

            <div className="p-3 bg-zinc-950/80 border border-zinc-800/80 rounded-lg flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span className="text-xs font-semibold text-zinc-200">Semgrep AST Engine</span>
              </div>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
                ACTIVE
              </span>
            </div>

            <div className="p-3 bg-zinc-950/80 border border-zinc-800/80 rounded-lg flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span className="text-xs font-semibold text-zinc-200">Bandit Python Engine</span>
              </div>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
                ACTIVE
              </span>
            </div>

            <div className="p-3 bg-zinc-950/80 border border-zinc-800/80 rounded-lg flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-xs font-semibold text-zinc-200">Gemini AI Security Copilot</span>
              </div>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
                READY
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
