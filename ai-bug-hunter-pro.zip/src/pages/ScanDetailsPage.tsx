import React, { useState, useEffect } from 'react';
import {
  Shield,
  ArrowLeft,
  Download,
  FileText,
  RotateCw,
  Clock,
  Terminal,
  TrendingUp,
  TrendingDown,
  Sparkles,
  AlertCircle,
  CheckCircle2,
  Package
} from 'lucide-react';
import { api } from '../api/client';
import { DetailedScan, Issue, Severity, IssueCategory } from '../types';
import { ScoreGauge } from '../components/ScoreGauge';
import { SeverityBadge } from '../components/SeverityBadge';
import { CategoryBadge } from '../components/CategoryBadge';
import { ScanPipelineTracker } from '../components/ScanPipelineTracker';

interface ScanDetailsPageProps {
  scanId: string;
  onBack: () => void;
  onNavigateToIssue: (issueId: string) => void;
  onNavigateToReport: (scanId: string) => void;
}

export const ScanDetailsPage: React.FC<ScanDetailsPageProps> = ({
  scanId,
  onBack,
  onNavigateToIssue,
  onNavigateToReport
}) => {
  const [scan, setScan] = useState<DetailedScan | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [selectedSeverity, setSelectedSeverity] = useState<string>('ALL');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'issues' | 'dependencies' | 'pipeline' | 'logs'>('issues');

  const fetchScan = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await api.getScanDetails(scanId);
      setScan(res.scan);
    } catch (err: any) {
      setError(err.message || 'Failed to load scan details');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchScan();
  }, [scanId]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center p-16 text-zinc-400">
        <RotateCw className="w-8 h-8 animate-spin text-emerald-500 mb-3" />
        <span className="text-xs font-mono">Loading static analysis audit results...</span>
      </div>
    );
  }

  if (error || !scan) {
    return (
      <div className="p-6 max-w-4xl mx-auto space-y-4">
        <button onClick={onBack} className="flex items-center gap-1 text-xs text-zinc-400 hover:text-zinc-200">
          <ArrowLeft className="w-4 h-4" /> Back to Scans
        </button>
        <div className="p-4 bg-rose-950/50 border border-rose-800 rounded-lg text-rose-300 text-xs">
          {error || 'Scan not found'}
        </div>
      </div>
    );
  }

  // Filter issues
  const filteredIssues = scan.issues.filter((issue) => {
    if (selectedSeverity !== 'ALL' && issue.severity !== selectedSeverity) return false;
    if (selectedCategory !== 'ALL' && issue.category !== selectedCategory) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = issue.title.toLowerCase().includes(q);
      const matchDesc = issue.description.toLowerCase().includes(q);
      const matchFile = issue.file_path.toLowerCase().includes(q);
      const matchCwe = (issue.cwe || '').toLowerCase().includes(q);
      if (!matchTitle && !matchDesc && !matchFile && !matchCwe) return false;
    }
    return true;
  });

  const criticalCount = scan.issues.filter(i => i.severity === 'CRITICAL').length;
  const highCount = scan.issues.filter(i => i.severity === 'HIGH').length;
  const mediumCount = scan.issues.filter(i => i.severity === 'MEDIUM').length;
  const lowCount = scan.issues.filter(i => i.severity === 'LOW').length;

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6 font-sans">
      {/* Top Breadcrumb & Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <button
            onClick={onBack}
            className="flex items-center gap-1 text-xs text-zinc-400 hover:text-zinc-200 font-mono mb-2 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Scans</span>
          </button>
          <div className="flex items-center gap-3">
            <h1 className="text-xl font-bold text-zinc-100">{scan.repo_name}</h1>
            <span className="px-2 py-0.5 text-xs font-mono bg-zinc-900 border border-zinc-800 text-zinc-400 rounded">
              {scan.commit_hash || 'main'}
            </span>
          </div>
          <p className="text-xs text-zinc-500 font-mono mt-1">
            Executed on {new Date(scan.started_at).toLocaleString()} • Duration: {scan.duration || 0}s • {scan.files_scanned} files analyzed
          </p>
        </div>

        {/* Header Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigateToReport(scan.id)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-200 text-xs font-semibold rounded transition-colors"
          >
            <FileText className="w-3.5 h-3.5 text-emerald-400" />
            <span>Audit Report</span>
          </button>
          <a
            href={`/api/reports/${scan.id}?format=markdown&download=true`}
            download
            className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-200 text-xs font-semibold rounded transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export MD</span>
          </a>
        </div>
      </div>

      {/* Overview Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Security Score */}
        <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-lg flex flex-col justify-between">
          <span className="text-xs font-mono text-zinc-400 uppercase font-semibold">Security Score</span>
          <div className="my-2">
            <ScoreGauge score={scan.security_score} size="md" />
          </div>
          <span className="text-[11px] text-zinc-500 font-mono">
            {scan.issues.length === 0 ? 'No vulnerabilities found' : `${scan.issues.length} total findings identified`}
          </span>
        </div>

        {/* Severity counts */}
        <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-lg flex flex-col justify-between">
          <span className="text-xs font-mono text-zinc-400 uppercase font-semibold">Severity Breakdown</span>
          <div className="my-1 grid grid-cols-2 gap-2 text-xs font-mono">
            <div className="text-rose-400 font-bold">{criticalCount} Critical</div>
            <div className="text-orange-400 font-bold">{highCount} High</div>
            <div className="text-amber-400 font-bold">{mediumCount} Medium</div>
            <div className="text-blue-400 font-bold">{lowCount} Low</div>
          </div>
          <span className="text-[11px] text-zinc-500 font-mono">Real deterministic rule matches</span>
        </div>

        {/* Workspace metrics */}
        <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-lg flex flex-col justify-between">
          <span className="text-xs font-mono text-zinc-400 uppercase font-semibold">Workspace Metrics</span>
          <div className="my-1 font-mono text-xs space-y-1">
            <div className="text-zinc-200">{scan.files_scanned} Source Files</div>
            <div className="text-zinc-400">{scan.lines_scanned} Total Lines</div>
          </div>
          <span className="text-[11px] text-zinc-500 font-mono">Status: {scan.status}</span>
        </div>

        {/* Comparison Diff if available */}
        <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-lg flex flex-col justify-between">
          <span className="text-xs font-mono text-zinc-400 uppercase font-semibold">Historical Comparison</span>
          {scan.comparison ? (
            <div className="my-1 font-mono text-xs space-y-1">
              <div className="flex items-center gap-1.5">
                {scan.comparison.scoreDelta >= 0 ? (
                  <TrendingUp className="w-4 h-4 text-emerald-400" />
                ) : (
                  <TrendingDown className="w-4 h-4 text-rose-400" />
                )}
                <span className={scan.comparison.scoreDelta >= 0 ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                  {scan.comparison.scoreDelta >= 0 ? `+${scan.comparison.scoreDelta}` : scan.comparison.scoreDelta} Score
                </span>
              </div>
              <div className="text-[11px] text-zinc-400">
                {scan.comparison.fixedIssuesCount} fixed • {scan.comparison.newIssuesCount} new
              </div>
            </div>
          ) : (
            <div className="text-xs font-mono text-zinc-500 my-2">Initial Baseline Scan</div>
          )}
          <span className="text-[11px] text-zinc-500 font-mono">Repository branch tracking</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-zinc-800 space-x-4 font-mono text-xs overflow-x-auto no-scrollbar w-full min-w-0">
        <button
          onClick={() => setActiveTab('issues')}
          className={`pb-2.5 font-bold transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
            activeTab === 'issues' ? 'text-emerald-400 border-b-2 border-emerald-400' : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          Verified Issues ({scan.issues.length})
        </button>
        <button
          onClick={() => setActiveTab('dependencies')}
          className={`pb-2.5 font-bold transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
            activeTab === 'dependencies' ? 'text-emerald-400 border-b-2 border-emerald-400' : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          Vulnerable Dependencies ({scan.dependencies.length})
        </button>
        <button
          onClick={() => setActiveTab('pipeline')}
          className={`pb-2.5 font-bold transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
            activeTab === 'pipeline' ? 'text-emerald-400 border-b-2 border-emerald-400' : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          Scanner Pipeline ({scan.scanners_executed.length} Engines)
        </button>
        <button
          onClick={() => setActiveTab('logs')}
          className={`pb-2.5 font-bold transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
            activeTab === 'logs' ? 'text-emerald-400 border-b-2 border-emerald-400' : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          Scan Logs ({scan.logs.length})
        </button>
      </div>

      {/* TAB 1: ISSUES LIST */}
      {activeTab === 'issues' && (
        <div className="space-y-4 w-full min-w-0">
          {/* Filters Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-zinc-900 border border-zinc-800 rounded-lg">
            <div className="flex flex-wrap items-center gap-2">
              {/* Severity filter */}
              <select
                value={selectedSeverity}
                onChange={(e) => setSelectedSeverity(e.target.value)}
                className="px-2.5 py-1.5 bg-zinc-950 border border-zinc-800 rounded text-xs font-mono text-zinc-300 focus:outline-none focus:border-zinc-600"
              >
                <option value="ALL">All Severities</option>
                <option value="CRITICAL">Critical</option>
                <option value="HIGH">High</option>
                <option value="MEDIUM">Medium</option>
                <option value="LOW">Low</option>
                <option value="INFO">Info</option>
              </select>

              {/* Category filter */}
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-2.5 py-1.5 bg-zinc-950 border border-zinc-800 rounded text-xs font-mono text-zinc-300 focus:outline-none focus:border-zinc-600"
              >
                <option value="ALL">All Categories</option>
                <option value="Injection">Injection</option>
                <option value="Secrets">Secrets</option>
                <option value="Authentication">Authentication</option>
                <option value="Cryptography">Cryptography</option>
                <option value="Dependencies">Dependencies</option>
                <option value="Code Quality">Code Quality</option>
              </select>
            </div>

            {/* Search */}
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search title, file, or CWE..."
              className="px-3 py-1.5 bg-zinc-950 border border-zinc-800 rounded text-xs font-mono text-zinc-200 placeholder-zinc-600 focus:outline-none focus:border-zinc-600 w-full sm:w-64"
            />
          </div>

          {/* Issues table / cards */}
          {filteredIssues.length === 0 ? (
            <div className="p-12 text-center bg-zinc-900 border border-zinc-800 rounded-lg">
              <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
              <h3 className="text-sm font-bold text-zinc-200">No issues matching filters</h3>
              <p className="text-xs text-zinc-500 mt-1 font-mono">
                {scan.issues.length === 0 ? 'Clean scan — static analyzers found 0 vulnerabilities.' : 'Try adjusting filter criteria.'}
              </p>
            </div>
          ) : (
            <div className="space-y-3 w-full min-w-0">
              {filteredIssues.map((issue) => (
                <div
                  key={issue.id}
                  className="p-4 bg-zinc-900 border border-zinc-800 rounded-lg hover:border-zinc-700 transition-colors flex flex-col md:flex-row items-start md:items-center justify-between gap-4 w-full min-w-0 max-w-full overflow-hidden"
                >
                  <div className="space-y-2 flex-1 min-w-0 w-full">
                    <div className="flex flex-wrap items-center gap-2">
                      <SeverityBadge severity={issue.severity} size="sm" />
                      <CategoryBadge category={issue.category} />
                      <span className="px-2 py-0.5 text-[10px] font-mono bg-zinc-950 text-zinc-400 border border-zinc-800 rounded shrink-0">
                        {issue.scanner}
                      </span>
                      {issue.cwe && (
                        <span className="text-[10px] font-mono text-zinc-500 break-all">
                          {issue.cwe}
                        </span>
                      )}
                    </div>

                    <h3 className="text-sm font-bold text-zinc-100 [overflow-wrap:anywhere] break-words">
                      {issue.title}
                    </h3>

                    <div className="font-mono text-xs text-zinc-400 min-w-0 max-w-full">
                      <span className="text-zinc-500">Location: </span>
                      <span className="text-emerald-400/90 [overflow-wrap:anywhere] break-all">{issue.file_path}</span>
                      <span className="text-zinc-500">:{issue.line_number}</span>
                    </div>

                    <p className="text-xs text-zinc-400 [overflow-wrap:anywhere] break-words">
                      {issue.description}
                    </p>
                  </div>

                  <div className="flex flex-col sm:flex-row items-end sm:items-center gap-2 shrink-0 self-end md:self-center">
                    <button
                      onClick={() => onNavigateToIssue(issue.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-100 text-xs font-semibold rounded transition-colors whitespace-nowrap"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Inspect &amp; Fix</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: VULNERABLE DEPENDENCIES */}
      {activeTab === 'dependencies' && (
        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5">
          <h3 className="text-xs font-mono font-bold text-zinc-300 uppercase tracking-wider mb-3">
            Package Manifest Vulnerabilities
          </h3>
          {scan.dependencies.length === 0 ? (
            <div className="p-8 text-center text-zinc-500 font-mono text-xs">
              No vulnerable dependencies detected in package.json or requirements.txt.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono text-xs">
                <thead>
                  <tr className="text-zinc-500 border-b border-zinc-800 pb-2">
                    <th className="py-2 pr-4 font-semibold">Package</th>
                    <th className="py-2 pr-4 font-semibold">Installed Version</th>
                    <th className="py-2 pr-4 font-semibold">Severity</th>
                    <th className="py-2 pr-4 font-semibold">Known Vulnerability</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800">
                  {scan.dependencies.map((dep) => (
                    <tr key={dep.id}>
                      <td className="py-2.5 pr-4 font-bold text-zinc-200">{dep.package_name}</td>
                      <td className="py-2.5 pr-4 text-zinc-400">{dep.version}</td>
                      <td className="py-2.5 pr-4">
                        <SeverityBadge severity={dep.severity} size="sm" />
                      </td>
                      <td className="py-2.5 pr-4 text-zinc-300">{dep.vulnerability}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: PIPELINE TRACKER */}
      {activeTab === 'pipeline' && (
        <ScanPipelineTracker
          status={scan.status}
          scannersExecuted={scan.scanners_executed}
          filesCount={scan.files_scanned}
          linesCount={scan.lines_scanned}
        />
      )}

      {/* TAB 4: SCAN LOGS */}
      {activeTab === 'logs' && (
        <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-4 font-mono text-xs">
          <div className="flex items-center gap-2 pb-2 mb-3 border-b border-zinc-800 text-zinc-400">
            <Terminal className="w-4 h-4 text-emerald-400" />
            <span className="font-bold uppercase tracking-wider">Static Analysis Execution Logs</span>
          </div>
          <div className="max-h-96 overflow-y-auto space-y-1 text-zinc-300">
            {scan.logs.map((log) => (
              <div key={log.id} className="flex items-start gap-3">
                <span className="text-zinc-600 shrink-0">
                  {new Date(log.timestamp).toLocaleTimeString()}
                </span>
                <span
                  className={`px-1 rounded text-[10px] font-bold shrink-0 ${
                    log.level === 'ERROR'
                      ? 'bg-rose-950 text-rose-400'
                      : log.level === 'WARN'
                      ? 'bg-amber-950 text-amber-400'
                      : 'bg-zinc-900 text-zinc-400'
                  }`}
                >
                  {log.level}
                </span>
                <span className="break-all">{log.message}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
