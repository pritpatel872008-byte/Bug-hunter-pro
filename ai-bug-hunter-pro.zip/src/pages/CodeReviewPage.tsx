import React, { useState } from 'react';
import { Sparkles, Code2, RotateCw, AlertTriangle, CheckCircle2, Shield, Zap, Wrench, Bug } from 'lucide-react';
import { api } from '../api/client';
import { SeverityBadge } from '../components/SeverityBadge';

export const CodeReviewPage: React.FC = () => {
  const [filePath, setFilePath] = useState('user_controller.ts');
  const [language, setLanguage] = useState('TypeScript');
  const [codeContent, setCodeContent] = useState(`// Paste or edit code to review
import { Request, Response } from 'express';
import db from './database';

export async function getUserProfile(req: Request, res: Response) {
  const userId = req.query.id;
  // Dynamic SQL string query
  const query = "SELECT * FROM users WHERE id = " + userId;
  const user = await db.query(query);
  res.json(user);
}`);

  const [loading, setLoading] = useState(false);
  const [reviewResult, setReviewResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const sampleSnippets: Record<string, { lang: string; path: string; code: string }> = {
    'SQL Injection & SSRF (Node.js)': {
      lang: 'TypeScript',
      path: 'src/services/data_fetcher.ts',
      code: `import axios from 'axios';
import { db } from './db';

export async function processUserWebhook(reqUrl: string, userId: string) {
  // SSRF Risk: unvalidated URL
  const webhookResp = await axios.post(reqUrl, { event: 'ping' });
  
  // SQLi Risk: direct interpolation
  const sql = \`UPDATE webhooks SET last_status = '\${webhookResp.status}' WHERE user_id = \${userId}\`;
  await db.query(sql);
}`
    },
    'Insecure Deserialization & OS Exec (Python)': {
      lang: 'Python',
      path: 'services/worker.py',
      code: `import os
import pickle

def handle_job(raw_payload: bytes):
    # Insecure pickle deserialization
    data = pickle.loads(raw_payload)
    command = data.get("cmd", "echo done")
    # Command injection vulnerability
    os.system(command)
`
    }
  };

  const handleRunReview = async () => {
    if (!codeContent.trim()) {
      setError('Please paste or write source code to review.');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const res = await api.reviewCode({
        filePath,
        language,
        codeContent
      });
      setReviewResult(res.review);
    } catch (err: any) {
      setError(err.message || 'AI code review service is currently unavailable.');
    } finally {
      setLoading(false);
    }
  };

  const loadSample = (name: string) => {
    const sample = sampleSnippets[name];
    if (sample) {
      setLanguage(sample.lang);
      setFilePath(sample.path);
      setCodeContent(sample.code);
      setReviewResult(null);
      setError(null);
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6 font-sans">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-zinc-100">AI Code Review Workspace</h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Real-time multi-dimensional architectural, security, and performance analysis via Gemini AI
          </p>
        </div>

        <div className="flex items-center gap-2">
          {Object.keys(sampleSnippets).map((name) => (
            <button
              key={name}
              onClick={() => loadSample(name)}
              className="px-2.5 py-1 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 text-xs font-mono rounded transition-colors"
            >
              {name}
            </button>
          ))}
        </div>
      </div>

      {/* Editor & Parameters */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Column: Code Input */}
        <div className="space-y-3 flex flex-col">
          <div className="flex items-center gap-3">
            <div className="flex-1">
              <label className="block text-xs font-mono font-semibold text-zinc-400 mb-1">
                Virtual File Path
              </label>
              <input
                type="text"
                value={filePath}
                onChange={(e) => setFilePath(e.target.value)}
                className="w-full px-3 py-1.5 bg-zinc-900 border border-zinc-800 rounded font-mono text-xs text-zinc-200 focus:outline-none focus:border-zinc-600"
              />
            </div>
            <div className="w-40">
              <label className="block text-xs font-mono font-semibold text-zinc-400 mb-1">
                Language
              </label>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="w-full px-3 py-1.5 bg-zinc-900 border border-zinc-800 rounded font-mono text-xs text-zinc-200 focus:outline-none focus:border-zinc-600"
              >
                <option value="TypeScript">TypeScript</option>
                <option value="JavaScript">JavaScript</option>
                <option value="Python">Python</option>
                <option value="Java">Java</option>
                <option value="Go">Go</option>
                <option value="Rust">Rust</option>
                <option value="C++">C++</option>
              </select>
            </div>
          </div>

          <div className="flex-1 min-h-[350px] border border-zinc-800 rounded-lg overflow-hidden bg-zinc-950 flex flex-col">
            <div className="px-3 py-2 bg-zinc-900 border-b border-zinc-800 text-xs font-mono text-zinc-400 flex items-center justify-between">
              <span>Source Editor</span>
              <span>{codeContent.split('\n').length} lines</span>
            </div>
            <textarea
              value={codeContent}
              onChange={(e) => setCodeContent(e.target.value)}
              placeholder="Paste raw source code here to review..."
              className="flex-1 w-full p-4 bg-transparent font-mono text-xs text-zinc-200 resize-none focus:outline-none leading-relaxed"
            />
          </div>

          <button
            onClick={handleRunReview}
            disabled={loading}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold text-xs rounded transition-colors"
          >
            {loading ? (
              <>
                <RotateCw className="w-4 h-4 animate-spin" />
                <span>Auditing Code Posture with Gemini...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Execute Deep Code Review</span>
              </>
            )}
          </button>

          {error && (
            <div className="p-3 bg-rose-950/50 border border-rose-800 rounded text-rose-300 text-xs">
              {error}
            </div>
          )}
        </div>

        {/* Right Column: AI Review Results */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-5 flex flex-col justify-between overflow-y-auto max-h-[600px]">
          {!reviewResult ? (
            <div className="flex flex-col items-center justify-center h-full text-center text-zinc-500 py-16 space-y-3">
              <Code2 className="w-12 h-12 text-zinc-700 mx-auto" />
              <div className="text-sm font-semibold text-zinc-400">No review executed yet</div>
              <p className="text-xs max-w-xs mx-auto">
                Paste your code snippet on the left and click "Execute Deep Code Review" to generate an audit.
              </p>
            </div>
          ) : (
            <div className="space-y-6 text-xs">
              {/* Score & Summary */}
              <div className="flex items-center justify-between p-4 bg-zinc-950 border border-zinc-800 rounded-lg">
                <div>
                  <div className="font-mono text-zinc-500 text-[11px] uppercase">Overall Quality Score</div>
                  <div className="text-3xl font-mono font-black text-emerald-400 mt-0.5">
                    {reviewResult.overallScore}/100
                  </div>
                </div>
                <div className="max-w-xs text-right text-zinc-300 font-sans text-xs">
                  {reviewResult.summary}
                </div>
              </div>

              {/* Findings */}
              <div className="space-y-3">
                <h3 className="font-mono font-bold text-zinc-300 uppercase tracking-wider text-xs">
                  Auditor Findings ({reviewResult.findings?.length || 0})
                </h3>

                {reviewResult.findings?.map((finding: any, idx: number) => (
                  <div
                    key={idx}
                    className="p-3 bg-zinc-950 border border-zinc-800 rounded-md space-y-1.5 font-sans"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <SeverityBadge severity={finding.severity} size="sm" />
                        <span className="font-mono text-[11px] text-zinc-400 bg-zinc-900 px-1.5 py-0.5 rounded border border-zinc-800">
                          {finding.category}
                        </span>
                      </div>
                      {finding.line && (
                        <span className="font-mono text-zinc-500 text-[11px]">
                          Line {finding.line}
                        </span>
                      )}
                    </div>

                    <div className="font-bold text-zinc-200">{finding.title}</div>
                    <p className="text-zinc-400 leading-relaxed">{finding.description}</p>
                    <div className="pt-1 text-emerald-400 text-[11px]">
                      <span className="font-semibold text-zinc-500">Recommendation: </span>
                      {finding.recommendation}
                    </div>
                  </div>
                ))}
              </div>

              {/* Strengths & Recommendations */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-zinc-800">
                {reviewResult.strengths && reviewResult.strengths.length > 0 && (
                  <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-md space-y-1">
                    <span className="font-mono font-bold text-emerald-400 text-[11px] uppercase">
                      Code Strengths
                    </span>
                    <ul className="list-disc list-inside text-zinc-400 space-y-1">
                      {reviewResult.strengths.map((s: string, idx: number) => (
                        <li key={idx}>{s}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {reviewResult.recommendations && reviewResult.recommendations.length > 0 && (
                  <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-md space-y-1">
                    <span className="font-mono font-bold text-sky-400 text-[11px] uppercase">
                      General Advice
                    </span>
                    <ul className="list-disc list-inside text-zinc-400 space-y-1">
                      {reviewResult.recommendations.map((r: string, idx: number) => (
                        <li key={idx}>{r}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
