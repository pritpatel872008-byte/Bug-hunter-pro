import React, { useState, useEffect } from 'react';
import { Shield, RotateCw, Play, Filter, Clock } from 'lucide-react';
import { api } from '../api/client';
import { Scan } from '../types';
import { ScoreGauge } from '../components/ScoreGauge';

interface ScansPageProps {
  onOpenUpload: () => void;
  onNavigateToScan: (scanId: string) => void;
}

export const ScansPage: React.FC<ScansPageProps> = ({ onOpenUpload, onNavigateToScan }) => {
  const [scans, setScans] = useState<Scan[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchScans = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await api.getScans();
      setScans(res.scans);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch scans');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchScans();
  }, []);

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6 font-sans">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-zinc-100">Security Scans</h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Audit history, static analysis runs, and scan comparison records
          </p>
        </div>
        <button
          onClick={onOpenUpload}
          className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded transition-colors"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span>New Scan</span>
        </button>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center p-16 text-zinc-400">
          <RotateCw className="w-6 h-6 animate-spin text-emerald-500 mb-2" />
          <span className="text-xs font-mono">Loading scan history...</span>
        </div>
      ) : error ? (
        <div className="p-4 bg-rose-950/50 border border-rose-800 rounded-lg text-rose-300 text-xs">
          {error}
        </div>
      ) : scans.length === 0 ? (
        <div className="p-12 text-center bg-zinc-900 border border-zinc-800 rounded-lg space-y-4">
          <Shield className="w-12 h-12 text-zinc-600 mx-auto" />
          <div>
            <h3 className="text-sm font-bold text-zinc-200">No scans executed yet</h3>
            <p className="text-xs text-zinc-500 mt-1 max-w-md mx-auto">
              Execute a static scan on your codebase to populate historical vulnerability reports.
            </p>
          </div>
          <button
            onClick={onOpenUpload}
            className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded transition-colors"
          >
            <span>Run First Scan</span>
          </button>
        </div>
      ) : (
        <div className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-xs">
              <thead className="bg-zinc-950/80 text-zinc-400 border-b border-zinc-800">
                <tr>
                  <th className="py-3 px-4 font-semibold">Repository</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                  <th className="py-3 px-4 font-semibold">Security Score</th>
                  <th className="py-3 px-4 font-semibold">Findings</th>
                  <th className="py-3 px-4 font-semibold">Files / Lines</th>
                  <th className="py-3 px-4 font-semibold">Duration</th>
                  <th className="py-3 px-4 font-semibold">Date</th>
                  <th className="py-3 px-4 text-right font-semibold">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800">
                {scans.map((scan) => (
                  <tr key={scan.id} className="hover:bg-zinc-800/30 transition-colors">
                    <td className="py-3 px-4 font-sans font-bold text-zinc-200">
                      <div className="truncate max-w-[200px]">{scan.repo_name}</div>
                      <span className="text-[10px] text-zinc-500 font-mono">
                        {scan.commit_hash || 'main'}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-2 py-0.5 text-[10px] font-bold rounded uppercase ${
                          scan.status === 'COMPLETED'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                            : scan.status === 'RUNNING'
                            ? 'bg-sky-950 text-sky-400 border border-sky-800 animate-pulse'
                            : 'bg-rose-950 text-rose-400 border border-rose-800'
                        }`}
                      >
                        {scan.status}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <ScoreGauge score={scan.security_score} size="sm" />
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-zinc-200">{scan.issues_count ?? 0}</span>
                        {scan.critical_count ? (
                          <span className="px-1.5 py-0.2 bg-rose-950 text-rose-300 border border-rose-800 text-[10px] rounded">
                            {scan.critical_count} crit
                          </span>
                        ) : null}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-zinc-400 text-[11px]">
                      {scan.files_scanned} files <span className="text-zinc-600">({scan.lines_scanned} lines)</span>
                    </td>
                    <td className="py-3 px-4 text-zinc-400 text-[11px]">
                      {scan.duration ? `${scan.duration}s` : '—'}
                    </td>
                    <td className="py-3 px-4 text-zinc-500 text-[11px]">
                      {new Date(scan.started_at).toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => onNavigateToScan(scan.id)}
                        className="px-3 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded text-xs font-semibold transition-colors"
                      >
                        View Report
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
