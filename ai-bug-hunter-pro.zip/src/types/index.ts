export type Severity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';
export type Confidence = 'HIGH' | 'MEDIUM' | 'LOW';
export type IssueCategory =
  | 'Injection'
  | 'Authentication'
  | 'Secrets'
  | 'Cryptography'
  | 'Dependencies'
  | 'Code Quality';

export interface User {
  id: string;
  name: string;
  email: string;
}

export interface Repository {
  id: string;
  name: string;
  source: 'upload' | 'github' | 'test-project' | 'demo';
  url?: string;
  branch?: string;
  created_at: string;
  scan_count?: number;
  last_security_score?: number;
  last_scan_status?: 'QUEUED' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'CANCELLED';
  last_scan_date?: string;
  last_scan_id?: string;
  total_issues?: number;
}

export interface ScannerStatus {
  name: string;
  status: 'COMPLETED' | 'RUNNING' | 'FAILED' | 'NOT_APPLICABLE' | 'UNAVAILABLE';
  findingsCount: number;
  durationMs: number;
  message?: string;
}

export interface Scan {
  id: string;
  repository_id: string;
  repo_name?: string;
  repo_source?: string;
  repo_branch?: string;
  commit_hash?: string;
  status: 'QUEUED' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'CANCELLED';
  security_score: number;
  files_scanned: number;
  lines_scanned: number;
  scanners_executed: ScannerStatus[];
  started_at: string;
  completed_at?: string;
  duration?: number;
  error_message?: string;
  is_demo?: number;
  issues_count?: number;
  critical_count?: number;
  high_count?: number;
  medium_count?: number;
  low_count?: number;
}

export interface Issue {
  id: string;
  scan_id: string;
  repository_id?: string;
  repo_name?: string;
  scan_date?: string;
  severity: Severity;
  confidence: Confidence;
  category: IssueCategory;
  title: string;
  description: string;
  file_path: string;
  line_number: number;
  code_snippet: string;
  scanner: string;
  cwe?: string;
  recommendation: string;
  status: 'OPEN' | 'CONFIRMED' | 'RESOLVED' | 'FALSE_POSITIVE';
  created_at: string;
  ai_analysis_id?: string;
  ai_explanation?: string;
  ai_impact?: string;
  ai_fix?: string;
  ai_tests?: string;
}

export interface Dependency {
  id: string;
  scan_id: string;
  package_name: string;
  version: string;
  severity: Severity;
  vulnerability: string;
}

export interface ScanLog {
  id: string;
  scan_id: string;
  message: string;
  level: 'INFO' | 'WARN' | 'ERROR';
  timestamp: string;
}

export interface ScanComparison {
  scoreDelta: number;
  previousScore: number;
  currentScore: number;
  newIssuesCount: number;
  fixedIssuesCount: number;
  unresolvedCount: number;
  newIssues: Issue[];
  fixedIssues: Issue[];
}

export interface DetailedScan extends Scan {
  issues: Issue[];
  dependencies: Dependency[];
  logs: ScanLog[];
  comparison?: ScanComparison | null;
}

export interface DashboardStats {
  hasData: boolean;
  totalRepositories: number;
  totalScans: number;
  completedScans: number;
  securityScore: number | null;
  findings: {
    total: number;
    critical: number;
    high: number;
    medium: number;
    low: number;
    info: number;
    secrets: number;
  };
  recentScans: Scan[];
  scannerStatuses: {
    name: string;
    status: string;
    description: string;
  }[];
}
