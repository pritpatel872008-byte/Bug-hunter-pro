import React from 'react';
import { CheckCircle2, AlertTriangle, XCircle, Clock, ShieldCheck } from 'lucide-react';
import { ScannerStatus } from '../types';

interface ScanPipelineTrackerProps {
  status: 'QUEUED' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'CANCELLED';
  scannersExecuted: ScannerStatus[];
  filesCount?: number;
  linesCount?: number;
}

export const ScanPipelineTracker: React.FC<ScanPipelineTrackerProps> = ({
  status,
  scannersExecuted,
  filesCount = 0,
  linesCount = 0
}) => {
  const steps = [
    {
      name: 'Repository Sandbox Prep',
      isCompleted: status === 'COMPLETED' || status === 'RUNNING' || filesCount > 0,
      detail: 'Safe archive extraction and path traversal checks'
    },
    {
      name: 'Source File & Language Discovery',
      isCompleted: status === 'COMPLETED' || (status === 'RUNNING' && filesCount > 0),
      detail: `${filesCount} source files identified (${linesCount} lines total)`
    }
  ];

  return (
    <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-lg space-y-4 font-mono text-xs">
      <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span className="font-bold text-zinc-200 uppercase tracking-wider text-xs">
            Static Analysis Pipeline
          </span>
        </div>
        <span
          className={`px-2 py-0.5 rounded-sm font-semibold uppercase text-[11px] ${
            status === 'COMPLETED'
              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
              : status === 'RUNNING'
              ? 'bg-sky-950 text-sky-400 border border-sky-800 animate-pulse'
              : status === 'FAILED'
              ? 'bg-rose-950 text-rose-400 border border-rose-800'
              : 'bg-zinc-800 text-zinc-400'
          }`}
        >
          {status}
        </span>
      </div>

      {/* Pre-scan steps */}
      <div className="space-y-2">
        {steps.map((step, idx) => (
          <div key={idx} className="flex items-center gap-2.5">
            {step.isCompleted ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : status === 'RUNNING' ? (
              <Clock className="w-4 h-4 text-sky-400 animate-spin shrink-0" />
            ) : (
              <div className="w-4 h-4 rounded-full border border-zinc-600 shrink-0" />
            )}
            <div className="flex flex-col">
              <span className="font-semibold text-zinc-200">{step.name}</span>
              <span className="text-[11px] text-zinc-500 font-sans">{step.detail}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Individual Scanner Executions */}
      <div className="pt-2 border-t border-zinc-800/80 space-y-2">
        <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider block">
          Scanner Engine Executions:
        </span>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {scannersExecuted.map((scanner, idx) => {
            const isDone = scanner.status === 'COMPLETED';
            const isNotApplicable = scanner.status === 'NOT_APPLICABLE';
            const isFailed = scanner.status === 'FAILED';

            return (
              <div
                key={idx}
                className="flex items-center justify-between p-2 bg-zinc-950/80 border border-zinc-800 rounded-md"
              >
                <div className="flex items-center gap-2">
                  {isDone ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  ) : isNotApplicable ? (
                    <span className="text-zinc-500 text-[10px]">○</span>
                  ) : isFailed ? (
                    <XCircle className="w-3.5 h-3.5 text-rose-400" />
                  ) : (
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                  )}
                  <span className="font-bold text-zinc-300">{scanner.name}</span>
                </div>

                <div className="flex items-center gap-2 text-[11px]">
                  {isDone ? (
                    <span className="text-zinc-400">
                      {scanner.findingsCount} findings{' '}
                      <span className="text-zinc-600">({scanner.durationMs}ms)</span>
                    </span>
                  ) : (
                    <span className="text-zinc-500">{scanner.message || scanner.status}</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
