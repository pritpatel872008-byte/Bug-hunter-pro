import React, { useState, useRef } from 'react';
import { X, Upload, Github, Play, AlertCircle, Loader2, FileCode, RefreshCw, Shield } from 'lucide-react';
import { api, ApiError } from '../api/client';
import { useAuth } from '../contexts/AuthContext';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScanCompleted: (scanId: string) => void;
  onOpenAuth?: (mode: 'login' | 'register') => void;
}

export const UploadModal: React.FC<UploadModalProps> = ({
  isOpen,
  onClose,
  onScanCompleted,
  onOpenAuth
}) => {
  const { user } = useAuth();
  const [tab, setTab] = useState<'zip' | 'github' | 'test-suite'>('zip');
  const [file, setFile] = useState<File | null>(null);
  const [repoName, setRepoName] = useState('');
  const [branch, setBranch] = useState('');
  const [githubUrl, setGithubUrl] = useState('');
  const [githubToken, setGithubToken] = useState('');
  const [showTokenInput, setShowTokenInput] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorInfo, setErrorInfo] = useState<{ message: string; endpoint?: string; status?: number } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleZipUpload = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!user) {
      setErrorInfo({
        message: 'Please sign in or create an account to start repository scans and store findings.',
        status: 401
      });
      return;
    }
    if (!file) {
      setErrorInfo({ message: 'Please select a ZIP file to scan.' });
      return;
    }

    try {
      setLoading(true);
      setErrorInfo(null);
      const res = await api.uploadZip(file, repoName || undefined, branch || undefined);
      onScanCompleted(res.scanId);
      onClose();
    } catch (err: any) {
      console.error('[UploadModal Error]', err);
      if (err instanceof ApiError) {
        setErrorInfo({
          message: err.message,
          endpoint: err.endpoint,
          status: err.status
        });
      } else {
        setErrorInfo({
          message: err.message || 'Failed to upload and analyze archive.'
        });
      }
    } finally {
      setLoading(false);
    }
  };

  const handleGithubImport = async (e?: React.FormEvent, customUrl?: string) => {
    if (e) e.preventDefault();
    if (!user) {
      setErrorInfo({
        message: 'Please sign in or create an account to import and scan GitHub repositories.',
        status: 401
      });
      return;
    }
    const targetUrl = (customUrl || githubUrl).trim();
    if (!targetUrl) {
      setErrorInfo({ message: 'Please enter a valid GitHub repository URL or "owner/repo" shorthand.' });
      return;
    }

    try {
      setLoading(true);
      setErrorInfo(null);
      const res = await api.importGithub(
        targetUrl,
        branch.trim() || undefined,
        repoName.trim() || undefined,
        githubToken.trim() || undefined
      );
      onScanCompleted(res.scanId);
      onClose();
    } catch (err: any) {
      console.error('[Github Import Error]', err);
      if (err instanceof ApiError) {
        setErrorInfo({
          message: err.message,
          endpoint: err.endpoint,
          status: err.status
        });
        if (err.status === 404 || err.status === 403) {
          setShowTokenInput(true);
        }
      } else {
        setErrorInfo({
          message: err.message || 'Failed to import GitHub repository.'
        });
      }
    } finally {
      setLoading(false);
    }
  };

  const handleScanTestSuite = async () => {
    if (!user) {
      setErrorInfo({
        message: 'Please sign in or create an account to run the security test suite.',
        status: 401
      });
      return;
    }
    try {
      setLoading(true);
      setErrorInfo(null);
      const res = await api.scanTestProject();
      onScanCompleted(res.scanId);
      onClose();
    } catch (err: any) {
      console.error('[Test Suite Error]', err);
      if (err instanceof ApiError) {
        setErrorInfo({
          message: err.message,
          endpoint: err.endpoint,
          status: err.status
        });
      } else {
        setErrorInfo({
          message: err.message || 'Failed to trigger test suite scan.'
        });
      }
    } finally {
      setLoading(false);
    }
  };

  const loadSampleZip = async () => {
    try {
      setLoading(true);
      setErrorInfo(null);
      // Fetch the pre-bundled bug_hunter_test.zip
      const res = await fetch('/bug_hunter_test.zip');
      if (!res.ok) {
        throw new Error('Sample test ZIP not found on server.');
      }
      const blob = await res.blob();
      const testFile = new File([blob], 'bug_hunter_test.zip', { type: 'application/zip' });
      setFile(testFile);
      setRepoName('bug_hunter_test');
    } catch (err: any) {
      setErrorInfo({ message: `Could not load sample file: ${err.message}` });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="w-full max-w-xl bg-zinc-900 border border-zinc-800 rounded-lg shadow-2xl overflow-hidden font-sans">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800">
          <div>
            <h2 className="text-base font-bold text-zinc-100">Scan Repository</h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              Upload source code or connect a repository for static security analysis
            </p>
          </div>
          <button
            onClick={onClose}
            disabled={loading}
            className="p-1 text-zinc-400 hover:text-zinc-200 rounded transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab selection */}
        <div className="flex border-b border-zinc-800 bg-zinc-950/50 p-1">
          <button
            onClick={() => { setTab('zip'); setErrorInfo(null); }}
            className={`flex-1 flex items-center justify-center gap-2 py-2 text-xs font-semibold rounded-md transition-colors ${
              tab === 'zip' ? 'bg-zinc-800 text-zinc-100' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Upload className="w-4 h-4" />
            <span>ZIP Upload</span>
          </button>
          <button
            onClick={() => { setTab('github'); setErrorInfo(null); }}
            className={`flex-1 flex items-center justify-center gap-2 py-2 text-xs font-semibold rounded-md transition-colors ${
              tab === 'github' ? 'bg-zinc-800 text-zinc-100' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Github className="w-4 h-4" />
            <span>GitHub URL</span>
          </button>
          <button
            onClick={() => { setTab('test-suite'); setErrorInfo(null); }}
            className={`flex-1 flex items-center justify-center gap-2 py-2 text-xs font-semibold rounded-md transition-colors ${
              tab === 'test-suite' ? 'bg-zinc-800 text-emerald-300' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <FileCode className="w-4 h-4" />
            <span>Test Suite</span>
          </button>
        </div>

        {/* Guest Authentication Prompt Banner */}
        {!user && (
          <div className="mx-6 mt-4 p-3 bg-emerald-950/40 border border-emerald-800/60 rounded flex items-center justify-between gap-3 text-xs text-zinc-300">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Sign in to store and track your SAST scans and AI remediations.</span>
            </div>
            {onOpenAuth && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenAuth('login');
                }}
                className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded font-semibold shrink-0 cursor-pointer text-xs"
              >
                Sign In
              </button>
            )}
          </div>
        )}

        {/* Diagnostic Error Banner */}
        {errorInfo && (
          <div className="mx-6 mt-4 p-3.5 bg-rose-950/40 border border-rose-800/80 rounded text-xs space-y-2">
            <div className="flex items-start gap-2 text-rose-300">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <div className="flex-1 font-medium">{errorInfo.message}</div>
            </div>
            {errorInfo.endpoint && (
              <div className="text-[11px] text-zinc-400 bg-black/40 px-2.5 py-1.5 rounded font-mono break-all">
                Endpoint: <span className="text-zinc-300">{errorInfo.endpoint}</span>
                {errorInfo.status && <span className="ml-2 text-amber-400">(HTTP {errorInfo.status})</span>}
              </div>
            )}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-rose-900/40">
              <div className="flex items-center gap-2">
                {errorInfo.status === 401 && onOpenAuth && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenAuth('login');
                    }}
                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded font-semibold text-xs cursor-pointer"
                  >
                    Sign In to Continue
                  </button>
                )}
                {tab === 'github' && (
                  <>
                    <button
                      type="button"
                      onClick={() => {
                        setShowTokenInput(true);
                      }}
                      className="text-[11px] text-amber-300 hover:underline"
                    >
                      + Add GitHub Token
                    </button>
                    <span className="text-zinc-600">|</span>
                    <button
                      type="button"
                      onClick={() => {
                        setTab('zip');
                        setErrorInfo(null);
                      }}
                      className="text-[11px] text-zinc-300 hover:underline"
                    >
                      Upload ZIP instead
                    </button>
                  </>
                )}
              </div>
              <button
                type="button"
                onClick={() => {
                  if (tab === 'zip') handleZipUpload();
                  else if (tab === 'github') handleGithubImport();
                  else handleScanTestSuite();
                }}
                className="flex items-center gap-1.5 px-3 py-1 bg-rose-900/60 hover:bg-rose-900 border border-rose-700 text-rose-200 rounded text-xs transition-colors"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Retry</span>
              </button>
            </div>
          </div>
        )}

        {/* Tab contents */}
        <div className="p-6">
          {tab === 'zip' && (
            <form onSubmit={handleZipUpload} className="space-y-4">
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-zinc-700 hover:border-zinc-500 rounded-lg p-6 flex flex-col items-center justify-center cursor-pointer transition-colors bg-zinc-950/40"
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".zip"
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      setFile(e.target.files[0]);
                      if (!repoName) {
                        setRepoName(e.target.files[0].name.replace(/\.zip$/i, ''));
                      }
                      setErrorInfo(null);
                    }
                  }}
                  className="hidden"
                />
                <Upload className="w-8 h-8 text-zinc-400 mb-2" />
                <p className="text-sm font-semibold text-zinc-200">
                  {file ? file.name : 'Click or drop .zip file here'}
                </p>
                <p className="text-xs text-zinc-500 mt-1">
                  Supports up to 50MB. Safe sandbox extraction & AST analysis.
                </p>
              </div>

              {/* Helper button to quickly test with bug_hunter_test.zip */}
              {!file && (
                <div className="flex items-center justify-between px-3 py-2 bg-zinc-950 border border-zinc-800/80 rounded text-xs">
                  <span className="text-zinc-400">Want to test with sample vulnerabilities?</span>
                  <button
                    type="button"
                    onClick={loadSampleZip}
                    className="text-emerald-400 hover:text-emerald-300 font-semibold transition-colors"
                  >
                    Select bug_hunter_test.zip
                  </button>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1">Repository Name</label>
                  <input
                    type="text"
                    value={repoName}
                    onChange={(e) => setRepoName(e.target.value)}
                    placeholder="my-backend-app"
                    className="w-full px-3 py-2 text-xs bg-zinc-950 border border-zinc-800 rounded text-zinc-100 placeholder-zinc-600 focus:outline-none focus:border-zinc-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1">Branch</label>
                  <input
                    type="text"
                    value={branch}
                    onChange={(e) => setBranch(e.target.value)}
                    placeholder="main"
                    className="w-full px-3 py-2 text-xs bg-zinc-950 border border-zinc-800 rounded text-zinc-100 placeholder-zinc-600 focus:outline-none focus:border-zinc-600"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading || !file}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold text-xs rounded transition-colors"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Analyzing Source Code Pipeline...</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-current" />
                    <span>Start Static Analysis Scan</span>
                  </>
                )}
              </button>
            </form>
          )}

          {tab === 'github' && (
            <form onSubmit={handleGithubImport} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1">
                  GitHub Repository URL or Shorthand
                </label>
                <input
                  type="text"
                  value={githubUrl}
                  onChange={(e) => {
                    setGithubUrl(e.target.value);
                    setErrorInfo(null);
                  }}
                  placeholder="https://github.com/owner/repository or owner/repository"
                  className="w-full px-3 py-2 text-xs bg-zinc-950 border border-zinc-800 rounded text-zinc-100 placeholder-zinc-600 focus:outline-none focus:border-zinc-600"
                />
              </div>

              {/* Quick sample public repo presets */}
              <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
                <span className="text-zinc-500 font-medium">Quick test presets:</span>
                {[
                  { label: 'expressjs/express', url: 'https://github.com/expressjs/express' },
                  { label: 'facebook/react', url: 'https://github.com/facebook/react' },
                  { label: 'OWASP/NodeGoat', url: 'https://github.com/OWASP/NodeGoat' },
                  { label: 'fastify/fastify', url: 'https://github.com/fastify/fastify' }
                ].map((preset) => (
                  <button
                    key={preset.label}
                    type="button"
                    onClick={() => {
                      setGithubUrl(preset.url);
                      setRepoName(preset.label);
                      setErrorInfo(null);
                    }}
                    className="px-2 py-0.5 bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-emerald-300 rounded font-mono transition-colors"
                  >
                    {preset.label}
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1">Custom Name (Optional)</label>
                  <input
                    type="text"
                    value={repoName}
                    onChange={(e) => setRepoName(e.target.value)}
                    placeholder="e.g. backend-api"
                    className="w-full px-3 py-2 text-xs bg-zinc-950 border border-zinc-800 rounded text-zinc-100 placeholder-zinc-600 focus:outline-none focus:border-zinc-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1">
                    Branch <span className="text-zinc-500 font-normal">(optional, auto-detects)</span>
                  </label>
                  <input
                    type="text"
                    value={branch}
                    onChange={(e) => setBranch(e.target.value)}
                    placeholder="Auto (main / master / default)"
                    className="w-full px-3 py-2 text-xs bg-zinc-950 border border-zinc-800 rounded text-zinc-100 placeholder-zinc-600 focus:outline-none focus:border-zinc-600"
                  />
                </div>
              </div>

              {/* Collapsible GitHub Personal Access Token (for private repos or rate limits) */}
              <div className="pt-1">
                <button
                  type="button"
                  onClick={() => setShowTokenInput(!showTokenInput)}
                  className="text-[11px] text-zinc-400 hover:text-zinc-200 flex items-center gap-1 font-medium transition-colors"
                >
                  <span>{showTokenInput ? '− Hide' : '+ Add'} GitHub Personal Access Token (PAT)</span>
                  <span className="text-zinc-500 font-normal">— for private repos & higher rate limits</span>
                </button>

                {showTokenInput && (
                  <div className="mt-2 p-3 bg-zinc-950/80 border border-zinc-800/90 rounded space-y-1.5">
                    <label className="block text-[11px] font-semibold text-zinc-300">
                      GitHub Personal Access Token
                    </label>
                    <input
                      type="password"
                      value={githubToken}
                      onChange={(e) => setGithubToken(e.target.value)}
                      placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
                      className="w-full px-3 py-1.5 text-xs bg-zinc-900 border border-zinc-800 rounded text-zinc-100 placeholder-zinc-600 focus:outline-none focus:border-zinc-600 font-mono"
                    />
                    <p className="text-[10px] text-zinc-500">
                      Needs <code className="text-zinc-400">repo</code> scope for private repositories or <code className="text-zinc-400">public_repo</code>. Token is used only for this scan and not saved.
                    </p>
                  </div>
                )}
              </div>

              <button
                type="submit"
                disabled={loading || !githubUrl.trim()}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold text-xs rounded transition-colors"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Fetching & Scanning GitHub Repository...</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-current" />
                    <span>Import & Run Security Scan</span>
                  </>
                )}
              </button>
            </form>
          )}

          {tab === 'test-suite' && (
            <div className="space-y-4">
              <div className="p-4 bg-zinc-950 border border-zinc-800 rounded-lg">
                <h4 className="text-xs font-bold text-zinc-200 mb-1">
                  Bundled Security Vulnerability Test Suite
                </h4>
                <p className="text-xs text-zinc-400 leading-relaxed">
                  Analyze the built-in <code className="text-emerald-400">/test-project</code> directory containing real intentionally vulnerable code patterns: SQL Injection, Command Injection, Live AWS & Stripe Secrets, Weak MD5 Hashing, SSRF, and Vulnerable Dependencies.
                </p>
              </div>

              <button
                type="button"
                onClick={handleScanTestSuite}
                disabled={loading}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold text-xs rounded transition-colors"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Executing Test Suite SAST Pipeline...</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-current" />
                    <span>Scan Test Suite Now</span>
                  </>
                )}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
