import React, { useState } from 'react';
import {
  Shield,
  Plus,
  Search,
  Bell,
  Sparkles,
  ChevronDown,
  LayoutDashboard,
  FolderGit2,
  ScanSearch,
  Bug,
  Code2,
  Settings,
  Menu,
  X,
  User,
  LogOut,
  KeyRound,
  LogIn,
  UserPlus
} from 'lucide-react';
import { useDemo } from '../contexts/DemoContext';
import { useAuth } from '../contexts/AuthContext';
import { AuthMode } from './AuthModal';

interface TopBarProps {
  currentTab: string;
  onNavigate: (tab: string) => void;
  onOpenUpload: () => void;
  onOpenAuth: (mode: AuthMode) => void;
}

export const TopBar: React.FC<TopBarProps> = ({ currentTab, onNavigate, onOpenUpload, onOpenAuth }) => {
  const { isDemoMode, toggleDemoMode } = useDemo();
  const { user, isAuthenticated, logout } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const navLinks = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'repositories', label: 'Repositories', icon: FolderGit2 },
    { id: 'scans', label: 'Scans', icon: ScanSearch },
    { id: 'issues', label: 'Findings', icon: Bug, count: 12 },
    { id: 'code-review', label: 'Code Review', icon: Code2, badge: 'AI' },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onNavigate('issues');
    }
  };

  const userInitials = user?.name
    ? user.name.split(' ').map((n) => n[0]).join('').substring(0, 2).toUpperCase()
    : 'U';

  return (
    <header className="sticky top-0 z-40 w-full bg-[#090d12]/95 backdrop-blur border-b border-zinc-800/80 shrink-0">
      {/* Primary Header Row */}
      <div className="px-3 sm:px-4 lg:px-6 py-2.5 flex items-center justify-between gap-2 sm:gap-4 max-w-7xl mx-auto w-full min-w-0">
        {/* Left: Brand Identity */}
        <div className="flex items-center gap-3 shrink-0 min-w-0">
          <button
            onClick={() => onNavigate('dashboard')}
            className="flex items-center gap-2 sm:gap-2.5 text-left group focus-visible:outline-none cursor-pointer"
          >
            <div className="w-8 h-8 rounded-lg bg-emerald-950/80 border border-emerald-700/80 flex items-center justify-center text-emerald-400 group-hover:border-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.2)] transition-all shrink-0">
              <Shield className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <div className="text-xs sm:text-sm font-bold tracking-wider font-mono text-zinc-100 flex items-center gap-1 sm:gap-1.5 whitespace-nowrap">
                <span>AI BUG</span>
                <span className="text-emerald-400">HUNTER PRO</span>
              </div>
              <div className="text-[10px] text-zinc-400 font-sans hidden sm:block truncate">
                Find Bugs. Detect Vulnerabilities. Fix Code Faster.
              </div>
            </div>
          </button>
        </div>

        {/* Center: Quick Search Bar (Hidden on mobile) */}
        <div className="hidden md:flex flex-1 max-w-xs lg:max-w-md mx-2 min-w-0">
          <form onSubmit={handleSearchSubmit} className="relative w-full">
            <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search findings, files, CWEs..."
              className="w-full pl-8 pr-12 py-1.5 bg-zinc-900/80 border border-zinc-800 rounded-md text-xs font-mono text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-zinc-700 transition-colors"
            />
            <kbd className="absolute right-2.5 top-2 px-1.5 py-0.5 text-[10px] font-mono text-zinc-400 bg-zinc-800 border border-zinc-700/80 rounded select-none">
              ⌘K
            </kbd>
          </form>
        </div>

        {/* Right: SOC Status, Actions, Profile */}
        <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
          {/* AI Ready Pulse Indicator */}
          <div className="hidden xl:flex items-center gap-1.5 px-2.5 py-1 bg-emerald-950/40 border border-emerald-800/60 rounded text-[11px] font-mono text-emerald-400 shrink-0">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-semibold">AI READY</span>
          </div>

          {/* Demo Mode Toggle */}
          <button
            onClick={toggleDemoMode}
            className={`hidden sm:flex items-center px-2 py-1 text-[11px] font-mono font-semibold rounded border whitespace-nowrap transition-colors focus-visible:outline-none cursor-pointer ${
              isDemoMode
                ? 'bg-amber-950/80 text-amber-300 border-amber-700'
                : 'bg-zinc-900 text-zinc-400 border-zinc-800 hover:text-zinc-200'
            }`}
            title="Toggle Demo Mode"
          >
            {isDemoMode ? 'DEMO ON' : 'DEMO OFF'}
          </button>

          {/* Primary Action Button */}
          <button
            onClick={onOpenUpload}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-md whitespace-nowrap shrink-0 transition-colors focus-visible:outline-none shadow-[0_0_12px_rgba(16,185,129,0.3)] cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden xs:inline">Scan Repository</span>
            <span className="xs:hidden">Scan</span>
          </button>

          {/* User Profile / Auth Area */}
          {user ? (
            <div className="relative pl-1 sm:pl-2 border-l border-zinc-800">
              <button
                onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                className="flex items-center gap-2 p-1 rounded-lg hover:bg-zinc-900 transition-colors cursor-pointer focus-visible:outline-none"
              >
                <div className="w-7 h-7 rounded-md bg-emerald-950/90 border border-emerald-700 text-[11px] font-bold text-emerald-300 font-mono flex items-center justify-center shrink-0">
                  {userInitials}
                </div>
                <div className="hidden lg:block text-left max-w-[120px]">
                  <div className="text-xs font-semibold text-zinc-200 truncate leading-tight">{user.name}</div>
                  <div className="text-[10px] text-zinc-400 font-mono leading-tight truncate">{user.email}</div>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-zinc-500 hidden sm:block" />
              </button>

              {/* User Dropdown */}
              {userDropdownOpen && (
                <div
                  className="absolute right-0 mt-2 w-56 bg-[#0c1017] border border-zinc-800 rounded-xl shadow-2xl py-2 z-50 font-sans text-xs"
                  onClick={() => setUserDropdownOpen(false)}
                >
                  <div className="px-3.5 py-2 border-b border-zinc-800">
                    <div className="font-bold text-zinc-200 truncate">{user.name}</div>
                    <div className="text-[11px] text-zinc-400 font-mono truncate">{user.email}</div>
                    <div className="mt-1 text-[10px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/80 px-1.5 py-0.5 rounded inline-block">
                      Tenant ID: {user.id.substring(0, 10)}...
                    </div>
                  </div>

                  <button
                    onClick={() => onNavigate('settings')}
                    className="w-full flex items-center gap-2 px-3.5 py-2 text-zinc-300 hover:text-zinc-100 hover:bg-zinc-800/60 transition-colors text-left cursor-pointer"
                  >
                    <Settings className="w-3.5 h-3.5 text-zinc-400" />
                    <span>Account &amp; Security Settings</span>
                  </button>

                  <button
                    onClick={() => onOpenAuth('forgot-password')}
                    className="w-full flex items-center gap-2 px-3.5 py-2 text-zinc-300 hover:text-zinc-100 hover:bg-zinc-800/60 transition-colors text-left cursor-pointer"
                  >
                    <KeyRound className="w-3.5 h-3.5 text-amber-400" />
                    <span>Change / Reset Password</span>
                  </button>

                  <div className="my-1 border-t border-zinc-800/80" />

                  <button
                    onClick={logout}
                    className="w-full flex items-center gap-2 px-3.5 py-2 text-rose-400 hover:text-rose-300 hover:bg-rose-950/30 transition-colors text-left cursor-pointer font-semibold"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Sign Out</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="flex items-center gap-1.5 pl-1 sm:pl-2 border-l border-zinc-800">
              <button
                onClick={() => onOpenAuth('login')}
                className="flex items-center gap-1 px-2.5 py-1.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-200 rounded-md text-xs font-semibold transition-colors cursor-pointer"
              >
                <LogIn className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden sm:inline">Sign In</span>
              </button>
              <button
                onClick={() => onOpenAuth('register')}
                className="hidden sm:flex items-center gap-1 px-2.5 py-1.5 bg-emerald-950/60 hover:bg-emerald-900/80 border border-emerald-700 text-emerald-300 rounded-md text-xs font-semibold transition-colors cursor-pointer"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>Register</span>
              </button>
            </div>
          )}

          {/* Mobile Menu Toggle Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-1.5 text-zinc-400 hover:text-zinc-200 bg-zinc-900 border border-zinc-800 rounded-md cursor-pointer"
          >
            {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Navigation Sub-Bar (Desktop) */}
      <div className="hidden md:flex border-t border-zinc-800/60 bg-[#070a0e]/90 px-4 lg:px-6">
        <nav className="flex items-center gap-1 max-w-7xl mx-auto w-full overflow-x-auto py-1">
          {navLinks.map((link) => {
            const isActive = currentTab === link.id;
            const Icon = link.icon;
            return (
              <button
                key={link.id}
                onClick={() => onNavigate(link.id)}
                className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap shrink-0 transition-colors focus-visible:outline-none cursor-pointer ${
                  isActive
                    ? 'bg-zinc-800/90 text-emerald-400 font-semibold border border-zinc-700/60'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/60'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-emerald-400' : 'text-zinc-400'}`} />
                <span>{link.label}</span>
                {link.count !== undefined && (
                  <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono font-bold ${
                    isActive ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/60' : 'bg-zinc-800 text-zinc-400'
                  }`}>
                    {link.count}
                  </span>
                )}
                {link.badge && (
                  <span className="text-[9px] px-1.5 py-0.2 bg-emerald-950 text-emerald-400 border border-emerald-800 rounded font-mono font-bold">
                    {link.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-zinc-800 bg-[#090d12] p-4 space-y-2">
          {/* Mobile search */}
          <form onSubmit={handleSearchSubmit} className="relative w-full mb-3">
            <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search findings, files..."
              className="w-full pl-8 pr-3 py-1.5 bg-zinc-900 border border-zinc-800 rounded text-xs font-mono text-zinc-200"
            />
          </form>

          {navLinks.map((link) => {
            const isActive = currentTab === link.id;
            const Icon = link.icon;
            return (
              <button
                key={link.id}
                onClick={() => {
                  onNavigate(link.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                  isActive
                    ? 'bg-zinc-800 text-emerald-400 font-semibold'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Icon className="w-4 h-4" />
                  <span>{link.label}</span>
                </div>
                {link.count !== undefined && (
                  <span className="text-[10px] px-1.5 py-0.5 rounded font-mono bg-zinc-800 text-zinc-300">
                    {link.count}
                  </span>
                )}
              </button>
            );
          })}

          {!user && (
            <div className="pt-2 border-t border-zinc-800 flex gap-2">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenAuth('login');
                }}
                className="flex-1 py-2 bg-emerald-600 text-white rounded text-xs font-semibold text-center"
              >
                Sign In
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenAuth('register');
                }}
                className="flex-1 py-2 bg-zinc-800 text-zinc-200 border border-zinc-700 rounded text-xs font-semibold text-center"
              >
                Create Account
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
};

