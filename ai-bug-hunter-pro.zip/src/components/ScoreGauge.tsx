import React from 'react';

interface ScoreGaugeProps {
  score: number | null;
  size?: 'sm' | 'md' | 'lg';
  showGrade?: boolean;
}

export const ScoreGauge: React.FC<ScoreGaugeProps> = ({ score, size = 'md', showGrade = true }) => {
  if (score === null || score === undefined) {
    return (
      <div className="flex items-center gap-2 text-zinc-500 font-mono text-sm">
        <span>No score yet</span>
      </div>
    );
  }

  const getGrade = (s: number): { grade: string; color: string; bg: string; border: string } => {
    if (s >= 90) return { grade: 'A+', color: 'text-emerald-400', bg: 'bg-emerald-950/40', border: 'border-emerald-700' };
    if (s >= 80) return { grade: 'A', color: 'text-emerald-400', bg: 'bg-emerald-950/40', border: 'border-emerald-700' };
    if (s >= 70) return { grade: 'B', color: 'text-sky-400', bg: 'bg-sky-950/40', border: 'border-sky-700' };
    if (s >= 50) return { grade: 'C', color: 'text-amber-400', bg: 'bg-amber-950/40', border: 'border-amber-700' };
    if (s >= 30) return { grade: 'D', color: 'text-orange-400', bg: 'bg-orange-950/40', border: 'border-orange-700' };
    return { grade: 'F', color: 'text-rose-400', bg: 'bg-rose-950/40', border: 'border-rose-700' };
  };

  const { grade, color, bg, border } = getGrade(score);

  if (size === 'sm') {
    return (
      <div className="inline-flex items-center gap-2">
        <span className={`font-mono font-bold text-base ${color}`}>{score}/100</span>
        {showGrade && (
          <span className={`px-1.5 py-0.2 text-xs font-mono font-bold border rounded-sm ${bg} ${border} ${color}`}>
            {grade}
          </span>
        )}
      </div>
    );
  }

  if (size === 'lg') {
    return (
      <div className="flex flex-col items-center justify-center p-6 bg-zinc-900 border border-zinc-800 rounded-lg">
        <div className="relative flex items-center justify-center">
          <div className={`text-5xl font-mono font-black tracking-tight ${color}`}>
            {score}
          </div>
          <span className="text-zinc-600 font-mono text-xl ml-1 self-end mb-1">/100</span>
        </div>
        {showGrade && (
          <div className="mt-3 flex items-center gap-2">
            <span className={`px-2.5 py-0.5 text-sm font-mono font-bold border rounded-sm ${bg} ${border} ${color}`}>
              Grade {grade}
            </span>
            <span className="text-xs text-zinc-400 font-mono">
              {score >= 80 ? 'Low Risk' : score >= 50 ? 'Moderate Risk' : 'High Risk'}
            </span>
          </div>
        )}
      </div>
    );
  }

  // Medium (Default)
  return (
    <div className="inline-flex items-center gap-3">
      <div className="flex items-baseline">
        <span className={`text-2xl font-mono font-black ${color}`}>{score}</span>
        <span className="text-xs text-zinc-500 font-mono ml-0.5">/100</span>
      </div>
      {showGrade && (
        <span className={`px-2 py-0.5 text-xs font-mono font-bold border rounded-sm ${bg} ${border} ${color}`}>
          {grade}
        </span>
      )}
    </div>
  );
};
