import React, { useState } from 'react';
import { Copy, Check, Sparkles } from 'lucide-react';

interface DiffViewerProps {
  originalCode: string;
  suggestedCode: string;
  explanation?: string;
  potentialSideEffects?: string[];
  recommendedTests?: string[];
}

export const DiffViewer: React.FC<DiffViewerProps> = ({
  originalCode,
  suggestedCode,
  explanation,
  potentialSideEffects,
  recommendedTests
}) => {
  const [copied, setCopied] = useState(false);
  const [viewMode, setViewMode] = useState<'split' | 'unified'>('split');

  const handleCopyFix = () => {
    navigator.clipboard.writeText(suggestedCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="border border-zinc-800 rounded-md overflow-hidden bg-zinc-950 font-mono text-xs w-full min-w-0 max-w-full">
      {/* Header bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 bg-zinc-900 border-b border-zinc-800">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="font-semibold text-zinc-200">AI Suggested Remediation</span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex bg-zinc-800 p-0.5 rounded text-[11px]">
            <button
              onClick={() => setViewMode('split')}
              className={`px-2 py-1 rounded transition-colors cursor-pointer ${
                viewMode === 'split' ? 'bg-zinc-700 text-zinc-100 font-semibold' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              Side-by-Side
            </button>
            <button
              onClick={() => setViewMode('unified')}
              className={`px-2 py-1 rounded transition-colors cursor-pointer ${
                viewMode === 'unified' ? 'bg-zinc-700 text-zinc-100 font-semibold' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              Unified
            </button>
          </div>

          <button
            onClick={handleCopyFix}
            className="flex items-center gap-1.5 px-3 py-1 bg-emerald-950 hover:bg-emerald-900 border border-emerald-700 text-emerald-300 rounded font-semibold text-[11px] transition-colors cursor-pointer"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>Fix Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy Fix</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Diff content */}
      {viewMode === 'split' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-zinc-800 w-full min-w-0">
          {/* Original Vulnerable */}
          <div className="p-3 bg-rose-950/20 min-w-0 w-full overflow-hidden">
            <div className="text-[11px] font-bold text-rose-400 mb-2 pb-1 border-b border-rose-900/40 uppercase tracking-wider">
              Original Vulnerable Code
            </div>
            <pre className="overflow-x-auto text-rose-200/90 whitespace-pre leading-relaxed p-1 min-w-0 max-w-full">
              {originalCode}
            </pre>
          </div>

          {/* Secure Replacement */}
          <div className="p-3 bg-emerald-950/20 min-w-0 w-full overflow-hidden">
            <div className="text-[11px] font-bold text-emerald-400 mb-2 pb-1 border-b border-emerald-900/40 uppercase tracking-wider">
              Secure Replacement Code
            </div>
            <pre className="overflow-x-auto text-emerald-200/90 whitespace-pre leading-relaxed p-1 min-w-0 max-w-full">
              {suggestedCode}
            </pre>
          </div>
        </div>
      ) : (
        <div className="p-4 space-y-4 w-full min-w-0">
          <div className="p-3 bg-rose-950/30 border border-rose-900/40 rounded min-w-0 w-full overflow-hidden">
            <div className="text-[11px] text-rose-400 font-bold mb-1">− VULNERABLE:</div>
            <pre className="text-rose-200 overflow-x-auto whitespace-pre min-w-0 max-w-full">{originalCode}</pre>
          </div>
          <div className="p-3 bg-emerald-950/30 border border-emerald-900/40 rounded min-w-0 w-full overflow-hidden">
            <div className="text-[11px] text-emerald-400 font-bold mb-1">+ REMEDIATED:</div>
            <pre className="text-emerald-200 overflow-x-auto whitespace-pre min-w-0 max-w-full">{suggestedCode}</pre>
          </div>
        </div>
      )}

      {/* Explanation & side effects if available */}
      {(explanation || (potentialSideEffects && potentialSideEffects.length > 0)) && (
        <div className="p-4 bg-zinc-900/80 border-t border-zinc-800 space-y-3 font-sans text-xs [overflow-wrap:anywhere] break-words min-w-0">
          {explanation && (
            <div>
              <span className="font-semibold text-zinc-300">Remediation Rationale: </span>
              <span className="text-zinc-400">{explanation}</span>
            </div>
          )}

          {potentialSideEffects && potentialSideEffects.length > 0 && (
            <div>
              <span className="font-semibold text-amber-300">Potential Considerations:</span>
              <ul className="list-disc list-inside mt-1 text-zinc-400 space-y-0.5 pl-1">
                {potentialSideEffects.map((item, idx) => (
                  <li key={idx} className="break-words">{item}</li>
                ))}
              </ul>
            </div>
          )}

          {recommendedTests && recommendedTests.length > 0 && (
            <div>
              <span className="font-semibold text-sky-300">Recommended Test Assertions:</span>
              <ul className="list-disc list-inside mt-1 text-zinc-400 space-y-0.5 pl-1">
                {recommendedTests.map((item, idx) => (
                  <li key={idx} className="break-words">{item}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
