import React from 'react';
import { IssueCategory } from '../types';

interface CategoryBadgeProps {
  category: IssueCategory | string;
}

export const CategoryBadge: React.FC<CategoryBadgeProps> = ({ category }) => {
  return (
    <span className="inline-flex items-center px-2.5 py-1 text-xs font-mono font-medium bg-zinc-900/90 text-zinc-300 border border-zinc-800 rounded whitespace-nowrap shrink-0">
      {category}
    </span>
  );
};
