import React, { useState } from 'react';
import { Copy, Check, FileCode } from 'lucide-react';

interface CodeViewerProps {
  code: string;
  filePath: string;
  startLine?: number;
  highlightLine?: number;
  maxHeight?: string;
}

export const CodeViewer: React.FC<CodeViewerProps> = ({
  code,
  filePath,
  startLine = 1,
  highlightLine,
  maxHeight = 'max-h-96'
}) => {
  const [copied, setCopied] = useState(false);
  const lines = code.split('\n');
  const ext = filePath.split('.').pop()?.toUpperCase() || 'FILE';

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="border border-zinc-800 rounded-xl overflow-hidden bg-[#090d13] font-mono text-xs shadow-inner w-full">
      {/* File header bar */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-zinc-900/90 border-b border-zinc-800 text-zinc-400">
        <div className="flex items-center gap-2 truncate">
          <FileCode className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="truncate font-semibold text-zinc-200">{filePath}</span>
          <span className="px-1.5 py-0.5 bg-zinc-800 text-zinc-400 text-[10px] font-bold rounded">
            {ext}
          </span>
        </div>

        <button
          onClick={handleCopy}
          className="flex items-center gap-1.5 px-2.5 py-1 text-[11px] bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded transition-colors cursor-pointer shrink-0"
          title="Copy code"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-emerald-400 font-semibold">Copied</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>Copy</span>
            </>
          )}
        </button>
      </div>

      {/* Code content */}
      <div className={`overflow-x-auto overflow-y-auto ${maxHeight} p-4 select-text`}>
        <table className="w-full border-collapse">
          <tbody>
            {lines.map((lineText, idx) => {
              const currentLineNumber = startLine + idx;
              const isHighlighted = highlightLine !== undefined && currentLineNumber === highlightLine;

              return (
                <tr
                  key={idx}
                  className={`leading-relaxed transition-colors ${
                    isHighlighted
                      ? 'bg-rose-950/60 text-rose-200 border-l-2 border-rose-500 font-bold'
                      : 'text-zinc-300 hover:bg-zinc-900/30'
                  }`}
                >
                  <td className="pr-4 pl-1 text-right select-none text-zinc-600 w-10 text-[11px] align-top font-mono">
                    {currentLineNumber}
                  </td>
                  <td className="whitespace-pre font-mono pl-3">
                    {lineText || ' '}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
