import React from 'react';
import { Severity } from '../types';

interface SeverityBadgeProps {
  severity: Severity;
  size?: 'sm' | 'md' | 'lg';
}

export const SeverityBadge: React.FC<SeverityBadgeProps> = ({ severity, size = 'md' }) => {
  const sizeClasses = {
    sm: 'text-[10px] px-1.5 py-0.5 font-bold tracking-wider',
    md: 'text-xs px-2.5 py-1 font-bold tracking-wider',
    lg: 'text-sm px-3 py-1.5 font-bold tracking-wider'
  };

  const colorStyles: Record<Severity, string> = {
    CRITICAL: 'bg-red-950/80 text-red-400 border border-red-800 shadow-[0_0_8px_rgba(239,68,68,0.15)]',
    HIGH: 'bg-orange-950/80 text-orange-400 border border-orange-800 shadow-[0_0_8px_rgba(249,115,22,0.15)]',
    MEDIUM: 'bg-amber-950/80 text-amber-400 border border-amber-800 shadow-[0_0_8px_rgba(245,158,11,0.15)]',
    LOW: 'bg-sky-950/80 text-sky-400 border border-sky-800 shadow-[0_0_8px_rgba(14,165,233,0.15)]',
    INFO: 'bg-zinc-900 text-zinc-300 border border-zinc-700'
  };

  return (
    <span
      className={`inline-flex items-center rounded uppercase font-mono whitespace-nowrap shrink-0 transition-all ${
        sizeClasses[size]
      } ${colorStyles[severity] || colorStyles.INFO}`}
    >
      {severity}
    </span>
  );
};
