import {
  DashboardStats,
  Repository,
  Scan,
  DetailedScan,
  Issue,
  User
} from '../types';

export class ApiError extends Error {
  public status?: number;
  public endpoint: string;
  public isNetworkError: boolean;
  public details?: any;

  constructor(message: string, endpoint: string, status?: number, isNetworkError: boolean = false, details?: any) {
    super(message);
    this.name = 'ApiError';
    this.endpoint = endpoint;
    this.status = status;
    this.isNetworkError = isNetworkError;
    this.details = details;
  }
}

class ApiClient {
  private token: string | null = null;
  private baseUrl: string = '';

  constructor() {
    this.token = localStorage.getItem('bug_hunter_token');
    
    // Support custom configurable API Base URL via environment variable
    const envBase = (import.meta as any).env?.VITE_API_BASE_URL;
    if (envBase && typeof envBase === 'string' && envBase.trim() !== '') {
      this.baseUrl = envBase.trim().replace(/\/+$/, '');
    }
  }

  public setToken(token: string | null) {
    this.token = token;
    if (token) {
      localStorage.setItem('bug_hunter_token', token);
    } else {
      localStorage.removeItem('bug_hunter_token');
    }
  }

  public getToken(): string | null {
    return this.token;
  }

  public getBaseUrl(): string {
    return this.baseUrl;
  }

  public setBaseUrl(url: string) {
    this.baseUrl = url.trim().replace(/\/+$/, '');
  }

  private resolveUrl(endpoint: string): string {
    if (endpoint.startsWith('http://') || endpoint.startsWith('https://')) {
      return endpoint;
    }
    const cleanEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
    return `${this.baseUrl}${cleanEndpoint}`;
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const targetUrl = this.resolveUrl(endpoint);
    const headers: Record<string, string> = {
      ...(options.headers as Record<string, string>)
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    // IMPORTANT: For FormData (multipart uploads), DO NOT manually set Content-Type
    // The browser must automatically compute multipart/form-data with the boundary parameter
    if (!(options.body instanceof FormData) && !headers['Content-Type']) {
      headers['Content-Type'] = 'application/json';
    }

    let res: Response;
    try {
      res = await fetch(targetUrl, {
        ...options,
        headers
      });
    } catch (err: any) {
      // Diagnostic network connection error
      const helpfulMsg = `Unable to connect to the security-analysis backend at ${targetUrl}. Please ensure the server is running and accessible.`;
      console.error(`[API Network Error] ${options.method || 'GET'} ${targetUrl}:`, err);
      throw new ApiError(helpfulMsg, targetUrl, undefined, true, err);
    }

    // Safely retrieve raw response text first to guard against non-JSON / HTML payloads
    const rawText = await res.text();
    let parsedData: any = null;
    let isJson = false;

    if (rawText && rawText.trim().length > 0) {
      try {
        parsedData = JSON.parse(rawText);
        isJson = true;
      } catch {
        isJson = false;
      }
    } else {
      parsedData = {};
      isJson = true;
    }

    // Detect if the server returned an HTML document (e.g. 404/500 rewrite or SPA index.html)
    const isHtmlResponse =
      !isJson &&
      (rawText.trim().startsWith('<') ||
        rawText.includes('<!doctype') ||
        rawText.includes('<!DOCTYPE') ||
        rawText.includes('<html'));

    if (!res.ok) {
      let errMessage = `Request failed with HTTP status ${res.status}: ${res.statusText}`;

      if (isJson && parsedData) {
        if (parsedData.error) {
          errMessage = parsedData.error;
        } else if (parsedData.message) {
          errMessage = parsedData.message;
        }
      } else if (isHtmlResponse) {
        if (res.status === 404) {
          errMessage = `API endpoint not found (404). Please verify backend deployment for ${endpoint}.`;
        } else if (res.status === 401) {
          errMessage = 'Unauthorized. Please sign in to perform this action.';
        } else if (res.status === 403) {
          errMessage = 'Access denied. You do not have permission to access this resource.';
        } else if (res.status === 413) {
          errMessage = 'Uploaded payload exceeds size limit (413 Payload Too Large).';
        } else if (res.status === 429) {
          errMessage = 'Rate limit exceeded (429). Please wait before trying again.';
        } else {
          errMessage = `Server returned an unexpected HTML response (HTTP ${res.status}). Please check the API deployment.`;
        }
      } else if (rawText && rawText.length < 200) {
        errMessage = rawText;
      }

      throw new ApiError(errMessage, targetUrl, res.status, false, parsedData);
    }

    // If HTTP status is OK (200, 201) but the content is actually an HTML document
    if (!isJson && isHtmlResponse) {
      throw new ApiError(
        'Server returned an unexpected HTML response instead of JSON. Please check the API deployment.',
        targetUrl,
        res.status,
        false
      );
    }

    return parsedData as T;
  }

  // Health check
  public async checkHealth(): Promise<{ status: string; service?: string; timestamp?: string }> {
    return this.request<{ status: string; service?: string; timestamp?: string }>('/api/health');
  }

  // Auth APIs
  public async login(email: string, password: string): Promise<{ user: User; token: string }> {
    const res = await this.request<{ user: User; token: string }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password })
    });
    this.setToken(res.token);
    return res;
  }

  public async register(name: string, email: string, password: string): Promise<{ user: User; token: string }> {
    const res = await this.request<{ user: User; token: string }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({ name, email, password })
    });
    this.setToken(res.token);
    return res;
  }

  public async getCurrentUser(): Promise<{ user: User }> {
    return this.request<{ user: User }>('/api/auth/me');
  }

  public logout() {
    this.setToken(null);
  }

  public async forgotPassword(email: string): Promise<{ message: string; devResetLink?: string }> {
    return this.request<{ message: string; devResetLink?: string }>('/api/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email })
    });
  }

  public async verifyResetToken(token: string): Promise<{ valid: boolean; email?: string; name?: string; message?: string }> {
    return this.request<{ valid: boolean; email?: string; name?: string; message?: string }>(
      `/api/auth/reset-password/verify?token=${encodeURIComponent(token)}`
    );
  }

  public async resetPassword(token: string, newPassword: string): Promise<{ success: boolean; message: string }> {
    return this.request<{ success: boolean; message: string }>('/api/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify({ token, newPassword })
    });
  }

  public async getEmailConfig(): Promise<{ configured: boolean; provider: string; fromAddress?: string }> {
    return this.request<{ configured: boolean; provider: string; fromAddress?: string }>('/api/auth/email-config');
  }

  // Stats
  public async getStats(): Promise<DashboardStats> {
    return this.request<DashboardStats>('/api/stats');
  }

  // Repositories
  public async getRepositories(): Promise<{ repositories: Repository[] }> {
    return this.request<{ repositories: Repository[] }>('/api/repositories');
  }

  public async getRepository(id: string): Promise<{ repository: Repository; scans: Scan[] }> {
    return this.request<{ repository: Repository; scans: Scan[] }>(`/api/repositories/${id}`);
  }

  public async uploadZip(
    file: File,
    name?: string,
    branch?: string
  ): Promise<{ repositoryId: string; scanId: string; score: number; issuesCount: number; status?: string; message?: string }> {
    const formData = new FormData();
    formData.append('file', file);
    if (name) formData.append('name', name);
    if (branch) formData.append('branch', branch);

    return this.request<{ repositoryId: string; scanId: string; score: number; issuesCount: number; status?: string; message?: string }>('/api/repositories/upload', {
      method: 'POST',
      body: formData
    });
  }

  public async importGithub(
    url: string,
    branch?: string,
    name?: string,
    token?: string
  ): Promise<{ repositoryId: string; scanId: string; score: number; issuesCount: number; status?: string; message?: string }> {
    return this.request<{ repositoryId: string; scanId: string; score: number; issuesCount: number; status?: string; message?: string }>('/api/repositories/github', {
      method: 'POST',
      body: JSON.stringify({ url, branch: branch || undefined, name, token: token || undefined })
    });
  }

  public async scanTestProject(): Promise<{ repositoryId: string; scanId: string; score: number; issuesCount: number; status?: string; message?: string }> {
    return this.request<{ repositoryId: string; scanId: string; score: number; issuesCount: number; status?: string; message?: string }>('/api/repositories/test-project', {
      method: 'POST'
    });
  }

  public async deleteRepository(id: string): Promise<{ message: string }> {
    return this.request<{ message: string }>(`/api/repositories/${id}`, {
      method: 'DELETE'
    });
  }

  // Scans
  public async getScans(repositoryId?: string): Promise<{ scans: Scan[] }> {
    const url = repositoryId ? `/api/scans?repository_id=${repositoryId}` : '/api/scans';
    return this.request<{ scans: Scan[] }>(url);
  }

  public async startScan(repositoryId: string, commitHash?: string): Promise<{ scanId: string; repositoryId: string; score: number; issuesCount: number; status: string }> {
    return this.request<{ scanId: string; repositoryId: string; score: number; issuesCount: number; status: string }>('/api/scans', {
      method: 'POST',
      body: JSON.stringify({ repository_id: repositoryId, commitHash })
    });
  }

  public async getScanDetails(id: string): Promise<{ scan: DetailedScan }> {
    return this.request<{ scan: DetailedScan }>(`/api/scans/${id}`);
  }

  public async cancelScan(id: string): Promise<{ message: string }> {
    return this.request<{ message: string }>(`/api/scans/${id}/cancel`, {
      method: 'POST'
    });
  }

  // Issues
  public async getIssues(params?: {
    severity?: string;
    category?: string;
    scanner?: string;
    status?: string;
    scan_id?: string;
    repository_id?: string;
    search?: string;
    sort_by?: string;
    order?: string;
  }): Promise<{ issues: Issue[]; totalCount: number }> {
    const query = new URLSearchParams();
    if (params) {
      Object.entries(params).forEach(([k, v]) => {
        if (v) query.append(k, v);
      });
    }
    const url = `/api/issues?${query.toString()}`;
    return this.request<{ issues: Issue[]; totalCount: number }>(url);
  }

  public async getIssue(id: string): Promise<{ issue: Issue }> {
    return this.request<{ issue: Issue }>(`/api/issues/${id}`);
  }

  public async updateIssueStatus(id: string, status: Issue['status']): Promise<{ message: string; status: string }> {
    return this.request<{ message: string; status: string }>(`/api/issues/${id}`, {
      method: 'PATCH',
      body: JSON.stringify({ status })
    });
  }

  // AI APIs
  public async getAIStatus(): Promise<{ provider: string; available: boolean; hasGeminiKey: boolean }> {
    return this.request<{ provider: string; available: boolean; hasGeminiKey: boolean }>('/api/ai/status');
  }

  public async explainIssue(issueId: string): Promise<{ analysis: any }> {
    return this.request<{ analysis: any }>(`/api/ai/issues/${issueId}/explain`, {
      method: 'POST'
    });
  }

  public async generateFix(issueId: string): Promise<{ fix: any }> {
    return this.request<{ fix: any }>(`/api/ai/issues/${issueId}/fix`, {
      method: 'POST'
    });
  }

  public async generateTests(issueId: string, framework?: string): Promise<{ tests: any }> {
    return this.request<{ tests: any }>(`/api/ai/issues/${issueId}/tests`, {
      method: 'POST',
      body: JSON.stringify({ framework })
    });
  }

  public async reviewCode(payload: { filePath: string; language: string; codeContent: string }): Promise<{ review: any }> {
    return this.request<{ review: any }>('/api/code-review', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  // Reports
  public async getReport(scanId: string, format = 'json'): Promise<any> {
    return this.request<any>(`/api/reports/${scanId}?format=${format}`);
  }
}

export const api = new ApiClient();
