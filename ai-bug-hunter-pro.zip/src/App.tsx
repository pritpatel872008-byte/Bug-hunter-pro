import React, { useState, useEffect } from 'react';
import { AuthProvider } from './contexts/AuthContext';
import { DemoProvider } from './contexts/DemoContext';
import { TopBar } from './components/TopBar';
import { UploadModal } from './components/UploadModal';
import { AuthModal, AuthMode } from './components/AuthModal';
import { LandingPage } from './pages/LandingPage';
import { DashboardPage } from './pages/DashboardPage';
import { RepositoriesPage } from './pages/RepositoriesPage';
import { RepoDetailsPage } from './pages/RepoDetailsPage';
import { ScansPage } from './pages/ScansPage';
import { ScanDetailsPage } from './pages/ScanDetailsPage';
import { IssuesPage } from './pages/IssuesPage';
import { IssueDetailsPage } from './pages/IssueDetailsPage';
import { CodeReviewPage } from './pages/CodeReviewPage';
import { ReportsPage } from './pages/ReportsPage';
import { SettingsPage } from './pages/SettingsPage';

function AppContent() {
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [selectedScanId, setSelectedScanId] = useState<string | null>(null);
  const [selectedIssueId, setSelectedIssueId] = useState<string | null>(null);
  const [selectedRepoId, setSelectedRepoId] = useState<string | null>(null);
  const [issueSeverityFilter, setIssueSeverityFilter] = useState<string | undefined>(undefined);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);

  // Authentication Modal State
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<AuthMode>('login');
  const [resetToken, setResetToken] = useState<string | null>(null);

  // Check URL query parameters for reset_token or auth action
  useEffect(() => {
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const token = urlParams.get('token') || urlParams.get('reset_token');
      const authAction = urlParams.get('auth');
      const isResetPath = window.location.pathname.includes('/reset-password');

      if (token || isResetPath) {
        setResetToken(token || null);
        setAuthModalMode('reset-password');
        setAuthModalOpen(true);
      } else if (authAction === 'login' || authAction === 'register' || authAction === 'forgot-password') {
        setAuthModalMode(authAction as AuthMode);
        setAuthModalOpen(true);
      }
    } catch {
      // Ignored in restricted environments
    }
  }, []);

  const handleOpenAuth = (mode: AuthMode = 'login') => {
    setAuthModalMode(mode);
    setAuthModalOpen(true);
  };

  const handleNavigate = (tab: string) => {
    setCurrentTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigateToScan = (scanId: string) => {
    setSelectedScanId(scanId);
    setCurrentTab('scan-details');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigateToIssue = (issueId: string) => {
    setSelectedIssueId(issueId);
    setCurrentTab('issue-details');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigateToRepo = (repoId: string) => {
    setSelectedRepoId(repoId);
    setCurrentTab('repo-details');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigateToIssuesWithFilter = (severity?: string) => {
    setIssueSeverityFilter(severity);
    setCurrentTab('issues');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigateToReport = (scanId: string) => {
    setSelectedScanId(scanId);
    setCurrentTab('reports');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleScanCompleted = (scanId: string) => {
    setSelectedScanId(scanId);
    setCurrentTab('scan-details');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden bg-[#090d12] text-zinc-100 flex flex-col font-sans selection:bg-emerald-950 selection:text-emerald-300">
      {/* Top Bar Navigation */}
      <TopBar
        currentTab={currentTab}
        onNavigate={handleNavigate}
        onOpenUpload={() => setUploadModalOpen(true)}
        onOpenAuth={handleOpenAuth}
      />

      {/* Main Page Area */}
      <main className="flex-1 w-full max-w-full overflow-x-hidden">
        {currentTab === 'landing' && (
          <LandingPage
            onStartScan={() => setUploadModalOpen(true)}
            onNavigateToDashboard={() => handleNavigate('dashboard')}
          />
        )}

        {currentTab === 'dashboard' && (
          <DashboardPage
            onOpenUpload={() => setUploadModalOpen(true)}
            onNavigateToScan={handleNavigateToScan}
            onNavigateToIssues={handleNavigateToIssuesWithFilter}
            onNavigateToRepo={handleNavigateToRepo}
          />
        )}

        {currentTab === 'repositories' && (
          <RepositoriesPage
            onOpenUpload={() => setUploadModalOpen(true)}
            onNavigateToScan={handleNavigateToScan}
            onNavigateToRepo={handleNavigateToRepo}
          />
        )}

        {currentTab === 'repo-details' && selectedRepoId && (
          <RepoDetailsPage
            repoId={selectedRepoId}
            onBack={() => handleNavigate('repositories')}
            onNavigateToScan={handleNavigateToScan}
            onOpenUpload={() => setUploadModalOpen(true)}
          />
        )}

        {currentTab === 'scans' && (
          <ScansPage
            onOpenUpload={() => setUploadModalOpen(true)}
            onNavigateToScan={handleNavigateToScan}
          />
        )}

        {currentTab === 'scan-details' && selectedScanId && (
          <ScanDetailsPage
            scanId={selectedScanId}
            onBack={() => handleNavigate('scans')}
            onNavigateToIssue={handleNavigateToIssue}
            onNavigateToReport={handleNavigateToReport}
          />
        )}

        {currentTab === 'issues' && (
          <IssuesPage
            initialSeverityFilter={issueSeverityFilter}
            onNavigateToIssue={handleNavigateToIssue}
          />
        )}

        {currentTab === 'issue-details' && selectedIssueId && (
          <IssueDetailsPage
            issueId={selectedIssueId}
            onBack={() => handleNavigate(selectedScanId ? 'scan-details' : 'issues')}
            onOpenUpload={() => setUploadModalOpen(true)}
          />
        )}

        {currentTab === 'code-review' && <CodeReviewPage />}

        {currentTab === 'reports' && selectedScanId && (
          <ReportsPage
            scanId={selectedScanId}
            onBack={() => handleNavigate('scan-details')}
          />
        )}

        {currentTab === 'settings' && (
          <SettingsPage onOpenAuth={handleOpenAuth} />
        )}
      </main>

      {/* Global Upload & Scan Modal */}
      <UploadModal
        isOpen={uploadModalOpen}
        onClose={() => setUploadModalOpen(false)}
        onScanCompleted={handleScanCompleted}
        onOpenAuth={handleOpenAuth}
      />

      {/* Global Authentication Modal (Sign In / Register / Forgot / Reset Password) */}
      <AuthModal
        isOpen={authModalOpen}
        initialMode={authModalMode}
        resetToken={resetToken}
        onClose={() => {
          setAuthModalOpen(false);
          setResetToken(null);
        }}
        onSuccess={() => {
          setAuthModalOpen(false);
          setResetToken(null);
        }}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <DemoProvider>
        <AppContent />
      </DemoProvider>
    </AuthProvider>
  );
}

