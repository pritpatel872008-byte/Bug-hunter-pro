import { createServerApp } from '../server/api/server_app.ts';

const app = createServerApp();

export default app;
