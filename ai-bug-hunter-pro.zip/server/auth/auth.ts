import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { Request, Response, NextFunction } from 'express';
import { getDb, ensureUserInDatabase } from '../db/database.ts';
import crypto, { randomUUID } from 'node:crypto';

// In-memory generated secret for development when JWT_SECRET is not configured
let devSecret: string | null = null;
let devSecretWarned = false;

function getJwtSecret(): string {
  const envSecret = process.env.JWT_SECRET;
  if (envSecret && envSecret.trim() !== '') {
    return envSecret.trim();
  }

  if (!devSecret) {
    devSecret = crypto.randomBytes(32).toString('hex');
  }

  if (!devSecretWarned) {
    if (process.env.NODE_ENV === 'production') {
      console.warn('Warning: JWT_SECRET not set in production. Please provide a secure JWT_SECRET environment variable.');
    } else {
      console.warn('Warning: JWT_SECRET not set. Using auto-generated development secret.');
    }
    devSecretWarned = true;
  }

  return devSecret;
}

export interface AuthUser {
  id: string;
  name: string;
  email: string;
}

export interface AuthRequest extends Request {
  user?: AuthUser;
}

export async function hashPassword(password: string): Promise<string> {
  const salt = await bcrypt.genSalt(10);
  return bcrypt.hash(password, salt);
}

export async function comparePassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export function generateToken(user: AuthUser): string {
  const secret = getJwtSecret();
  return jwt.sign(
    { id: user.id, name: user.name, email: user.email },
    secret,
    { expiresIn: '7d' }
  );
}

export function verifyToken(token: string): AuthUser | null {
  try {
    const secret = getJwtSecret();
    const decoded = jwt.verify(token, secret) as AuthUser;
    return decoded;
  } catch {
    return null;
  }
}

export function authMiddleware(req: AuthRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized: Missing or invalid token' });
  }

  const token = authHeader.split(' ')[1];
  const user = verifyToken(token);
  if (!user) {
    return res.status(401).json({ error: 'Unauthorized: Token expired or invalid' });
  }

  req.user = user;
  ensureUserInDatabase(user.id, user.email, user.name);
  next();
}

// Optional auth middleware (e.g. for endpoints that support anonymous or logged-in users)
export function optionalAuthMiddleware(req: AuthRequest, _res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    const user = verifyToken(token);
    if (user) {
      req.user = user;
      ensureUserInDatabase(user.id, user.email, user.name);
    }
  }
  next();
}
