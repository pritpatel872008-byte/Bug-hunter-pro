import nodemailer from 'nodemailer';

export interface EmailConfig {
  configured: boolean;
  host: string;
  port: number;
  user: string;
  fromAddress: string;
}

export function getEmailConfig(): EmailConfig {
  const host = process.env.SMTP_HOST?.trim() || process.env.EMAIL_SERVER?.trim() || 'smtp.gmail.com';
  const port = parseInt(process.env.SMTP_PORT?.trim() || process.env.EMAIL_PORT?.trim() || '587', 10);
  const user = process.env.SMTP_USER?.trim() || process.env.AUTH_EMAIL?.trim() || process.env.EMAIL_USERNAME?.trim() || '';
  const pass = process.env.SMTP_PASSWORD?.trim() || process.env.SMTP_PASS?.trim() || process.env.AUTH_EMAIL_APP_PASSWORD?.trim() || process.env.EMAIL_PASSWORD?.trim() || '';
  const fromAddress = process.env.EMAIL_FROM?.trim() || user || 'security@bughunter.dev';

  const configured = Boolean(user && pass);

  return {
    configured,
    host,
    port,
    user,
    fromAddress
  };
}

export function createTransporter() {
  const host = process.env.SMTP_HOST?.trim() || process.env.EMAIL_SERVER?.trim() || 'smtp.gmail.com';
  const port = parseInt(process.env.SMTP_PORT?.trim() || process.env.EMAIL_PORT?.trim() || '587', 10);
  const user = process.env.SMTP_USER?.trim() || process.env.AUTH_EMAIL?.trim() || process.env.EMAIL_USERNAME?.trim() || '';
  const pass = process.env.SMTP_PASSWORD?.trim() || process.env.SMTP_PASS?.trim() || process.env.AUTH_EMAIL_APP_PASSWORD?.trim() || process.env.EMAIL_PASSWORD?.trim() || '';

  if (!user || !pass) {
    return null;
  }

  const isSecure = port === 465;

  return nodemailer.createTransport({
    host,
    port,
    secure: isSecure,
    auth: {
      user,
      pass
    }
  });
}

export interface SendResetEmailParams {
  toEmail: string;
  userName?: string;
  resetToken: string;
  appBaseUrl: string;
}

export async function sendPasswordResetEmail({
  toEmail,
  userName,
  resetToken,
  appBaseUrl
}: SendResetEmailParams): Promise<{ sent: boolean; resetLink: string }> {
  const configuredAppUrl = process.env.APP_URL?.trim();
  // Ensure we use production APP_URL if configured, avoiding localhost
  const cleanBase = (configuredAppUrl && !configuredAppUrl.includes('localhost') ? configuredAppUrl : appBaseUrl).replace(/\/+$/, '');
  
  // Real reset URL containing production URL with token
  const resetLink = `${cleanBase}/reset-password?token=${encodeURIComponent(resetToken)}&reset_token=${encodeURIComponent(resetToken)}`;
  const config = getEmailConfig();

  if (!config.configured) {
    console.error('[Email Service Error] SMTP is not configured. Missing SMTP_USER / SMTP_PASSWORD on server.');
    throw new Error('SMTP email delivery is not configured on the server. Please ensure SMTP_HOST, SMTP_PORT, SMTP_USER, and SMTP_PASSWORD are set.');
  }

  const recipientName = userName || toEmail.split('@')[0] || 'Security Engineer';
  const subject = 'AI Bug Hunter - Password Reset Request';
  const textContent = `Hello ${recipientName},

We received a request to reset your password for AI Bug Hunter.

To securely reset your password, click the link below or copy and paste it into your browser:
${resetLink}

This reset link is valid for 15 minutes and can only be used once.

If you did not request this password reset, please ignore this email and your password will remain unchanged.

Best regards,
The AI Bug Hunter Security Team`;

  const htmlContent = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #090d12; color: #f4f4f5; margin: 0; padding: 24px; }
    .card { max-width: 540px; margin: 0 auto; background: #0c1017; border: 1px solid #27272a; border-radius: 12px; padding: 32px; box-shadow: 0 4px 20px rgba(0,0,0,0.5); }
    .brand { font-family: monospace; font-size: 16px; font-weight: bold; color: #10b981; margin-bottom: 24px; letter-spacing: 0.05em; }
    h1 { font-size: 20px; font-weight: 700; color: #f4f4f5; margin-top: 0; }
    p { font-size: 14px; line-height: 1.6; color: #a1a1aa; }
    .btn { display: inline-block; background-color: #059669; color: #ffffff !important; padding: 12px 24px; border-radius: 6px; text-decoration: none; font-weight: 600; font-size: 14px; margin: 20px 0; }
    .token-box { background: #18181b; border: 1px solid #27272a; border-radius: 6px; padding: 12px; font-family: monospace; font-size: 12px; word-break: break-all; color: #10b981; margin: 16px 0; }
    .footer { font-size: 12px; color: #71717a; border-top: 1px solid #27272a; padding-top: 16px; margin-top: 24px; font-family: monospace; }
  </style>
</head>
<body>
  <div class="card">
    <div class="brand">✦ AI BUG HUNTER PRO</div>
    <h1>Password Reset Request</h1>
    <p>Hello <strong>${recipientName}</strong>,</p>
    <p>We received a request to reset your password for your AI Bug Hunter account. Click the button below to set a new password:</p>
    <div style="text-align: center;">
      <a href="${resetLink}" class="btn" target="_blank" rel="noopener noreferrer">Reset Your Password</a>
    </div>
    <p>Or paste this link into your browser:</p>
    <div class="token-box">${resetLink}</div>
    <p style="font-size: 12px; color: #a1a1aa;">This link expires in 15 minutes and can only be used once. If you did not request this, please disregard this email.</p>
    <div class="footer">
      AI Bug Hunter Security Engineering • SAST Static Analysis Platform
    </div>
  </div>
</body>
</html>
  `;

  try {
    const transporter = createTransporter();
    if (!transporter) {
      throw new Error('Failed to create nodemailer transporter.');
    }

    await transporter.sendMail({
      from: `"AI Bug Hunter Security" <${config.fromAddress}>`,
      to: toEmail,
      subject,
      text: textContent,
      html: htmlContent
    });
    console.log(`[Email Service] Password reset email successfully delivered to ${toEmail}`);
    return { sent: true, resetLink };
  } catch (err: any) {
    console.error(`[Email Service Error] Failed to send email via SMTP to ${toEmail}:`, err.message);
    throw new Error(`Email delivery failed: ${err.message}`);
  }
}

