export interface IssueAnalysisResult {
  explanation: string;
  impact: string;
  recommendation: string;
  suggested_fix: string;
  tests?: string[];
  confidence: number | string;
  exploitScenario?: string;
  remediation?: string;
  saferCode?: string;
  assumptions?: string;
}

export interface FixGenerationResult {
  originalCode: string;
  suggestedCode: string;
  explanation: string;
  potentialSideEffects: string[];
  recommendedTests: string[];
}

export interface TestCaseItem {
  name: string;
  description: string;
}

export interface TestGenerationResult {
  language?: string;
  framework: 'pytest' | 'jest' | 'vitest' | 'junit' | string;
  test_code: string;
  testCode: string;
  explanation: string;
  testExplanation: string;
  runInstructions?: string;
  test_cases?: TestCaseItem[];
}

export interface CodeReviewFinding {
  line?: number;
  category: 'Security' | 'Maintainability' | 'Performance' | 'Error Handling' | 'Architecture' | 'Testing';
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';
  title: string;
  description: string;
  recommendation: string;
}

export interface CodeReviewResult {
  summary: string;
  overallScore: number;
  findings: CodeReviewFinding[];
  strengths: string[];
  recommendations: string[];
}

export interface AIProvider {
  name: string;
  isAvailable(): Promise<boolean>;
  explainIssue(context: {
    title: string;
    description: string;
    category: string;
    severity: string;
    filePath: string;
    lineNumber: number;
    codeSnippet: string;
    scanner: string;
    cwe?: string;
  }): Promise<IssueAnalysisResult>;

  generateFix(context: {
    title: string;
    description: string;
    filePath: string;
    lineNumber: number;
    codeSnippet: string;
    surroundingCode?: string;
    cwe?: string;
  }): Promise<FixGenerationResult>;

  generateTests(context: {
    title: string;
    category: string;
    filePath: string;
    codeSnippet: string;
    framework?: string;
  }): Promise<TestGenerationResult>;

  reviewCode(context: {
    filePath: string;
    language: string;
    codeContent: string;
  }): Promise<CodeReviewResult>;
}
