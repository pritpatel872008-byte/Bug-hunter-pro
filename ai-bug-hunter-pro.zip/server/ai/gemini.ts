import { GoogleGenAI, Type } from '@google/genai';
import {
  AIProvider,
  IssueAnalysisResult,
  FixGenerationResult,
  TestGenerationResult,
  CodeReviewResult
} from './provider.ts';

const DEFAULT_GEMINI_MODEL = 'gemini-3.6-flash';

/**
 * Robust JSON extraction and parsing for Gemini responses.
 * Handles markdown backticks, raw control characters, and unescaped backslashes.
 */
function safeParseGeminiJson(rawText: string, contextName: string): any {
  if (!rawText || typeof rawText !== 'string' || rawText.trim() === '') {
    throw new Error('Gemini returned an empty structured response. Please retry.');
  }

  let cleaned = rawText.trim();

  // Strip markdown code fences if present
  if (cleaned.startsWith('```json')) {
    cleaned = cleaned.replace(/^```json\s*/, '').replace(/```\s*$/, '').trim();
  } else if (cleaned.startsWith('```')) {
    cleaned = cleaned.replace(/^```\s*/, '').replace(/```\s*$/, '').trim();
  }

  // 1. Direct JSON parse
  try {
    return JSON.parse(cleaned);
  } catch (firstErr: any) {
    console.warn(`[Gemini Parse Attempt 1 Failed for ${contextName}]: ${firstErr.message}`);

    // 2. Fix unescaped control characters / backslashes in code strings
    try {
      // Fix unescaped invalid escape sequences (e.g. \a \e \v \x or non-escaped backslashes not followed by valid escape)
      const sanitized = cleaned
        .replace(/\\(?!["\\/bfnrtu]|u[0-9a-fA-F]{4})/g, '\\\\')
        // Replace unescaped newlines inside strings (if any)
        .replace(/(?<=:\s*"[^"]*)\n(?=[^"]*")/g, '\\n');

      return JSON.parse(sanitized);
    } catch (secondErr: any) {
      console.error(`[Gemini Safe Parse Failed for ${contextName}]`, {
        error: secondErr.message,
        sample: cleaned.slice(0, 300)
      });
      throw new Error('Gemini returned an invalid structured response. Please retry.');
    }
  }
}

export class GeminiProvider implements AIProvider {
  public get name(): string {
    const model = process.env.AI_MODEL || DEFAULT_GEMINI_MODEL;
    return `Google Gemini (${model})`;
  }

  private getModelName(): string {
    return process.env.AI_MODEL || DEFAULT_GEMINI_MODEL;
  }

  private getClient(): GoogleGenAI {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey.trim() === '') {
      throw new Error('Gemini AI is not configured. Static analysis is still available.');
    }
    return new GoogleGenAI({
      apiKey: apiKey.trim(),
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });
  }

  public async isAvailable(): Promise<boolean> {
    const apiKey = process.env.GEMINI_API_KEY;
    return Boolean(apiKey && apiKey.trim() !== '');
  }

  public async explainIssue(context: {
    title: string;
    description: string;
    category: string;
    severity: string;
    filePath: string;
    lineNumber: number;
    codeSnippet: string;
    scanner: string;
    cwe?: string;
  }): Promise<IssueAnalysisResult> {
    const client = this.getClient();
    const model = this.getModelName();

    const prompt = `You are a Principal Application Security Engineer performing static analysis triaging.
Analyze this REAL vulnerability finding from scanner ${context.scanner}:

File: ${context.filePath} (Line ${context.lineNumber})
Vulnerability: ${context.title} (${context.severity})
Category: ${context.category}
CWE: ${context.cwe || 'N/A'}
Scanner Description: ${context.description}

Code Snippet:
${context.codeSnippet}`;

    const response = await client.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            explanation: {
              type: Type.STRING,
              description: 'Clear, detailed technical explanation of the vulnerability and why this code pattern is unsafe'
            },
            impact: {
              type: Type.STRING,
              description: 'Concrete security and business impact if exploited (e.g. data breach, unauthorized access, RCE)'
            },
            recommendation: {
              type: Type.STRING,
              description: 'Specific practical guidance on how developers should fix this'
            },
            suggested_fix: {
              type: Type.STRING,
              description: 'Safe replacement code snippet'
            },
            tests: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'Defensive test case descriptions'
            },
            confidence: {
              type: Type.NUMBER,
              description: 'Confidence score between 0.0 and 1.0'
            },
            exploitScenario: {
              type: Type.STRING,
              description: 'Step-by-step realistic attack vector showing how an attacker could exploit this vulnerability'
            },
            assumptions: {
              type: Type.STRING,
              description: 'Assumptions made regarding framework or surrounding environment'
            }
          },
          required: ['explanation', 'impact', 'recommendation', 'suggested_fix']
        }
      }
    });

    const parsed = safeParseGeminiJson(response.text || '', 'Issue Analysis');

    if (!parsed || typeof parsed !== 'object') {
      throw new Error('Gemini returned an invalid structured response. Please retry.');
    }

    const explanation = parsed.explanation || parsed.description;
    const impact = parsed.impact;
    const recommendation = parsed.recommendation || parsed.remediation || 'Remediate insecure code pattern.';
    const suggested_fix = parsed.suggested_fix || parsed.saferCode || '// Parameterize query or use safe APIs';

    if (!explanation || !impact) {
      throw new Error('Gemini returned an invalid structured response. Please retry.');
    }

    return {
      explanation,
      impact,
      recommendation,
      suggested_fix,
      tests: Array.isArray(parsed.tests) ? parsed.tests : [],
      confidence: typeof parsed.confidence === 'number' || typeof parsed.confidence === 'string' ? parsed.confidence : 0.95,
      exploitScenario: parsed.exploitScenario,
      remediation: recommendation,
      saferCode: suggested_fix,
      assumptions: parsed.assumptions
    };
  }

  public async generateFix(context: {
    title: string;
    description: string;
    filePath: string;
    lineNumber: number;
    codeSnippet: string;
    surroundingCode?: string;
    cwe?: string;
  }): Promise<FixGenerationResult> {
    const client = this.getClient();
    const model = this.getModelName();

    const prompt = `You are an expert security refactoring engineer.
Generate a verified, safe, non-breaking remediation fix for this vulnerability:

File: ${context.filePath} (Line ${context.lineNumber})
Issue: ${context.title} (${context.cwe || 'CWE'})
Description: ${context.description}

Vulnerable Code Snippet:
${context.codeSnippet}
${context.surroundingCode ? `\nSurrounding Context:\n${context.surroundingCode}` : ''}`;

    const response = await client.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            originalCode: {
              type: Type.STRING,
              description: 'The exact original vulnerable code snippet'
            },
            suggestedCode: {
              type: Type.STRING,
              description: 'The completely fixed, clean, and secure replacement code'
            },
            explanation: {
              type: Type.STRING,
              description: 'Detailed explanation of what changes were made and why this prevents exploitation'
            },
            potentialSideEffects: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'Potential side effects or developer considerations'
            },
            recommendedTests: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'Recommended test cases to write'
            }
          },
          required: ['suggestedCode', 'explanation']
        }
      }
    });

    const parsed = safeParseGeminiJson(response.text || '', 'Fix Generation');

    if (!parsed || typeof parsed !== 'object') {
      throw new Error('Gemini returned an invalid structured response. Please retry.');
    }

    const suggestedCode = parsed.suggestedCode || parsed.suggested_fix || parsed.fix;
    if (!suggestedCode) {
      throw new Error('Gemini returned an invalid structured response. Please retry.');
    }

    return {
      originalCode: parsed.originalCode || context.codeSnippet,
      suggestedCode,
      explanation: parsed.explanation || 'Refactored to eliminate insecure pattern.',
      potentialSideEffects: Array.isArray(parsed.potentialSideEffects)
        ? parsed.potentialSideEffects
        : ['Ensure callers pass validated parameters.'],
      recommendedTests: Array.isArray(parsed.recommendedTests)
        ? parsed.recommendedTests
        : ['Verify with malicious security payload unit test.']
    };
  }

  public async generateTests(context: {
    title: string;
    category: string;
    filePath: string;
    codeSnippet: string;
    framework?: string;
  }): Promise<TestGenerationResult> {
    const client = this.getClient();
    const model = this.getModelName();
    const ext = context.filePath.split('.').pop()?.toLowerCase() || '';

    // Determine target framework and language
    let framework: 'pytest' | 'jest' | 'vitest' | 'junit' = 'jest';
    let language = 'javascript';

    if (context.framework) {
      const f = context.framework.toLowerCase();
      if (f.includes('pytest') || f === 'python') {
        framework = 'pytest';
        language = 'python';
      } else if (f.includes('vitest')) {
        framework = 'vitest';
        language = 'typescript';
      } else if (f.includes('junit') || f === 'java') {
        framework = 'junit';
        language = 'java';
      } else {
        framework = 'jest';
        language = ext === 'ts' || ext === 'tsx' ? 'typescript' : 'javascript';
      }
    } else {
      if (ext === 'py') {
        framework = 'pytest';
        language = 'python';
      } else if (ext === 'java') {
        framework = 'junit';
        language = 'java';
      } else if (ext === 'ts' || ext === 'tsx') {
        framework = 'vitest';
        language = 'typescript';
      }
    }

    const prompt = `You are an automated security test generation engine.
Create an automated defensive security test suite in ${framework} (${language}) that specifically tests and verifies this vulnerability is prevented and malicious payloads are rejected.

Target File: ${context.filePath}
Issue: ${context.title} (${context.category})
Target Test Framework: ${framework}
Language: ${language}

Real Vulnerable Code Context:
\`\`\`${language}
${context.codeSnippet}
\`\`\`

Generate complete, runnable ${framework} test source code inside the "test_code" property.`;

    const response = await client.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            language: {
              type: Type.STRING,
              description: 'Programming language of the test code (e.g. python, javascript, typescript, java)'
            },
            framework: {
              type: Type.STRING,
              description: 'Test framework (e.g. pytest, jest, vitest, junit)'
            },
            test_code: {
              type: Type.STRING,
              description: 'Complete, executable test suite code as a valid string'
            },
            explanation: {
              type: Type.STRING,
              description: 'Why these tests are useful and how they verify vulnerability prevention'
            },
            test_cases: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: {
                    type: Type.STRING,
                    description: 'Test function or method name'
                  },
                  description: {
                    type: Type.STRING,
                    description: 'Description of the test scenario and expected outcome'
                  }
                },
                required: ['name', 'description']
              },
              description: 'List of specific test cases included in the test code'
            }
          },
          required: ['language', 'framework', 'test_code', 'explanation']
        }
      }
    });

    const parsed = safeParseGeminiJson(response.text || '', 'Test Generation');

    if (!parsed || typeof parsed !== 'object') {
      throw new Error('Gemini returned an invalid structured response. Please retry.');
    }

    const testCode = parsed.test_code || parsed.testCode;
    if (!testCode || typeof testCode !== 'string' || testCode.trim() === '') {
      throw new Error('Gemini returned an invalid structured response (empty test_code). Please retry.');
    }

    const explanation = parsed.explanation || parsed.testExplanation || 'Automated defensive test suite verifying exploit prevention.';
    let runCommand = 'npm test';
    if (framework === 'pytest') runCommand = 'pytest -v tests/test_security.py';
    else if (framework === 'vitest') runCommand = 'npx vitest run';
    else if (framework === 'junit') runCommand = 'mvn test -Dtest=SecurityTest';

    return {
      language: parsed.language || language,
      framework,
      test_code: testCode,
      testCode, // alias for backwards compatibility
      explanation,
      testExplanation: explanation, // alias for backwards compatibility
      runInstructions: runCommand,
      test_cases: Array.isArray(parsed.test_cases) ? parsed.test_cases : []
    };
  }

  public async reviewCode(context: {
    filePath: string;
    language: string;
    codeContent: string;
  }): Promise<CodeReviewResult> {
    const client = this.getClient();
    const model = this.getModelName();

    const prompt = `You are a Principal Software Architect and Security Auditor.
Perform an in-depth code review on this file:
File Path: ${context.filePath}
Language: ${context.language}

Source Code:
\`\`\`${context.language}
${context.codeContent.slice(0, 10000)}
\`\`\``;

    const response = await client.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: {
              type: Type.STRING,
              description: 'High-level summary of code quality and security posture'
            },
            overallScore: {
              type: Type.INTEGER,
              description: 'Overall code quality score between 0 and 100'
            },
            findings: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  line: { type: Type.INTEGER, description: 'Line number' },
                  category: { type: Type.STRING, description: 'Category of finding' },
                  severity: { type: Type.STRING, description: 'CRITICAL, HIGH, MEDIUM, LOW, or INFO' },
                  title: { type: Type.STRING, description: 'Short title' },
                  description: { type: Type.STRING, description: 'Clear explanation' },
                  recommendation: { type: Type.STRING, description: 'How to resolve' }
                },
                required: ['category', 'severity', 'title', 'description', 'recommendation']
              }
            },
            strengths: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'List of observed code strengths'
            },
            recommendations: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'List of key architectural recommendations'
            }
          },
          required: ['summary', 'overallScore', 'findings']
        }
      }
    });

    const parsed = safeParseGeminiJson(response.text || '', 'Code Review');

    if (!parsed || typeof parsed !== 'object') {
      throw new Error('Gemini returned an invalid structured response. Please retry.');
    }

    return {
      summary: parsed.summary || 'Code review completed.',
      overallScore: typeof parsed.overallScore === 'number' ? parsed.overallScore : 80,
      findings: Array.isArray(parsed.findings) ? parsed.findings : [],
      strengths: Array.isArray(parsed.strengths) ? parsed.strengths : ['Clean structure and readability'],
      recommendations: Array.isArray(parsed.recommendations) ? parsed.recommendations : ['Add automated defensive tests']
    };
  }
}
