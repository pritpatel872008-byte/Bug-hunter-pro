import {
  AIProvider,
  IssueAnalysisResult,
  FixGenerationResult,
  TestGenerationResult,
  CodeReviewResult
} from './provider.ts';

export class OllamaProvider implements AIProvider {
  public name = 'Ollama (Local LLM)';
  private baseUrl: string;
  private model: string;

  constructor(baseUrl?: string, model?: string) {
    this.baseUrl = baseUrl || process.env.OLLAMA_BASE_URL || 'http://localhost:11434';
    this.model = model || 'codellama';
  }

  public async isAvailable(): Promise<boolean> {
    try {
      const res = await fetch(`${this.baseUrl}/api/tags`, { signal: AbortSignal.timeout(1500) });
      return res.ok;
    } catch {
      return false;
    }
  }

  private async queryOllama(prompt: string): Promise<string> {
    let res: globalThis.Response;
    try {
      res = await fetch(`${this.baseUrl}/api/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: this.model,
          prompt: `${prompt}\n\nPlease output valid JSON only.`,
          stream: false,
          format: 'json'
        }),
        signal: AbortSignal.timeout(30000)
      });
    } catch (err: any) {
      throw new Error('Local Ollama AI is unavailable.');
    }

    if (!res.ok) {
      throw new Error(`Local Ollama AI is unavailable.`);
    }

    const data: any = await res.json();
    return data.response || '{}';
  }

  public async explainIssue(context: any): Promise<IssueAnalysisResult> {
    const isAvail = await this.isAvailable();
    if (!isAvail) {
      throw new Error('Local Ollama AI is unavailable.');
    }

    const prompt = `Analyze this security finding:\nFile: ${context.filePath}:${context.lineNumber}\nVulnerability: ${context.title}\nSnippet: ${context.codeSnippet}\nReturn JSON with keys: explanation, impact, remediation, saferCode, confidence.`;
    const jsonStr = await this.queryOllama(prompt);
    const parsed = JSON.parse(jsonStr);
    const rec = parsed.recommendation || parsed.remediation || 'Remediate vulnerability in source code.';
    const fix = parsed.suggested_fix || parsed.saferCode || '// Use parameterized inputs';
    return {
      explanation: parsed.explanation || 'Ollama local analysis completed.',
      impact: parsed.impact || 'Security risk detected by static analyzer.',
      recommendation: rec,
      suggested_fix: fix,
      remediation: rec,
      saferCode: fix,
      confidence: parsed.confidence || 'MEDIUM'
    };
  }

  public async generateFix(context: any): Promise<FixGenerationResult> {
    const isAvail = await this.isAvailable();
    if (!isAvail) {
      throw new Error('Local Ollama AI is unavailable.');
    }

    const prompt = `Generate fix for vulnerability: ${context.title}\nSnippet: ${context.codeSnippet}\nReturn JSON with keys: originalCode, suggestedCode, explanation, potentialSideEffects, recommendedTests.`;
    const jsonStr = await this.queryOllama(prompt);
    const parsed = JSON.parse(jsonStr);
    return {
      originalCode: parsed.originalCode || context.codeSnippet,
      suggestedCode: parsed.suggestedCode || context.codeSnippet,
      explanation: parsed.explanation || 'Applied local security refactoring.',
      potentialSideEffects: parsed.potentialSideEffects || [],
      recommendedTests: parsed.recommendedTests || []
    };
  }

  public async generateTests(context: any): Promise<TestGenerationResult> {
    const isAvail = await this.isAvailable();
    if (!isAvail) {
      throw new Error('Local Ollama AI is unavailable.');
    }

    const prompt = `Generate test suite for ${context.title}\nCode: ${context.codeSnippet}\nReturn JSON with keys: framework, testCode, testExplanation, runInstructions.`;
    const jsonStr = await this.queryOllama(prompt);
    const parsed = JSON.parse(jsonStr);
    const code = parsed.test_code || parsed.testCode || '# Security test';
    const expl = parsed.explanation || parsed.testExplanation || 'Verifies boundary inputs';
    return {
      language: parsed.language || 'python',
      framework: parsed.framework || 'pytest',
      test_code: code,
      testCode: code,
      explanation: expl,
      testExplanation: expl,
      runInstructions: parsed.runInstructions || 'pytest -v',
      test_cases: parsed.test_cases || []
    };
  }

  public async reviewCode(context: any): Promise<CodeReviewResult> {
    const isAvail = await this.isAvailable();
    if (!isAvail) {
      throw new Error('Local Ollama AI is unavailable.');
    }

    const prompt = `Review code in ${context.filePath}:\n${context.codeContent.slice(0, 4000)}\nReturn JSON with summary, overallScore, findings, strengths, recommendations.`;
    const jsonStr = await this.queryOllama(prompt);
    const parsed = JSON.parse(jsonStr);
    return {
      summary: parsed.summary || 'Local code review',
      overallScore: parsed.overallScore || 75,
      findings: parsed.findings || [],
      strengths: parsed.strengths || [],
      recommendations: parsed.recommendations || []
    };
  }
}
