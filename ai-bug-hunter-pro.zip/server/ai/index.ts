import { AIProvider } from './provider.ts';
import { GeminiProvider } from './gemini.ts';
import { OllamaProvider } from './ollama.ts';

let activeProvider: AIProvider | null = null;
let currentProviderType: 'gemini' | 'ollama' = 'gemini';

export function getAIProvider(): AIProvider {
  const envProvider = (process.env.AI_PROVIDER || 'gemini').toLowerCase().trim();
  const targetType = envProvider === 'ollama' ? 'ollama' : 'gemini';

  if (!activeProvider || currentProviderType !== targetType) {
    currentProviderType = targetType;
    if (targetType === 'ollama') {
      activeProvider = new OllamaProvider();
    } else {
      activeProvider = new GeminiProvider();
    }
  }

  return activeProvider;
}

export function setAIProvider(type: 'gemini' | 'ollama', config?: { ollamaUrl?: string; model?: string }): AIProvider {
  currentProviderType = type;
  if (type === 'ollama') {
    activeProvider = new OllamaProvider(config?.ollamaUrl, config?.model);
  } else {
    activeProvider = new GeminiProvider();
  }
  return activeProvider;
}

export * from './provider.ts';
export * from './gemini.ts';
export * from './ollama.ts';
