export type Severity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';
export type Confidence = 'HIGH' | 'MEDIUM' | 'LOW';
export type IssueCategory =
  | 'Injection'
  | 'Authentication'
  | 'Secrets'
  | 'Cryptography'
  | 'Dependencies'
  | 'Code Quality';

export interface RawFinding {
  id?: string;
  severity: Severity;
  confidence: Confidence;
  category: IssueCategory;
  title: string;
  description: string;
  file_path: string;
  line_number: number;
  code_snippet: string;
  scanner: string;
  cwe?: string;
  recommendation: string;
}

export interface DiscoveredFile {
  relativePath: string;
  absolutePath: string;
  extension: string;
  language: string;
  sizeBytes: number;
  lineCount: number;
  content: string;
}

export interface LanguageStat {
  language: string;
  files: number;
  lines: number;
  percentage: number;
}

export interface ScannerExecutionStatus {
  name: string;
  status: 'COMPLETED' | 'RUNNING' | 'FAILED' | 'NOT_APPLICABLE' | 'UNAVAILABLE';
  findingsCount: number;
  durationMs: number;
  message?: string;
}

export interface ScanResultPayload {
  filesScanned: number;
  linesScanned: number;
  languages: LanguageStat[];
  scannersExecuted: ScannerExecutionStatus[];
  findings: RawFinding[];
  dependencies: {
    package_name: string;
    version: string;
    severity: Severity;
    vulnerability: string;
  }[];
}
