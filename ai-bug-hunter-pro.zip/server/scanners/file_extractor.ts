import AdmZip from 'adm-zip';
import fs from 'node:fs';
import path from 'node:path';
import { DiscoveredFile, LanguageStat } from './types.ts';

const MAX_ZIP_SIZE = 50 * 1024 * 1024; // 50MB
const MAX_FILE_COUNT = 5000;
const MAX_TOTAL_UNCOMPRESSED_SIZE = 150 * 1024 * 1024; // 150MB

const IGNORED_DIRS = new Set([
  'node_modules',
  '.git',
  '.svn',
  '.hg',
  '__pycache__',
  '.pytest_cache',
  'venv',
  '.venv',
  'env',
  'dist',
  'build',
  '.idea',
  '.vscode',
  'vendor',
  'target',
  '.next',
  '.nuget'
]);

const EXTENSION_TO_LANGUAGE: Record<string, string> = {
  '.py': 'Python',
  '.pyw': 'Python',
  '.js': 'JavaScript',
  '.jsx': 'JavaScript',
  '.mjs': 'JavaScript',
  '.cjs': 'JavaScript',
  '.ts': 'TypeScript',
  '.tsx': 'TypeScript',
  '.java': 'Java',
  '.go': 'Go',
  '.rs': 'Rust',
  '.c': 'C',
  '.h': 'C',
  '.cpp': 'C++',
  '.hpp': 'C++',
  '.cc': 'C++',
  '.php': 'PHP',
  '.rb': 'Ruby',
  '.sh': 'Shell',
  '.bash': 'Shell',
  '.sql': 'SQL',
  '.html': 'HTML',
  '.json': 'JSON',
  '.yaml': 'YAML',
  '.yml': 'YAML',
  '.xml': 'XML',
  '.env': 'Configuration',
  '.config': 'Configuration'
};

const BINARY_EXTENSIONS = new Set([
  '.png', '.jpg', '.jpeg', '.gif', '.ico', '.svg', '.webp',
  '.pdf', '.zip', '.tar', '.gz', '.7z', '.rar', '.exe', '.dll',
  '.so', '.dylib', '.bin', '.wasm', '.woff', '.woff2', '.ttf',
  '.eot', '.mp3', '.mp4', '.mov', '.sqlite', '.db'
]);

export interface ExtractionResult {
  targetDir: string;
  files: DiscoveredFile[];
  languages: LanguageStat[];
  totalFiles: number;
  totalLines: number;
}

/**
 * Safely extracts a ZIP buffer into a designated sandbox directory,
 * strictly preventing path traversal attacks and zip bombs.
 */
export function extractZipSafely(zipBuffer: Buffer, targetDir: string): void {
  if (!zipBuffer || zipBuffer.length === 0) {
    throw new Error('ZIP file buffer is empty.');
  }

  if (zipBuffer.length > MAX_ZIP_SIZE) {
    throw new Error(`ZIP file exceeds maximum allowed size of ${MAX_ZIP_SIZE / 1024 / 1024}MB`);
  }

  if (!fs.existsSync(targetDir)) {
    fs.mkdirSync(targetDir, { recursive: true });
  }

  let zip: AdmZip;
  try {
    zip = new AdmZip(zipBuffer);
  } catch (err: any) {
    throw new Error(`Invalid or corrupted ZIP archive: ${err.message}`);
  }

  let zipEntries;
  try {
    zipEntries = zip.getEntries();
  } catch (err: any) {
    throw new Error(`Failed to read ZIP entries: ${err.message}`);
  }

  if (zipEntries.length > MAX_FILE_COUNT) {
    throw new Error(`ZIP contains too many files (${zipEntries.length} > ${MAX_FILE_COUNT})`);
  }

  let totalUncompressed = 0;
  const resolvedTarget = path.resolve(targetDir);

  for (const entry of zipEntries) {
    if (entry.isDirectory) continue;

    totalUncompressed += entry.header.size;
    if (totalUncompressed > MAX_TOTAL_UNCOMPRESSED_SIZE) {
      throw new Error(`Extracted ZIP contents exceed maximum uncompressed limit of ${MAX_TOTAL_UNCOMPRESSED_SIZE / 1024 / 1024}MB (potential zip bomb)`);
    }

    // Path traversal check
    const entryName = entry.entryName.replace(/\\/g, '/');
    const safePath = path.normalize(entryName).replace(/^(\.\.(\/|\\|$))+/, '');
    const fullPath = path.resolve(resolvedTarget, safePath);

    if (!fullPath.startsWith(resolvedTarget + path.sep) && fullPath !== resolvedTarget) {
      throw new Error(`Security Violation: Illegal path traversal detected in entry: ${entry.entryName}`);
    }

    // Write file safely
    const parentDir = path.dirname(fullPath);
    if (!fs.existsSync(parentDir)) {
      fs.mkdirSync(parentDir, { recursive: true });
    }

    fs.writeFileSync(fullPath, entry.getData());
  }
}

/**
 * Recursively scans directory and discovers all valid source code files
 */
export function discoverFiles(dir: string, baseDir?: string): DiscoveredFile[] {
  const root = baseDir || dir;
  const discovered: DiscoveredFile[] = [];

  if (!fs.existsSync(dir)) return discovered;

  const entries = fs.readdirSync(dir, { withFileTypes: true });

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    const relPath = path.relative(root, fullPath).replace(/\\/g, '/');

    if (entry.isDirectory()) {
      if (IGNORED_DIRS.has(entry.name) || entry.name.startsWith('.')) {
        continue;
      }
      discovered.push(...discoverFiles(fullPath, root));
    } else if (entry.isFile()) {
      const ext = path.extname(entry.name).toLowerCase();
      if (BINARY_EXTENSIONS.has(ext)) continue;

      const stat = fs.statSync(fullPath);
      // Skip files larger than 2MB
      if (stat.size > 2 * 1024 * 1024) continue;

      try {
        const content = fs.readFileSync(fullPath, 'utf8');
        const lines = content.split('\n').length;
        const language = EXTENSION_TO_LANGUAGE[ext] || 'Text';

        discovered.push({
          relativePath: relPath,
          absolutePath: fullPath,
          extension: ext,
          language,
          sizeBytes: stat.size,
          lineCount: lines,
          content
        });
      } catch {
        // Skip unreadable files
      }
    }
  }

  return discovered;
}

/**
 * Calculates language breakdown statistics from discovered files
 */
export function calculateLanguageStats(files: DiscoveredFile[]): LanguageStat[] {
  const map: Record<string, { files: number; lines: number }> = {};
  let totalLines = 0;

  for (const file of files) {
    if (!map[file.language]) {
      map[file.language] = { files: 0, lines: 0 };
    }
    map[file.language].files += 1;
    map[file.language].lines += file.lineCount;
    totalLines += file.lineCount;
  }

  const stats: LanguageStat[] = Object.entries(map).map(([language, data]) => ({
    language,
    files: data.files,
    lines: data.lines,
    percentage: totalLines > 0 ? Math.round((data.lines / totalLines) * 100) : 0
  }));

  stats.sort((a, b) => b.lines - a.lines);
  return stats;
}
