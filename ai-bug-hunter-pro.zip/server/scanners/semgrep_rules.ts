import { DiscoveredFile, RawFinding } from './types.ts';

interface SemgrepRule {
  id: string;
  name: string;
  category: 'Injection' | 'Authentication' | 'Cryptography' | 'Code Quality';
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';
  confidence: 'HIGH' | 'MEDIUM' | 'LOW';
  languages: string[];
  cwe: string;
  description: string;
  recommendation: string;
  check: (line: string, fileContent: string, lineIdx: number) => boolean;
}

const SEMGREP_RULES: SemgrepRule[] = [
  {
    id: 'generic.ssrf.axios-or-fetch-untrusted-url',
    name: 'Server-Side Request Forgery (SSRF) Risk',
    category: 'Injection',
    severity: 'HIGH',
    confidence: 'HIGH',
    languages: ['JavaScript', 'TypeScript', 'Python', 'Go', 'Java'],
    cwe: 'CWE-918',
    description: 'Making outgoing HTTP requests directly to an unvalidated URL provided by user input allows attackers to scan internal networks or access cloud instance metadata (e.g. 169.254.169.254).',
    recommendation: 'Validate and whitelist allowed target domains/schemes. Block loopback (127.0.0.1, localhost) and private IP ranges (10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, 169.254.169.254).',
    check: (line) => /(?:axios\.get|axios\.post|fetch|requests\.get|requests\.post|http\.get)\s*\(\s*(?:req\.|params\.|query\.|user_input|url|target_url)/i.test(line)
  },
  {
    id: 'generic.xxe.xml-external-entity-enabled',
    name: 'XML External Entity (XXE) Injection',
    category: 'Injection',
    severity: 'HIGH',
    confidence: 'HIGH',
    languages: ['Python', 'Java', 'PHP', 'JavaScript', 'TypeScript'],
    cwe: 'CWE-611',
    description: 'Parsing XML documents with external entity resolution or DTD processing enabled allows attackers to read arbitrary files and conduct internal port scanning.',
    recommendation: 'Disable DTD processing and external entity resolution in XML parsers (e.g. resolve_entities=False, disallow_doctype=True).',
    check: (line) => /(?:etree\.parse|XMLParser|DocumentBuilderFactory|saxParser)\s*\(.*resolve_entities\s*=\s*True/i.test(line) ||
      (/FEATURE_SECURE_PROCESSING/i.test(line) && /false/i.test(line))
  },
  {
    id: 'generic.sql.concatenation-in-query',
    name: 'Generic SQL Injection via String Concatenation',
    category: 'Injection',
    severity: 'CRITICAL',
    confidence: 'HIGH',
    languages: ['JavaScript', 'TypeScript', 'Java', 'PHP', 'Go', 'Rust', 'C++'],
    cwe: 'CWE-89',
    description: 'SQL query built by joining strings directly with request parameters. An attacker can break query structure to exfiltrate or tamper with data.',
    recommendation: 'Use parameterized queries ($1, ?), prepared statements, or query builders that automatically escape input.',
    check: (line) => /(?:SELECT|INSERT|UPDATE|DELETE)\s+.*(?:FROM|INTO|SET|WHERE)\s+.*['"`]\s*\+\s*(?:req\.|input|id|user|query)/i.test(line) ||
      /(?:pool|client|connection|db)\.query\s*\(\s*`.*(?:SELECT|INSERT|UPDATE|DELETE).*\$\{/i.test(line)
  },
  {
    id: 'generic.crypto.hardcoded-aes-key-iv',
    name: 'Static / Hardcoded Initialization Vector (IV) or Key',
    category: 'Cryptography',
    severity: 'HIGH',
    confidence: 'HIGH',
    languages: ['JavaScript', 'TypeScript', 'Python', 'Java', 'Go'],
    cwe: 'CWE-329',
    description: 'Static IV or hardcoded encryption key detected in cipher setup. Reusing an IV with symmetric ciphers (like AES-GCM or AES-CBC) destroys cryptographic confidentiality.',
    recommendation: 'Generate a unique, cryptographically random IV for every encryption operation using a secure RNG.',
    check: (line) => /crypto\.createCipheriv\s*\(\s*['"][^'"]+['"]\s*,\s*['"][^'"]+['"]\s*,\s*['"][^'"]+['"]\s*\)/i.test(line) ||
      /AES\.new\s*\(.*IV\s*=\s*b?['"][^'"]+['"]/i.test(line)
  },
  {
    id: 'generic.auth.jwt-none-algorithm',
    name: 'JWT Insecure "none" Algorithm Permitted',
    category: 'Authentication',
    severity: 'CRITICAL',
    confidence: 'HIGH',
    languages: ['JavaScript', 'TypeScript', 'Python', 'Go', 'Java'],
    cwe: 'CWE-347',
    description: 'Allowing the "none" algorithm in JWT verification disables cryptographic signature checks, letting attackers forge tokens with arbitrary claims.',
    recommendation: 'Enforce specific algorithms in verification options (e.g. algorithms: ["HS256"] or ["RS256"]). Never permit "none".',
    check: (line) => /algorithms\s*:\s*\[.*['"]none['"].*\]/i.test(line) || /jwt\.decode\(.*verify\s*=\s*False/i.test(line)
  },
  {
    id: 'generic.dos.regex-redos',
    name: 'Potential ReDoS (Regular Expression Denial of Service)',
    category: 'Code Quality',
    severity: 'MEDIUM',
    confidence: 'MEDIUM',
    languages: ['JavaScript', 'TypeScript', 'Python', 'Java', 'PHP'],
    cwe: 'CWE-1333',
    description: 'Nested quantifiers in regular expression (e.g. (a+)+ or (.*)+) can cause catastrophic backtracking on non-matching inputs, exhausting CPU resources.',
    recommendation: 'Refactor regular expressions to eliminate nested repetitions, or use linear-time regex engines such as RE2.',
    check: (line) => /\([^)]*[\+\*]\)[\+\*]|\(\.\*[\+\*]\)/.test(line)
  }
];

export function runSemgrepScan(files: DiscoveredFile[]): RawFinding[] {
  const findings: RawFinding[] = [];

  for (const file of files) {
    const lines = file.content.split('\n');

    for (let lineIdx = 0; lineIdx < lines.length; lineIdx++) {
      const line = lines[lineIdx];
      const lineNum = lineIdx + 1;

      // Skip comment lines
      if (/^\s*(\/\/|#|\*)/.test(line)) continue;

      for (const rule of SEMGREP_RULES) {
        if (!rule.languages.includes(file.language)) continue;

        if (rule.check(line, file.content, lineIdx)) {
          const start = Math.max(0, lineIdx - 1);
          const end = Math.min(lines.length - 1, lineIdx + 1);
          const snippet = lines.slice(start, end + 1).join('\n');

          findings.push({
            severity: rule.severity,
            confidence: rule.confidence,
            category: rule.category,
            title: rule.name,
            description: rule.description,
            file_path: file.relativePath,
            line_number: lineNum,
            code_snippet: snippet,
            scanner: 'Semgrep',
            cwe: rule.cwe,
            recommendation: rule.recommendation
          });
        }
      }
    }
  }

  return findings;
}
