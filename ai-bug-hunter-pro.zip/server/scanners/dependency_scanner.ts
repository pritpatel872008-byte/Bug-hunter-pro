import { DiscoveredFile, RawFinding, Severity } from './types.ts';

interface VulnerableDependency {
  package_name: string;
  affectedVersionRegex: RegExp;
  fixedVersion: string;
  severity: Severity;
  vulnerability: string;
  cwe: string;
}

// Known vulnerable packages and CVE advisories database
const KNOWN_VULNERABILITIES: Record<string, VulnerableDependency[]> = {
  // Node / npm packages
  'lodash': [
    {
      package_name: 'lodash',
      affectedVersionRegex: /^4\.(?:[0-9]|1[0-6])\./,
      fixedVersion: '4.17.21',
      severity: 'HIGH',
      vulnerability: 'CVE-2021-23337: Prototype Pollution in template and zipObjectDeep',
      cwe: 'CWE-1321'
    }
  ],
  'axios': [
    {
      package_name: 'axios',
      affectedVersionRegex: /^(?:0\.|1\.[0-6]\.)/,
      fixedVersion: '1.7.4',
      severity: 'HIGH',
      vulnerability: 'CVE-2023-45857: Cross-Site Request Forgery & SSRF via relative URL handling',
      cwe: 'CWE-918'
    }
  ],
  'express': [
    {
      package_name: 'express',
      affectedVersionRegex: /^(?:[0-3]\.|4\.(?:[0-9]|1[0-8])\.)/,
      fixedVersion: '4.19.2',
      severity: 'HIGH',
      vulnerability: 'CVE-2024-29041: Open Redirect and Path Traversal in static router',
      cwe: 'CWE-601'
    }
  ],
  'jsonwebtoken': [
    {
      package_name: 'jsonwebtoken',
      affectedVersionRegex: /^[0-8]\./,
      fixedVersion: '9.0.0',
      severity: 'CRITICAL',
      vulnerability: 'CVE-2022-23529: Insecure Default Secret and Algorithm Verification Bypass',
      cwe: 'CWE-347'
    }
  ],
  // Python packages
  'requests': [
    {
      package_name: 'requests',
      affectedVersionRegex: /^(?:1\.|2\.(?:[0-9]|1[0-9]|2[0-9]|30)\.)/,
      fixedVersion: '2.31.0',
      severity: 'HIGH',
      vulnerability: 'CVE-2023-32681: Unintended leak of Proxy-Authorization headers on redirects',
      cwe: 'CWE-200'
    }
  ],
  'django': [
    {
      package_name: 'django',
      affectedVersionRegex: /^(?:[0-3]\.|4\.[0-1]\.)/,
      fixedVersion: '4.2.11',
      severity: 'CRITICAL',
      vulnerability: 'CVE-2024-27351: Regular Expression Denial of Service in django.utils.text.Truncator',
      cwe: 'CWE-1333'
    }
  ],
  'flask': [
    {
      package_name: 'flask',
      affectedVersionRegex: /^[01]\./,
      fixedVersion: '2.2.5',
      severity: 'MEDIUM',
      vulnerability: 'CVE-2023-30861: Session Cookie Security and Cleartext Leakage',
      cwe: 'CWE-312'
    }
  ],
  'cryptography': [
    {
      package_name: 'cryptography',
      affectedVersionRegex: /^(?:[0-3][0-9]\.|4[0-1]\.)/,
      fixedVersion: '42.0.4',
      severity: 'HIGH',
      vulnerability: 'CVE-2024-26130: Null pointer dereference in PKCS#12 parsing',
      cwe: 'CWE-476'
    }
  ]
};

export interface DependencyAuditResult {
  findings: RawFinding[];
  dependencies: {
    package_name: string;
    version: string;
    severity: Severity;
    vulnerability: string;
  }[];
}

export function runDependencyScan(files: DiscoveredFile[]): DependencyAuditResult {
  const findings: RawFinding[] = [];
  const dependencies: DependencyAuditResult['dependencies'] = [];

  // 1. Scan package.json
  const packageJsonFiles = files.filter(f => f.relativePath.endsWith('package.json'));
  for (const file of packageJsonFiles) {
    try {
      const parsed = JSON.parse(file.content);
      const allDeps = {
        ...parsed.dependencies,
        ...parsed.devDependencies
      };

      for (const [pkg, rawVersion] of Object.entries(allDeps)) {
        const verStr = String(rawVersion).replace(/[\^~>=<]/g, '').trim();
        const knownList = KNOWN_VULNERABILITIES[pkg.toLowerCase()];

        if (knownList) {
          for (const known of knownList) {
            if (known.affectedVersionRegex.test(verStr)) {
              dependencies.push({
                package_name: pkg,
                version: verStr,
                severity: known.severity,
                vulnerability: known.vulnerability
              });

              findings.push({
                severity: known.severity,
                confidence: 'HIGH',
                category: 'Dependencies',
                title: `Vulnerable Dependency: ${pkg}@${verStr}`,
                description: `${known.vulnerability}. Installed package version ${verStr} contains known security vulnerabilities.`,
                file_path: file.relativePath,
                line_number: 1,
                code_snippet: `"${pkg}": "${rawVersion}"`,
                scanner: 'DependencyCheck',
                cwe: known.cwe,
                recommendation: `Upgrade ${pkg} to version ${known.fixedVersion} or higher immediately.`
              });
            }
          }
        }
      }
    } catch {
      // Invalid JSON syntax in file, skip
    }
  }

  // 2. Scan requirements.txt
  const reqFiles = files.filter(f => f.relativePath.toLowerCase().endsWith('requirements.txt'));
  for (const file of reqFiles) {
    const lines = file.content.split('\n');
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line || line.startsWith('#')) continue;

      const match = line.match(/^([a-zA-Z0-9_\-]+)\s*(?:==|>=|<=|~=)\s*([0-9a-zA-Z\.\-]+)/);
      if (match) {
        const pkg = match[1].toLowerCase();
        const verStr = match[2];
        const knownList = KNOWN_VULNERABILITIES[pkg];

        if (knownList) {
          for (const known of knownList) {
            if (known.affectedVersionRegex.test(verStr)) {
              dependencies.push({
                package_name: pkg,
                version: verStr,
                severity: known.severity,
                vulnerability: known.vulnerability
              });

              findings.push({
                severity: known.severity,
                confidence: 'HIGH',
                category: 'Dependencies',
                title: `Vulnerable Python Package: ${pkg}==${verStr}`,
                description: `${known.vulnerability}.`,
                file_path: file.relativePath,
                line_number: i + 1,
                code_snippet: line,
                scanner: 'DependencyCheck',
                cwe: known.cwe,
                recommendation: `Update ${pkg} to >= ${known.fixedVersion} in requirements.txt.`
              });
            }
          }
        }
      }
    }
  }

  return { findings, dependencies };
}
