import { DiscoveredFile, RawFinding } from './types.ts';

interface EslintRule {
  id: string;
  name: string;
  category: 'Injection' | 'Authentication' | 'Cryptography' | 'Code Quality';
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';
  confidence: 'HIGH' | 'MEDIUM' | 'LOW';
  cwe: string;
  description: string;
  recommendation: string;
  check: (line: string, fileContent: string, lineIdx: number) => boolean;
}

const ESLINT_RULES: EslintRule[] = [
  {
    id: 'security/detect-eval-with-expr',
    name: 'Dynamic Code Execution via eval() or Function constructor',
    category: 'Injection',
    severity: 'CRITICAL',
    confidence: 'HIGH',
    cwe: 'CWE-95',
    description: 'Use of eval() or new Function() allows executing arbitrary strings as JavaScript, opening the app to XSS and arbitrary code execution.',
    recommendation: 'Refactor code to avoid eval(). Use JSON.parse() for data or safe parser libraries for expressions.',
    check: (line) => /\beval\s*\(/i.test(line) || /new\s+Function\s*\(/i.test(line) || /setTimeout\s*\(\s*['"`]/i.test(line)
  },
  {
    id: 'security/detect-unsafe-innerhtml',
    name: 'DOM XSS via innerHTML / dangerouslySetInnerHTML',
    category: 'Injection',
    severity: 'HIGH',
    confidence: 'HIGH',
    cwe: 'CWE-79',
    description: 'Setting innerHTML, outerHTML, or React dangerouslySetInnerHTML with unvalidated content enables Cross-Site Scripting (XSS) attacks.',
    recommendation: 'Use textContent, innerText, or sanitize inputs with DOMPurify / sanitize-html before injecting into DOM.',
    check: (line) => /\.innerHTML\s*=/i.test(line) || /\.outerHTML\s*=/i.test(line) || /dangerouslySetInnerHTML\s*=\s*\{\s*\{\s*__html\s*:/i.test(line)
  },
  {
    id: 'security/detect-child-process',
    name: 'Unsafe Node.js Child Process Execution',
    category: 'Injection',
    severity: 'CRITICAL',
    confidence: 'HIGH',
    cwe: 'CWE-78',
    description: 'Spawning child processes with exec() or execSync() executes commands within a system shell. If user arguments are concatenated, it yields Command Injection.',
    recommendation: 'Use execFile() or spawn() with argument arrays (e.g. spawn("cmd", [arg1, arg2])) to avoid shell parsing.',
    check: (line) => /(?:child_process|cp)\.(?:exec|execSync)\s*\(/i.test(line) || /(?:exec|execSync)\s*\(\s*`.*\$\{/i.test(line)
  },
  {
    id: 'security/detect-object-injection',
    name: 'Prototype Pollution / Unsafe Object Key Assignment',
    category: 'Code Quality',
    severity: 'HIGH',
    confidence: 'MEDIUM',
    cwe: 'CWE-1321',
    description: 'Direct assignment to object properties using unvalidated user keys (e.g. obj[userKey] or __proto__) can corrupt Object prototype and cause denial of service or code execution.',
    recommendation: 'Validate property keys, reject "__proto__", "constructor", and "prototype", or use Map instead of plain objects.',
    check: (line) => /__proto__|prototype\[|constructor\.prototype/i.test(line)
  },
  {
    id: 'security/detect-non-literal-fs-filename',
    name: 'Path Traversal via Dynamic File System Access',
    category: 'Injection',
    severity: 'HIGH',
    confidence: 'HIGH',
    cwe: 'CWE-22',
    description: 'Reading or writing files using dynamic user-controlled paths without validation allows arbitrary file access and directory traversal.',
    recommendation: 'Sanitize file paths using path.normalize(), path.resolve(), and verify the resolved path remains inside the intended directory.',
    check: (line) => /fs\.(?:readFileSync|writeFileSync|readFile|writeFile|createReadStream|createWriteStream|unlinkSync|unlink)\s*\(\s*(?:req\.|params\.|query\.|body\.|`.*\$\{)/i.test(line)
  },
  {
    id: 'security/detect-loose-equality-auth',
    name: 'Loose Equality (==) on Security Token or Hash',
    category: 'Authentication',
    severity: 'MEDIUM',
    confidence: 'MEDIUM',
    cwe: 'CWE-208',
    description: 'Using loose equality (==) or non-constant-time string comparison for passwords/tokens can lead to type coercion bugs and timing attacks.',
    recommendation: 'Use crypto.timingSafeEqual() for cryptographic verification or strict equality (===) with fixed length.',
    check: (line) => /(?:token|password|hash|signature|secret)\s*==\s*[a-zA-Z0-9_]+/i.test(line)
  },
  {
    id: 'security/detect-weak-crypto-random',
    name: 'Weak Pseudo-Randomness (Math.random) in Security Context',
    category: 'Cryptography',
    severity: 'LOW',
    confidence: 'HIGH',
    cwe: 'CWE-338',
    description: 'Math.random() produces deterministic values that an attacker can predict. Never use Math.random() for security tokens, passwords, or encryption IVs.',
    recommendation: 'Use Node.js crypto.randomBytes() or Web Crypto API crypto.getRandomValues().',
    check: (line) => /Math\.random\(\)/i.test(line) && /(?:token|secret|password|nonce|otp|session|key|salt|iv)/i.test(line)
  },
  {
    id: 'security/detect-open-cors',
    name: 'Permissive CORS Configuration (Access-Control-Allow-Origin: *)',
    category: 'Authentication',
    severity: 'MEDIUM',
    confidence: 'HIGH',
    cwe: 'CWE-942',
    description: 'Configuring Access-Control-Allow-Origin: * on API routes handling authenticated user sessions can expose private endpoints to third-party domains.',
    recommendation: 'Whitelist explicit trusted origins and avoid setting credentials: true with wildcard origin.',
    check: (line) => /(?:Access-Control-Allow-Origin|origin)\s*[:=]\s*['"]\*['"]/i.test(line) && /(?:credentials|auth|cookie|session)/i.test(line)
  }
];

export function runEslintScan(files: DiscoveredFile[]): RawFinding[] {
  const findings: RawFinding[] = [];
  const jsTsFiles = files.filter(f => ['JavaScript', 'TypeScript'].includes(f.language));

  for (const file of jsTsFiles) {
    const lines = file.content.split('\n');

    for (let lineIdx = 0; lineIdx < lines.length; lineIdx++) {
      const line = lines[lineIdx];
      const lineNum = lineIdx + 1;

      // Skip comments
      if (/^\s*\/\//.test(line) || /^\s*\*/.test(line)) continue;

      for (const rule of ESLINT_RULES) {
        if (rule.check(line, file.content, lineIdx)) {
          const start = Math.max(0, lineIdx - 1);
          const end = Math.min(lines.length - 1, lineIdx + 1);
          const snippet = lines.slice(start, end + 1).join('\n');

          findings.push({
            severity: rule.severity,
            confidence: rule.confidence,
            category: rule.category,
            title: rule.name,
            description: rule.description,
            file_path: file.relativePath,
            line_number: lineNum,
            code_snippet: snippet,
            scanner: 'ESLint',
            cwe: rule.cwe,
            recommendation: rule.recommendation
          });
        }
      }
    }
  }

  return findings;
}
