import { DiscoveredFile, RawFinding, ScanResultPayload, ScannerExecutionStatus } from './types.ts';
import { runGitleaksScan } from './gitleaks_rules.ts';
import { runBanditScan } from './bandit_rules.ts';
import { runEslintScan } from './eslint_rules.ts';
import { runSemgrepScan } from './semgrep_rules.ts';
import { runDependencyScan } from './dependency_scanner.ts';
import { calculateLanguageStats } from './file_extractor.ts';

const SEVERITY_ORDER: Record<string, number> = {
  CRITICAL: 0,
  HIGH: 1,
  MEDIUM: 2,
  LOW: 3,
  INFO: 4
};

export async function runCompleteScanPipeline(
  files: DiscoveredFile[],
  logCallback?: (message: string, level?: string) => void
): Promise<ScanResultPayload> {
  const log = (msg: string, lvl: string = 'INFO') => {
    if (logCallback) logCallback(msg, lvl);
  };

  log(`Discovered ${files.length} source code files across repository.`);
  const languages = calculateLanguageStats(files);
  const totalLines = files.reduce((acc, f) => acc + f.lineCount, 0);

  const scannersExecuted: ScannerExecutionStatus[] = [];
  const rawFindings: RawFinding[] = [];

  // 1. Semgrep SAST Scanner
  log('Executing Semgrep static analysis engine...');
  const semgrepStart = Date.now();
  try {
    const semgrepFindings = runSemgrepScan(files);
    scannersExecuted.push({
      name: 'Semgrep',
      status: 'COMPLETED',
      findingsCount: semgrepFindings.length,
      durationMs: Date.now() - semgrepStart
    });
    rawFindings.push(...semgrepFindings);
    log(`Semgrep scan completed (${semgrepFindings.length} findings)`);
  } catch (err: any) {
    scannersExecuted.push({
      name: 'Semgrep',
      status: 'FAILED',
      findingsCount: 0,
      durationMs: Date.now() - semgrepStart,
      message: err.message
    });
    log(`Semgrep error: ${err.message}`, 'WARN');
  }

  // 2. Gitleaks Secret Scanner
  log('Executing Gitleaks secret detection scanner...');
  const gitleaksStart = Date.now();
  try {
    const gitleaksFindings = runGitleaksScan(files);
    scannersExecuted.push({
      name: 'Gitleaks',
      status: 'COMPLETED',
      findingsCount: gitleaksFindings.length,
      durationMs: Date.now() - gitleaksStart
    });
    rawFindings.push(...gitleaksFindings);
    log(`Gitleaks scan completed (${gitleaksFindings.length} secrets identified)`);
  } catch (err: any) {
    scannersExecuted.push({
      name: 'Gitleaks',
      status: 'FAILED',
      findingsCount: 0,
      durationMs: Date.now() - gitleaksStart,
      message: err.message
    });
    log(`Gitleaks error: ${err.message}`, 'WARN');
  }

  // 3. Bandit Python Scanner
  const hasPython = files.some(f => f.language === 'Python');
  const banditStart = Date.now();
  if (hasPython) {
    log('Executing Bandit Python vulnerability analyzer...');
    try {
      const banditFindings = runBanditScan(files);
      scannersExecuted.push({
        name: 'Bandit',
        status: 'COMPLETED',
        findingsCount: banditFindings.length,
        durationMs: Date.now() - banditStart
      });
      rawFindings.push(...banditFindings);
      log(`Bandit scan completed (${banditFindings.length} findings)`);
    } catch (err: any) {
      scannersExecuted.push({
        name: 'Bandit',
        status: 'FAILED',
        findingsCount: 0,
        durationMs: Date.now() - banditStart,
        message: err.message
      });
      log(`Bandit error: ${err.message}`, 'WARN');
    }
  } else {
    scannersExecuted.push({
      name: 'Bandit',
      status: 'NOT_APPLICABLE',
      findingsCount: 0,
      durationMs: 0,
      message: 'No Python source files detected'
    });
  }

  // 4. ESLint / JS Security Scanner
  const hasJsTs = files.some(f => ['JavaScript', 'TypeScript'].includes(f.language));
  const eslintStart = Date.now();
  if (hasJsTs) {
    log('Executing ESLint JS/TS security analyzer...');
    try {
      const eslintFindings = runEslintScan(files);
      scannersExecuted.push({
        name: 'ESLint',
        status: 'COMPLETED',
        findingsCount: eslintFindings.length,
        durationMs: Date.now() - eslintStart
      });
      rawFindings.push(...eslintFindings);
      log(`ESLint scan completed (${eslintFindings.length} findings)`);
    } catch (err: any) {
      scannersExecuted.push({
        name: 'ESLint',
        status: 'FAILED',
        findingsCount: 0,
        durationMs: Date.now() - eslintStart,
        message: err.message
      });
      log(`ESLint error: ${err.message}`, 'WARN');
    }
  } else {
    scannersExecuted.push({
      name: 'ESLint',
      status: 'NOT_APPLICABLE',
      findingsCount: 0,
      durationMs: 0,
      message: 'No JS/TS source files detected'
    });
  }

  // 5. Dependency Audit Scanner
  log('Executing Dependency vulnerability audit...');
  const depStart = Date.now();
  let depResults = { findings: [] as RawFinding[], dependencies: [] as any[] };
  try {
    depResults = runDependencyScan(files);
    scannersExecuted.push({
      name: 'DependencyCheck',
      status: 'COMPLETED',
      findingsCount: depResults.findings.length,
      durationMs: Date.now() - depStart
    });
    rawFindings.push(...depResults.findings);
    log(`Dependency audit completed (${depResults.dependencies.length} packages analyzed)`);
  } catch (err: any) {
    scannersExecuted.push({
      name: 'DependencyCheck',
      status: 'FAILED',
      findingsCount: 0,
      durationMs: Date.now() - depStart,
      message: err.message
    });
    log(`Dependency check error: ${err.message}`, 'WARN');
  }

  // Finding Deduplication
  const seenKey = new Set<string>();
  const deduplicated: RawFinding[] = [];

  for (const finding of rawFindings) {
    const key = `${finding.file_path}:${finding.line_number}:${finding.category}:${finding.title}`;
    if (!seenKey.has(key)) {
      seenKey.add(key);
      deduplicated.push(finding);
    }
  }

  // Sort by Severity (CRITICAL -> INFO)
  deduplicated.sort((a, b) => (SEVERITY_ORDER[a.severity] ?? 5) - (SEVERITY_ORDER[b.severity] ?? 5));

  log(`Normalized and deduplicated to ${deduplicated.length} verified security issues.`);

  return {
    filesScanned: files.length,
    linesScanned: totalLines,
    languages,
    scannersExecuted,
    findings: deduplicated,
    dependencies: depResults.dependencies
  };
}
