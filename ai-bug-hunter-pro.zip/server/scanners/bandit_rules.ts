import { DiscoveredFile, RawFinding } from './types.ts';

interface BanditRule {
  id: string;
  name: string;
  category: 'Injection' | 'Authentication' | 'Cryptography' | 'Code Quality' | 'Secrets';
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';
  confidence: 'HIGH' | 'MEDIUM' | 'LOW';
  cwe: string;
  description: string;
  recommendation: string;
  check: (line: string, fileContent: string, lineIdx: number) => boolean;
}

const BANDIT_RULES: BanditRule[] = [
  {
    id: 'B101-assert_used',
    name: 'Assert Statement Used for Security Check',
    category: 'Code Quality',
    severity: 'LOW',
    confidence: 'HIGH',
    cwe: 'CWE-617',
    description: 'Use of assert detected. Python optimizes asserts away when run with the -O flag (python -O), disabling security checks.',
    recommendation: 'Do not use assert for application security, authorization, or input validation. Raise explicit exceptions (e.g. ValueError, PermissionError).',
    check: (line) => /^\s*assert\s+.*(?:auth|role|is_admin|permission|token|user)/i.test(line)
  },
  {
    id: 'B102-exec_used',
    name: 'Dynamic Code Execution via exec()',
    category: 'Injection',
    severity: 'CRITICAL',
    confidence: 'HIGH',
    cwe: 'CWE-95',
    description: 'Use of exec() detected. Executing arbitrary strings as Python code allows remote code execution (RCE) if user input reaches the parameter.',
    recommendation: 'Avoid dynamic code execution with exec(). Refactor logic to use standard functions, data dispatch tables, or strict parsing.',
    check: (line) => /\bexec\s*\(/i.test(line)
  },
  {
    id: 'B307-eval_used',
    name: 'Dynamic Expression Evaluation via eval()',
    category: 'Injection',
    severity: 'CRITICAL',
    confidence: 'HIGH',
    cwe: 'CWE-95',
    description: 'Use of eval() detected. Evaluating untrusted expressions can allow remote attackers to execute arbitrary system commands.',
    recommendation: 'Replace eval() with safe alternatives like ast.literal_eval() for data literals or json.loads() for JSON.',
    check: (line) => /\beval\s*\(/i.test(line) && !line.includes('ast.literal_eval')
  },
  {
    id: 'B602-subprocess_popen_with_shell_equals_true',
    name: 'Subprocess Execution with shell=True',
    category: 'Injection',
    severity: 'CRITICAL',
    confidence: 'HIGH',
    cwe: 'CWE-78',
    description: 'Subprocess call with shell=True detected. If untrusted input is formatted into the command string, it allows OS Command Injection.',
    recommendation: 'Set shell=False and pass arguments as a list (e.g. subprocess.run(["ls", "-l", path])) or use shlex.quote() if shell mode is mandatory.',
    check: (line) => /subprocess\.(?:Popen|call|check_call|check_output|run)\s*\(.*shell\s*=\s*True/i.test(line) ||
      (/shell\s*=\s*True/i.test(line) && /subprocess/i.test(line))
  },
  {
    id: 'B605-start_process_with_a_shell',
    name: 'Insecure OS Shell Command (os.system / os.popen)',
    category: 'Injection',
    severity: 'HIGH',
    confidence: 'HIGH',
    cwe: 'CWE-78',
    description: 'Starting a process using os.system() or os.popen() opens a subshell, exposing the host to command injection vulnerabilities.',
    recommendation: 'Migrate to subprocess.run([args], check=True) without a shell wrapper.',
    check: (line) => /\bos\.(?:system|popen|popen2|popen3|popen4)\s*\(/i.test(line)
  },
  {
    id: 'B301-pickle_insecure_deserialization',
    name: 'Insecure Deserialization via pickle / cPickle',
    category: 'Injection',
    severity: 'CRITICAL',
    confidence: 'HIGH',
    cwe: 'CWE-502',
    description: 'Unpickling untrusted data using pickle.loads() or pickle.load() can lead to arbitrary code execution through __reduce__ magic methods.',
    recommendation: 'Never unpickle untrusted data. Use safer serialization formats such as JSON, Protocol Buffers, or MsgPack with signing.',
    check: (line) => /\bpickle\.(?:loads|load)\s*\(/i.test(line) || /\b_pickle\.(?:loads|load)\s*\(/i.test(line)
  },
  {
    id: 'B506-yaml_load',
    name: 'Unsafe YAML Loading (yaml.load without Loader)',
    category: 'Injection',
    severity: 'HIGH',
    confidence: 'HIGH',
    cwe: 'CWE-20',
    description: 'Use of unsafe yaml.load() detected. By default in PyYAML, yaml.load() can instantiate arbitrary Python objects.',
    recommendation: 'Use yaml.safe_load(data) or specify Loader=yaml.SafeLoader explicitly.',
    check: (line) => /\byaml\.load\s*\([^,)]+\)/i.test(line) && !line.includes('SafeLoader')
  },
  {
    id: 'B303-md5_sha1_weak_hash',
    name: 'Weak Cryptographic Hash Function (MD5 / SHA1)',
    category: 'Cryptography',
    severity: 'MEDIUM',
    confidence: 'HIGH',
    cwe: 'CWE-327',
    description: 'Use of weak MD5 or SHA-1 hash function detected. MD5 and SHA-1 have known collision vulnerabilities and are unsuitable for cryptographic security.',
    recommendation: 'Use SHA-256 (hashlib.sha256) or SHA-3 for hashing, and Argon2 / bcrypt for password hashing.',
    check: (line) => /hashlib\.(?:md5|sha1)\s*\(/i.test(line) || /algorithms\.MD5\(\)/i.test(line) || /algorithms\.SHA1\(\)/i.test(line)
  },
  {
    id: 'B311-random_pseudo_randomness',
    name: 'Cryptographically Weak Random Number Generator',
    category: 'Cryptography',
    severity: 'LOW',
    confidence: 'MEDIUM',
    cwe: 'CWE-330',
    description: 'Standard pseudo-random generators in `random` module are not cryptographically secure and should not be used for security tokens or keys.',
    recommendation: 'Use Python secrets module (e.g. secrets.token_hex(), secrets.token_urlsafe()) for cryptographic or security purposes.',
    check: (line) => /\brandom\.(?:random|randint|choice|randrange)\s*\(/i.test(line) && /(?:token|secret|key|salt|nonce|password|session)/i.test(line)
  },
  {
    id: 'B104-hardcoded_bind_all_interfaces',
    name: 'Hardcoded Bind to All Network Interfaces (0.0.0.0)',
    category: 'Code Quality',
    severity: 'MEDIUM',
    confidence: 'HIGH',
    cwe: 'CWE-1188',
    description: 'Binding a network socket or web service to 0.0.0.0 listens on all public and private network interfaces, exposing services inadvertently.',
    recommendation: 'Bind to 127.0.0.1 for local development or make the host configurable via environment variables.',
    check: (line) => /['"]0\.0\.0\.0['"]|\.bind\(\s*\(\s*['"]0\.0\.0\.0['"]/i.test(line)
  },
  {
    id: 'B201-flask_debug_true',
    name: 'Flask / Django App Running with debug=True',
    category: 'Code Quality',
    severity: 'HIGH',
    confidence: 'HIGH',
    cwe: 'CWE-489',
    description: 'Running web framework in debug mode (debug=True) enables interactive web debuggers (like Werkzeug PIN debugger) which can lead to remote code execution.',
    recommendation: 'Set debug=False or control via DEBUG = os.getenv("DEBUG", "False").lower() == "true" for production.',
    check: (line) => /app\.run\(.*debug\s*=\s*True/i.test(line) || /DEBUG\s*=\s*True/i.test(line)
  },
  {
    id: 'B608-sql_injection_python',
    name: 'Direct SQL String Formatting (SQL Injection Risk)',
    category: 'Injection',
    severity: 'CRITICAL',
    confidence: 'HIGH',
    cwe: 'CWE-89',
    description: 'SQL query constructed via string concatenation or f-string interpolation. Untrusted user input can manipulate database query logic.',
    recommendation: 'Use parameterized queries with prepared statements (e.g. cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))) or an ORM.',
    check: (line) => /(?:execute|cursor\.execute|db\.execute)\s*\(\s*(?:f['"].*SELECT.*\{|['"].*SELECT.*%s.*['"]\s*\%|['"].*SELECT.*['"]\s*\+)/i.test(line) ||
      (/(?:SELECT|INSERT|UPDATE|DELETE)\s+.*(?:WHERE|FROM|INTO)/i.test(line) && /(?:f['"].*\{|\.format\(|\s*\+\s*[a-zA-Z_])/i.test(line))
  }
];

export function runBanditScan(files: DiscoveredFile[]): RawFinding[] {
  const findings: RawFinding[] = [];
  const pythonFiles = files.filter(f => f.language === 'Python');

  for (const file of pythonFiles) {
    const lines = file.content.split('\n');

    for (let lineIdx = 0; lineIdx < lines.length; lineIdx++) {
      const line = lines[lineIdx];
      const lineNum = lineIdx + 1;

      // Skip comment lines
      if (/^\s*#/.test(line)) continue;

      for (const rule of BANDIT_RULES) {
        if (rule.check(line, file.content, lineIdx)) {
          const start = Math.max(0, lineIdx - 1);
          const end = Math.min(lines.length - 1, lineIdx + 1);
          const snippet = lines.slice(start, end + 1).join('\n');

          findings.push({
            severity: rule.severity,
            confidence: rule.confidence,
            category: rule.category,
            title: rule.name,
            description: rule.description,
            file_path: file.relativePath,
            line_number: lineNum,
            code_snippet: snippet,
            scanner: 'Bandit',
            cwe: rule.cwe,
            recommendation: rule.recommendation
          });
        }
      }
    }
  }

  return findings;
}
