import { DiscoveredFile, RawFinding } from './types.ts';

interface SecretRule {
  id: string;
  name: string;
  category: 'Secrets';
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM';
  confidence: 'HIGH' | 'MEDIUM';
  regex: RegExp;
  cwe: string;
  description: string;
  recommendation: string;
}

const SECRET_RULES: SecretRule[] = [
  {
    id: 'gitleaks-aws-access-key',
    name: 'AWS Access Key ID Exposed',
    category: 'Secrets',
    severity: 'CRITICAL',
    confidence: 'HIGH',
    regex: /(?:A3T[A-Z0-9]|AKIA|AGPA|AIDA|AROA|AIPA|ANPA|ANVA|ASIA)[A-Z0-9]{16}/g,
    cwe: 'CWE-798',
    description: 'A hardcoded AWS Access Key ID was detected in source code. Exposed credentials can allow unauthorized access to cloud infrastructure.',
    recommendation: 'Revoke this access key immediately in AWS IAM, store credentials in environment variables or an AWS Secrets Manager, and never commit secrets to source control.'
  },
  {
    id: 'gitleaks-aws-secret-key',
    name: 'AWS Secret Access Key',
    category: 'Secrets',
    severity: 'CRITICAL',
    confidence: 'HIGH',
    regex: /(?:aws_secret_access_key|aws_secret_key|secret_key|aws_secret)[\s:=]+['"]([0-9a-zA-Z/+]{40})['"]/gi,
    cwe: 'CWE-798',
    description: 'A hardcoded AWS Secret Access Key was detected. When paired with an access key, this provides full authenticated API permissions.',
    recommendation: 'Rotate the AWS IAM secret key immediately and migrate to IAM roles (e.g. AWS IAM Instance Profile / ECS task roles) or secret managers.'
  },
  {
    id: 'gitleaks-github-pat',
    name: 'GitHub Personal Access Token',
    category: 'Secrets',
    severity: 'CRITICAL',
    confidence: 'HIGH',
    regex: /(?:ghp_[0-9a-zA-Z]{36}|gho_[0-9a-zA-Z]{36}|github_pat_[0-9a-zA-Z_]{22,255})/g,
    cwe: 'CWE-798',
    description: 'An exposed GitHub personal access token (PAT) or OAuth token was found in the repository.',
    recommendation: 'Revoke the compromised token in GitHub settings and load authentication tokens via CI/CD secrets or environment variables.'
  },
  {
    id: 'gitleaks-stripe-key',
    name: 'Stripe Secret API Key',
    category: 'Secrets',
    severity: 'CRITICAL',
    confidence: 'HIGH',
    regex: /(?:sk_live_[0-9a-zA-Z]{24,34}|rk_live_[0-9a-zA-Z]{24,34})/g,
    cwe: 'CWE-798',
    description: 'A live Stripe Secret or Restricted API key was detected. Exposed payment keys can lead to financial fraud, customer data exposure, and unauthorized charges.',
    recommendation: 'Roll this Stripe API key in the Stripe Dashboard immediately and restrict key permissions.'
  },
  {
    id: 'gitleaks-slack-token',
    name: 'Slack API Token / Webhook',
    category: 'Secrets',
    severity: 'HIGH',
    confidence: 'HIGH',
    regex: /(?:xox[baprs]-[0-9]{10,13}-[0-9]{10,13}-[a-zA-Z0-9]{24,32}|https:\/\/hooks\.slack\.com\/services\/T[0-9A-Z]{8}\/B[0-9A-Z]{8}\/[0-9a-zA-Z]{24})/g,
    cwe: 'CWE-798',
    description: 'A Slack API token or incoming webhook URL was detected.',
    recommendation: 'Invalidate this Slack token/webhook in the Slack App Management console.'
  },
  {
    id: 'gitleaks-rsa-private-key',
    name: 'Unencrypted Private Cryptographic Key',
    category: 'Secrets',
    severity: 'CRITICAL',
    confidence: 'HIGH',
    regex: /-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----/g,
    cwe: 'CWE-312',
    description: 'A private cryptographic key is committed in plaintext within the source code.',
    recommendation: 'Never commit private keys. Generate new key pairs, revoke the existing key, and use SSH agents, HashiCorp Vault, or KMS.'
  },
  {
    id: 'gitleaks-jwt-secret',
    name: 'Hardcoded JWT Secret',
    category: 'Secrets',
    severity: 'HIGH',
    confidence: 'MEDIUM',
    regex: /(?:jwt_secret|jwtSecret|JWT_SECRET|secretKey|secret_token)[\s:=]+['"]([a-zA-Z0-9!@#$%^&*()_+=-]{8,64})['"]/g,
    cwe: 'CWE-798',
    description: 'A static hardcoded secret string is used for signing JSON Web Tokens (JWT). Attackers who inspect the repository can forge arbitrary authentication tokens.',
    recommendation: 'Store JWT secrets securely in environment variables and rotate keys periodically using asymmetric RSA/ECDSA keys.'
  },
  {
    id: 'gitleaks-database-url-password',
    name: 'Hardcoded Database Credentials in URI',
    category: 'Secrets',
    severity: 'HIGH',
    confidence: 'HIGH',
    regex: /(?:postgres|postgresql|mysql|mongodb|redis|mssql):\/\/[a-zA-Z0-9_-]+:([^@\s'"]+)@[a-zA-Z0-9.-]+:[0-9]+/gi,
    cwe: 'CWE-798',
    description: 'A database connection string containing embedded plaintext username and password was found.',
    recommendation: 'Extract database connection strings to environment variables and use managed identity or secret management.'
  },
  {
    id: 'gitleaks-generic-api-key',
    name: 'Generic API Key / Auth Token Assigned',
    category: 'Secrets',
    severity: 'MEDIUM',
    confidence: 'MEDIUM',
    regex: /(?:api_key|apiKey|auth_token|authToken|access_token)[\s:=]+['"]([a-zA-Z0-9_\-]{20,64})['"]/gi,
    cwe: 'CWE-798',
    description: 'Potential secret or API key assignment found hardcoded in source file.',
    recommendation: 'Move all API credentials to environment configuration files (.env) that are excluded via .gitignore.'
  }
];

export function runGitleaksScan(files: DiscoveredFile[]): RawFinding[] {
  const findings: RawFinding[] = [];

  for (const file of files) {
    const lines = file.content.split('\n');

    for (let lineIdx = 0; lineIdx < lines.length; lineIdx++) {
      const line = lines[lineIdx];
      const lineNum = lineIdx + 1;

      // Skip obvious comments / test placeholders if explicitly marked as mock or test example
      if (line.includes('EXAMPLE_KEY') || line.includes('YOUR_KEY_HERE') || line.includes('PLACEHOLDER')) {
        continue;
      }

      for (const rule of SECRET_RULES) {
        // Reset regex state
        rule.regex.lastIndex = 0;
        const match = rule.regex.exec(line);

        if (match) {
          // Extract snippet with 1 line context before and after
          const start = Math.max(0, lineIdx - 1);
          const end = Math.min(lines.length - 1, lineIdx + 1);
          const snippet = lines.slice(start, end + 1).join('\n');

          findings.push({
            severity: rule.severity,
            confidence: rule.confidence,
            category: 'Secrets',
            title: rule.name,
            description: rule.description,
            file_path: file.relativePath,
            line_number: lineNum,
            code_snippet: snippet,
            scanner: 'Gitleaks',
            cwe: rule.cwe,
            recommendation: rule.recommendation
          });
        }
      }
    }
  }

  return findings;
}
