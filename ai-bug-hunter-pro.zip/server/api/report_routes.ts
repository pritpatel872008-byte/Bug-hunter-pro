import { Router, Response } from 'express';
import { authMiddleware, AuthRequest } from '../auth/auth.ts';
import { ReportService } from '../services/report_service.ts';

export const reportRouter = Router();

// Enforce authentication on report downloads & views
reportRouter.use(authMiddleware);

// GET /api/reports/:scanId - strictly verifies scan belongs to user
reportRouter.get('/:scanId', (req: AuthRequest, res: Response) => {
  try {
    const { scanId } = req.params;
    const userId = req.user!.id;
    const format = (req.query.format as string) || 'json';

    if (format === 'markdown' || format === 'md') {
      const markdown = ReportService.generateMarkdownReport(scanId, userId);
      res.setHeader('Content-Type', 'text/markdown; charset=utf-8');
      if (req.query.download === 'true') {
        res.setHeader('Content-Disposition', `attachment; filename="audit-report-${scanId.slice(0, 8)}.md"`);
      }
      return res.send(markdown);
    }

    const report = ReportService.generateJsonReport(scanId, userId);
    if (req.query.download === 'true') {
      res.setHeader('Content-Disposition', `attachment; filename="audit-report-${scanId.slice(0, 8)}.json"`);
    }
    return res.json(report);
  } catch (err: any) {
    if (err.message === 'Scan not found') {
      return res.status(404).json({ error: 'Scan report not found' });
    }
    return res.status(500).json({ error: err.message });
  }
});

