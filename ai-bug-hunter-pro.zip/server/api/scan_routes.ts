import { Router, Response } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { getDb } from '../db/database.ts';
import { authMiddleware, AuthRequest } from '../auth/auth.ts';
import { ScanService } from '../services/scan_service.ts';
import { discoverFiles } from '../scanners/file_extractor.ts';

export const scanRouter = Router();

// Enforce authentication on all scan endpoints
scanRouter.use(authMiddleware);

// GET /api/scans - returns only scans belonging to the authenticated user's repositories
scanRouter.get('/', (req: AuthRequest, res: Response) => {
  try {
    const db = getDb();
    const userId = req.user!.id;
    const repoId = req.query.repository_id as string | undefined;

    let query = `
      SELECT s.*, r.name as repo_name, r.source as repo_source, r.branch as repo_branch,
        (SELECT COUNT(*) FROM issues i WHERE i.scan_id = s.id) as issues_count,
        (SELECT COUNT(*) FROM issues i WHERE i.scan_id = s.id AND i.severity = 'CRITICAL') as critical_count,
        (SELECT COUNT(*) FROM issues i WHERE i.scan_id = s.id AND i.severity = 'HIGH') as high_count,
        (SELECT COUNT(*) FROM issues i WHERE i.scan_id = s.id AND i.severity = 'MEDIUM') as medium_count,
        (SELECT COUNT(*) FROM issues i WHERE i.scan_id = s.id AND i.severity = 'LOW') as low_count
      FROM scans s
      JOIN repositories r ON s.repository_id = r.id
      WHERE r.user_id = ?
    `;

    const params: any[] = [userId];
    if (repoId) {
      query += ' AND s.repository_id = ?';
      params.push(repoId);
    }
    query += ' ORDER BY s.started_at DESC';

    const scans: any[] = db.prepare(query).all(...params);

    return res.json({
      scans: scans.map(s => ({
        ...s,
        scanners_executed: JSON.parse(s.scanners_executed || '[]')
      }))
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// POST /api/scans (Start static analysis scan for an owned repository)
scanRouter.post('/', async (req: AuthRequest, res: Response) => {
  try {
    const repositoryId = req.body.repository_id || req.body.repositoryId;
    if (!repositoryId) {
      return res.status(400).json({ error: 'Missing required field: repository_id' });
    }

    const db = getDb();
    const userId = req.user!.id;

    // Strict ownership verification: cannot trigger scans for repos of another user
    const repo: any = db.prepare('SELECT * FROM repositories WHERE id = ? AND user_id = ?').get(repositoryId, userId);
    if (!repo) {
      return res.status(404).json({ error: 'Repository not found' });
    }

    // Look for stored files in data/repositories/{userId}/{repoId} or test-project
    const repoDir = path.resolve(process.cwd(), 'data', 'repositories', userId, repo.id);
    let files: any[] = [];

    if (fs.existsSync(repoDir)) {
      files = discoverFiles(repoDir);
    } else if (repo.source === 'test-project') {
      const testProjDir = path.resolve(process.cwd(), 'test-project');
      if (fs.existsSync(testProjDir)) {
        files = discoverFiles(testProjDir);
      }
    }

    if (files.length === 0) {
      const testProjDir = path.resolve(process.cwd(), 'test-project');
      if (fs.existsSync(testProjDir)) {
        files = discoverFiles(testProjDir);
      } else {
        return res.status(400).json({
          error: 'No cached source files found for this repository. Please re-upload or select a valid project.'
        });
      }
    }

    const commitHash = req.body.commitHash || `${repo.branch || 'main'}@${Date.now().toString(36)}`;
    const scanResult = await ScanService.executeScan({
      repositoryId: repo.id,
      userId,
      commitHash,
      files
    });

    return res.status(201).json({
      scanId: scanResult.scanId,
      repositoryId: repo.id,
      score: scanResult.score,
      issuesCount: scanResult.issuesCount,
      status: 'COMPLETED',
      message: 'Static analysis scan completed successfully.'
    });
  } catch (err: any) {
    console.error('[SCAN ERROR]', err);
    return res.status(500).json({ error: err.message || 'Scan execution failed' });
  }
});

// GET /api/scans/:id - strictly returns scan details only if owned by user
scanRouter.get('/:id', (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const details = ScanService.getScanDetails(req.params.id, userId);
    if (!details) {
      return res.status(404).json({ error: 'Scan not found' });
    }
    return res.json({ scan: details });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// POST /api/scans/:id/cancel - strictly cancels scan only if owned by user
scanRouter.post('/:id/cancel', (req: AuthRequest, res: Response) => {
  try {
    const db = getDb();
    const userId = req.user!.id;

    const scan: any = db.prepare(`
      SELECT s.id, s.status FROM scans s
      JOIN repositories r ON s.repository_id = r.id
      WHERE s.id = ? AND r.user_id = ?
    `).get(req.params.id, userId);

    if (!scan) return res.status(404).json({ error: 'Scan not found' });

    if (scan.status === 'RUNNING' || scan.status === 'QUEUED') {
      db.prepare(`
        UPDATE scans
        SET status = 'CANCELLED', completed_at = ?
        WHERE id = ?
      `).run(new Date().toISOString(), req.params.id);

      db.prepare('INSERT INTO scan_logs (id, scan_id, message, level, timestamp) VALUES (?, ?, ?, ?, ?)').run(
        crypto.randomUUID(),
        req.params.id,
        'Scan was cancelled by user.',
        'WARN',
        new Date().toISOString()
      );
    }

    return res.json({ message: 'Scan cancelled successfully.' });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

