import { Router, Response } from 'express';
import { randomUUID } from 'node:crypto';
import { getDb } from '../db/database.ts';
import { authMiddleware, AuthRequest } from '../auth/auth.ts';
import { getAIProvider, setAIProvider, OllamaProvider } from '../ai/index.ts';

export const aiRouter = Router();

function getUnavailableMessage(provider: any): string {
  if (provider instanceof OllamaProvider) {
    return 'Local Ollama AI is unavailable.';
  }
  return 'Gemini AI is not configured. Static analysis is still available.';
}

function formatAiErrorMessage(err: any, provider: any): string {
  const isOllama = provider instanceof OllamaProvider;
  if (!isOllama) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey.trim() === '') {
      return 'Gemini AI is not configured. Static analysis is still available.';
    }
  }
  const rawMsg = err?.message || 'AI analysis failed';
  if (rawMsg.includes('Gemini AI is not configured')) {
    return rawMsg;
  }
  return rawMsg.startsWith('Gemini') ? rawMsg : `Gemini AI analysis failed: ${rawMsg}`;
}

// GET /api/ai/status
aiRouter.get('/status', async (_req, res: Response) => {
  try {
    const provider = getAIProvider();
    const available = await provider.isAvailable();
    const isOllama = provider instanceof OllamaProvider;

    return res.json({
      provider: provider.name,
      available,
      providerType: isOllama ? 'ollama' : 'gemini',
      hasGeminiKey: Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim() !== ''),
      message: available ? 'AI engine ready' : getUnavailableMessage(provider)
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Enforce authentication on all AI reasoning endpoints
aiRouter.use(authMiddleware);

// POST /api/ai/configure (Switch provider)
aiRouter.post('/configure', (req: AuthRequest, res: Response) => {
  try {
    const { provider, ollamaUrl, model } = req.body;
    if (provider !== 'gemini' && provider !== 'ollama') {
      return res.status(400).json({ error: 'Provider must be "gemini" or "ollama"' });
    }
    const updated = setAIProvider(provider, { ollamaUrl, model });
    return res.json({
      message: `AI provider switched to ${updated.name}`,
      provider: updated.name
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// POST /api/issues/:id/explain - strictly verifies issue belongs to user
aiRouter.post('/issues/:id/explain', async (req: AuthRequest, res: Response) => {
  const provider = getAIProvider();
  try {
    const db = getDb();
    const userId = req.user!.id;

    // Strict ownership verification
    const issue: any = db.prepare(`
      SELECT i.* FROM issues i
      JOIN scans s ON i.scan_id = s.id
      JOIN repositories r ON s.repository_id = r.id
      WHERE i.id = ? AND r.user_id = ?
    `).get(req.params.id, userId);

    if (!issue) {
      return res.status(404).json({ error: 'Issue finding not found' });
    }

    const isAvailable = await provider.isAvailable();
    if (!isAvailable) {
      return res.status(503).json({
        error: getUnavailableMessage(provider),
        fallbackFinding: issue
      });
    }

    const analysis = await provider.explainIssue({
      title: issue.title,
      description: issue.description,
      category: issue.category,
      severity: issue.severity,
      filePath: issue.file_path,
      lineNumber: issue.line_number,
      codeSnippet: issue.code_snippet,
      scanner: issue.scanner,
      cwe: issue.cwe
    });

    const fixCode = analysis.suggested_fix || analysis.saferCode || '// Parameterized query or safe API';
    const explanation = analysis.explanation;
    const impact = analysis.impact;

    // Check if AI analysis already exists, update or insert
    const existing: any = db.prepare('SELECT id FROM ai_analysis WHERE issue_id = ?').get(issue.id);
    if (existing) {
      db.prepare(`
        UPDATE ai_analysis
        SET explanation = ?, impact = ?, suggested_fix = ?
        WHERE issue_id = ?
      `).run(explanation, impact, fixCode, issue.id);
    } else {
      db.prepare(`
        INSERT INTO ai_analysis (id, issue_id, explanation, impact, suggested_fix, generated_tests, created_at)
        VALUES (?, ?, ?, ?, ?, NULL, ?)
      `).run(randomUUID(), issue.id, explanation, impact, fixCode, new Date().toISOString());
    }

    return res.json({ analysis });
  } catch (err: any) {
    const msg = formatAiErrorMessage(err, provider);
    return res.status(500).json({
      error: msg
    });
  }
});

// POST /api/issues/:id/fix - strictly verifies issue belongs to user
aiRouter.post('/issues/:id/fix', async (req: AuthRequest, res: Response) => {
  const provider = getAIProvider();
  try {
    const db = getDb();
    const userId = req.user!.id;

    // Strict ownership verification
    const issue: any = db.prepare(`
      SELECT i.* FROM issues i
      JOIN scans s ON i.scan_id = s.id
      JOIN repositories r ON s.repository_id = r.id
      WHERE i.id = ? AND r.user_id = ?
    `).get(req.params.id, userId);

    if (!issue) {
      return res.status(404).json({ error: 'Issue finding not found' });
    }

    const isAvailable = await provider.isAvailable();
    if (!isAvailable) {
      return res.status(503).json({
        error: getUnavailableMessage(provider)
      });
    }

    const fixResult = await provider.generateFix({
      title: issue.title,
      description: issue.description,
      filePath: issue.file_path,
      lineNumber: issue.line_number,
      codeSnippet: issue.code_snippet,
      cwe: issue.cwe
    });

    // Update suggested fix in database
    const existing: any = db.prepare('SELECT id FROM ai_analysis WHERE issue_id = ?').get(issue.id);
    if (existing) {
      db.prepare('UPDATE ai_analysis SET suggested_fix = ? WHERE issue_id = ?').run(fixResult.suggestedCode, issue.id);
    } else {
      db.prepare(`
        INSERT INTO ai_analysis (id, issue_id, explanation, impact, suggested_fix, generated_tests, created_at)
        VALUES (?, ?, ?, ?, ?, NULL, ?)
      `).run(randomUUID(), issue.id, fixResult.explanation, 'Security vulnerability remediation', fixResult.suggestedCode, new Date().toISOString());
    }

    return res.json({ fix: fixResult });
  } catch (err: any) {
    const msg = formatAiErrorMessage(err, provider);
    return res.status(500).json({ error: msg });
  }
});

// POST /api/issues/:id/tests - strictly verifies issue belongs to user
aiRouter.post('/issues/:id/tests', async (req: AuthRequest, res: Response) => {
  const provider = getAIProvider();
  try {
    const { framework } = req.body;
    const db = getDb();
    const userId = req.user!.id;

    // Strict ownership verification
    const issue: any = db.prepare(`
      SELECT i.* FROM issues i
      JOIN scans s ON i.scan_id = s.id
      JOIN repositories r ON s.repository_id = r.id
      WHERE i.id = ? AND r.user_id = ?
    `).get(req.params.id, userId);

    if (!issue) {
      return res.status(404).json({ error: 'Issue finding not found' });
    }

    const isAvailable = await provider.isAvailable();
    if (!isAvailable) {
      return res.status(503).json({
        error: getUnavailableMessage(provider)
      });
    }

    const testResult = await provider.generateTests({
      title: issue.title,
      category: issue.category,
      filePath: issue.file_path,
      codeSnippet: issue.code_snippet,
      framework
    });

    // Update database
    const existing: any = db.prepare('SELECT id FROM ai_analysis WHERE issue_id = ?').get(issue.id);
    if (existing) {
      db.prepare(`
        UPDATE ai_analysis
        SET generated_tests = ?
        WHERE issue_id = ?
      `).run(testResult.testCode, issue.id);
    } else {
      db.prepare(`
        INSERT INTO ai_analysis (id, issue_id, explanation, impact, suggested_fix, generated_tests, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `).run(randomUUID(), issue.id, 'Automated defensive test suite', 'Security test verification', '// See generated tests', testResult.testCode, new Date().toISOString());
    }

    return res.json({ tests: testResult });
  } catch (err: any) {
    const msg = formatAiErrorMessage(err, provider);
    return res.status(500).json({ error: msg });
  }
});

// POST /api/code-review
aiRouter.post('/code-review', async (req: AuthRequest, res: Response) => {
  const provider = getAIProvider();
  try {
    const { filePath = 'snippet.ts', language = 'TypeScript', codeContent } = req.body;
    if (!codeContent || codeContent.trim() === '') {
      return res.status(400).json({ error: 'Code content is required for review.' });
    }

    const isAvailable = await provider.isAvailable();
    if (!isAvailable) {
      return res.status(503).json({
        error: getUnavailableMessage(provider)
      });
    }

    const review = await provider.reviewCode({
      filePath,
      language,
      codeContent
    });

    return res.json({ review });
  } catch (err: any) {
    const msg = formatAiErrorMessage(err, provider);
    return res.status(500).json({ error: msg });
  }
});
