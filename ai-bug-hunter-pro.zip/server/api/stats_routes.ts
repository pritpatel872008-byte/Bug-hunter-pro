import { Router, Response } from 'express';
import { getDb } from '../db/database.ts';
import { authMiddleware, AuthRequest } from '../auth/auth.ts';

export const statsRouter = Router();

// Enforce authentication on dashboard statistics
statsRouter.use(authMiddleware);

// GET /api/stats (REAL Database Aggregations Scoped Strictly to Authenticated User)
statsRouter.get('/', (req: AuthRequest, res: Response) => {
  try {
    const db = getDb();
    const userId = req.user!.id;

    // 1. Repositories count for user
    const totalReposRow: any = db.prepare('SELECT COUNT(*) as count FROM repositories WHERE user_id = ?').get(userId);
    const totalRepos = totalReposRow?.count || 0;

    // 2. Scans count for user
    const totalScansRow: any = db.prepare(`
      SELECT COUNT(*) as count FROM scans s
      JOIN repositories r ON s.repository_id = r.id
      WHERE r.user_id = ?
    `).get(userId);
    const totalScans = totalScansRow?.count || 0;

    // 3. Completed Scans count for user
    const completedScansRow: any = db.prepare(`
      SELECT COUNT(*) as count FROM scans s
      JOIN repositories r ON s.repository_id = r.id
      WHERE r.user_id = ? AND s.status = 'COMPLETED'
    `).get(userId);
    const completedScans = completedScansRow?.count || 0;

    // 4. Vulnerability breakdown across all open issues in user's scans
    const severityCounts: any = db.prepare(`
      SELECT
        COUNT(*) as total_issues,
        SUM(CASE WHEN i.severity = 'CRITICAL' THEN 1 ELSE 0 END) as critical,
        SUM(CASE WHEN i.severity = 'HIGH' THEN 1 ELSE 0 END) as high,
        SUM(CASE WHEN i.severity = 'MEDIUM' THEN 1 ELSE 0 END) as medium,
        SUM(CASE WHEN i.severity = 'LOW' THEN 1 ELSE 0 END) as low,
        SUM(CASE WHEN i.severity = 'INFO' THEN 1 ELSE 0 END) as info,
        SUM(CASE WHEN i.category = 'Secrets' THEN 1 ELSE 0 END) as secrets
      FROM issues i
      JOIN scans s ON i.scan_id = s.id
      JOIN repositories r ON s.repository_id = r.id
      WHERE r.user_id = ? AND i.status != 'FALSE_POSITIVE'
    `).get(userId);

    // 5. Average security score of latest completed scans for user
    const avgScoreRow: any = db.prepare(`
      SELECT AVG(security_score) as avg_score
      FROM (
        SELECT s.security_score FROM scans s
        JOIN repositories r ON s.repository_id = r.id
        WHERE r.user_id = ? AND s.status = 'COMPLETED'
        ORDER BY s.started_at DESC
        LIMIT 10
      )
    `).get(userId);
    const avgScore = avgScoreRow?.avg_score != null ? Math.round(avgScoreRow.avg_score) : null;

    // 6. Recent scans for user with real metadata
    const recentScans: any[] = db.prepare(`
      SELECT s.*, r.name as repo_name, r.source as repo_source,
        (SELECT COUNT(*) FROM issues i WHERE i.scan_id = s.id) as issues_count,
        (SELECT COUNT(*) FROM issues i WHERE i.scan_id = s.id AND i.severity = 'CRITICAL') as critical_count,
        (SELECT COUNT(*) FROM issues i WHERE i.scan_id = s.id AND i.severity = 'HIGH') as high_count
      FROM scans s
      JOIN repositories r ON s.repository_id = r.id
      WHERE r.user_id = ?
      ORDER BY s.started_at DESC
      LIMIT 6
    `).all(userId);

    // 7. Active scanner availability status
    const scannerStatuses = [
      { name: 'Semgrep SAST', status: 'Active', description: 'Semantic code analysis & injection detector' },
      { name: 'Gitleaks Secrets', status: 'Active', description: 'API keys, credentials, and token scanner' },
      { name: 'Bandit Security', status: 'Active', description: 'Python AST security vulnerability analyzer' },
      { name: 'ESLint Security', status: 'Active', description: 'JavaScript/TypeScript SAST rule engine' },
      { name: 'DependencyCheck', status: 'Active', description: 'Package manifest CVE vulnerability checker' },
      {
        name: 'Gemini AI Reasoner',
        status: process.env.GEMINI_API_KEY ? 'Active' : 'Unconfigured',
        description: 'Deep technical explanation & automated fix engine'
      }
    ];

    return res.json({
      hasData: totalScans > 0,
      totalRepositories: totalRepos,
      totalScans,
      completedScans,
      securityScore: avgScore,
      findings: {
        total: severityCounts?.total_issues || 0,
        critical: severityCounts?.critical || 0,
        high: severityCounts?.high || 0,
        medium: severityCounts?.medium || 0,
        low: severityCounts?.low || 0,
        info: severityCounts?.info || 0,
        secrets: severityCounts?.secrets || 0
      },
      recentScans: recentScans.map(s => ({
        ...s,
        scanners_executed: JSON.parse(s.scanners_executed || '[]')
      })),
      scannerStatuses
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

