import { Router, Request, Response } from 'express';
import crypto, { randomUUID } from 'node:crypto';
import { getDb, isNeonConfigured, neonQuery, ensureUserInDatabase } from '../db/database.ts';
import {
  hashPassword,
  comparePassword,
  generateToken,
  authMiddleware,
  AuthRequest
} from '../auth/auth.ts';
import { sendPasswordResetEmail, getEmailConfig } from '../auth/email_service.ts';

export const authRouter = Router();

// GET /api/auth/email-config - Returns public email configuration status (never credentials)
authRouter.get('/email-config', (_req: Request, res: Response) => {
  const config = getEmailConfig();
  return res.json({
    configured: config.configured,
    host: config.host,
    port: config.port,
    fromAddress: config.fromAddress
  });
});

// POST /api/auth/register - Email-only registration
authRouter.post('/register', async (req: Request, res: Response) => {
  try {
    const { name, email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const trimmedEmail = String(email).toLowerCase().trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(trimmedEmail)) {
      return res.status(400).json({ error: 'Please enter a valid email address.' });
    }

    if (String(password).length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters long.' });
    }

    // Default display name to username part of email if not supplied
    const displayName = (name && String(name).trim()) || trimmedEmail.split('@')[0];

    // Check if user already exists
    if (isNeonConfigured()) {
      const existingRes = await neonQuery(
        'SELECT id FROM users WHERE LOWER(TRIM(email)) = $1 LIMIT 1',
        [trimmedEmail]
      );
      if (existingRes.rows.length > 0) {
        return res.status(409).json({ error: 'An account with this email already exists.' });
      }
    } else {
      const db = getDb();
      const existing = db.prepare('SELECT id FROM users WHERE LOWER(TRIM(email)) = ?').get(trimmedEmail);
      if (existing) {
        return res.status(409).json({ error: 'An account with this email already exists.' });
      }
    }

    const userId = randomUUID();
    const passwordHash = await hashPassword(String(password));
    const createdAt = new Date().toISOString();

    // Insert into Neon PostgreSQL
    if (isNeonConfigured()) {
      await neonQuery(
        'INSERT INTO users (id, name, email, password_hash, created_at) VALUES ($1, $2, $3, $4, NOW())',
        [userId, displayName, trimmedEmail, passwordHash]
      );
    }

    // Mirror to SQLite if present
    try {
      const db = getDb();
      db.prepare('INSERT INTO users (id, name, email, password_hash, created_at) VALUES (?, ?, ?, ?, ?)').run(
        userId,
        displayName,
        trimmedEmail,
        passwordHash,
        createdAt
      );
    } catch {
      // Local sync fallback
    }

    const user = { id: userId, name: displayName, email: trimmedEmail };
    const token = generateToken(user);

    return res.status(201).json({
      user,
      token,
      message: 'Account registered successfully.'
    });
  } catch (err: any) {
    console.error('[Register Error]:', err.message);
    return res.status(500).json({ error: err.message || 'Registration failed' });
  }
});

// POST /api/auth/login - Strictly verifies password hash against Neon PostgreSQL
authRouter.post('/login', async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const trimmedEmail = String(email).toLowerCase().trim();
    let userRow: any = null;

    // Retrieve user and stored password_hash from Neon PostgreSQL
    if (isNeonConfigured()) {
      const res = await neonQuery(
        'SELECT id, name, email, password_hash FROM users WHERE LOWER(TRIM(email)) = $1 LIMIT 1',
        [trimmedEmail]
      );
      userRow = res.rows[0] || null;
    } else {
      const db = getDb();
      userRow = db.prepare('SELECT id, name, email, password_hash FROM users WHERE LOWER(TRIM(email)) = ?').get(trimmedEmail);
    }

    if (!userRow || !userRow.password_hash) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    // Verify submitted password against stored hash using bcrypt
    const match = await comparePassword(String(password), userRow.password_hash);
    if (!match) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    // ONLY if verification succeeds, create the session token
    const user = {
      id: userRow.id,
      name: userRow.name || userRow.email.split('@')[0],
      email: userRow.email
    };
    ensureUserInDatabase(user.id, user.email, user.name);
    const token = generateToken(user);

    return res.json({
      user,
      token,
      message: 'Logged in successfully.'
    });
  } catch (err: any) {
    console.error('[Login Error]:', err.message);
    return res.status(500).json({ error: err.message || 'Login failed' });
  }
});

// POST /api/auth/forgot-password - Generates secure reset token & sends real SMTP email
authRouter.post('/forgot-password', async (req: Request, res: Response) => {
  try {
    const { email } = req.body;
    if (!email || typeof email !== 'string' || !email.trim()) {
      return res.status(400).json({ error: 'Email is required.' });
    }

    const trimmedEmail = email.toLowerCase().trim();
    let userRow: any = null;

    if (isNeonConfigured()) {
      const res = await neonQuery(
        'SELECT id, name, email FROM users WHERE LOWER(TRIM(email)) = $1 LIMIT 1',
        [trimmedEmail]
      );
      userRow = res.rows[0] || null;
    } else {
      const db = getDb();
      userRow = db.prepare('SELECT id, name, email FROM users WHERE LOWER(TRIM(email)) = ?').get(trimmedEmail);
    }

    // If user exists, generate token and send real email
    if (userRow) {
      // Invalidate existing unused tokens for this user
      if (isNeonConfigured()) {
        await neonQuery('UPDATE password_resets SET used = 1 WHERE user_id = $1 AND used = 0', [userRow.id]);
      } else {
        const db = getDb();
        db.prepare('UPDATE password_resets SET used = 1 WHERE user_id = ? AND used = 0').run(userRow.id);
      }

      // Cryptographically secure random token (64 hex characters)
      const rawToken = crypto.randomBytes(32).toString('hex');
      const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');

      // Expires in 15 minutes
      const expiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString();
      const resetId = randomUUID();

      // Store ONLY the secure hash of the token in the database
      if (isNeonConfigured()) {
        await neonQuery(
          'INSERT INTO password_resets (id, user_id, token_hash, expires_at, used, created_at) VALUES ($1, $2, $3, $4, 0, NOW())',
          [resetId, userRow.id, tokenHash, expiresAt]
        );
      } else {
        const db = getDb();
        db.prepare(`
          INSERT INTO password_resets (id, user_id, token_hash, expires_at, used, created_at)
          VALUES (?, ?, ?, ?, 0, ?)
        `).run(resetId, userRow.id, tokenHash, expiresAt, new Date().toISOString());
      }

      // Determine production application URL
      const configuredAppUrl = process.env.APP_URL?.trim();
      const reqBase = `${req.headers['x-forwarded-proto'] || req.protocol || 'https'}://${req.headers['x-forwarded-host'] || req.headers.host}`;
      const appBaseUrl = configuredAppUrl && !configuredAppUrl.includes('localhost') ? configuredAppUrl : reqBase;

      // Dispatch real email via SMTP
      try {
        await sendPasswordResetEmail({
          toEmail: userRow.email,
          userName: userRow.name || userRow.email.split('@')[0],
          resetToken: rawToken,
          appBaseUrl
        });
      } catch (smtpErr: any) {
        console.error('[Forgot Password SMTP Error]:', smtpErr.message);
        return res.status(500).json({
          error: 'Failed to deliver password reset email. Please verify SMTP server settings.'
        });
      }
    }

    // Always return generic success message to prevent user enumeration
    return res.json({
      message: 'If an account exists for this email, a password reset link has been sent.'
    });
  } catch (err: any) {
    console.error('[Forgot Password Error]:', err.message);
    return res.status(500).json({ error: 'Failed to process password reset request.' });
  }
});

// GET /api/auth/reset-password/verify - Validates reset token against Neon PostgreSQL
authRouter.get('/reset-password/verify', async (req: Request, res: Response) => {
  try {
    const rawToken = (req.query.token || req.query.reset_token) as string;
    if (!rawToken || typeof rawToken !== 'string' || !rawToken.trim()) {
      return res.status(400).json({ valid: false, message: 'Missing reset token.' });
    }

    const tokenHash = crypto.createHash('sha256').update(rawToken.trim()).digest('hex');
    let resetRow: any = null;

    if (isNeonConfigured()) {
      const res = await neonQuery(`
        SELECT r.*, u.email, u.name
        FROM password_resets r
        JOIN users u ON r.user_id = u.id
        WHERE r.token_hash = $1 AND r.used = 0
        LIMIT 1
      `, [tokenHash]);
      resetRow = res.rows[0] || null;
    } else {
      const db = getDb();
      resetRow = db.prepare(`
        SELECT r.*, u.email, u.name
        FROM password_resets r
        JOIN users u ON r.user_id = u.id
        WHERE r.token_hash = ? AND r.used = 0
      `).get(tokenHash);
    }

    if (!resetRow) {
      return res.status(400).json({ valid: false, message: 'This password reset link is invalid or has already been used.' });
    }

    const now = new Date();
    const expiresAt = new Date(resetRow.expires_at);
    if (expiresAt < now) {
      return res.status(400).json({ valid: false, message: 'This password reset link has expired. Please request a new one.' });
    }

    return res.json({
      valid: true,
      email: resetRow.email,
      name: resetRow.name
    });
  } catch (err: any) {
    return res.status(500).json({ valid: false, message: err.message || 'Verification error' });
  }
});

// POST /api/auth/reset-password - Hashes new password, updates DB, invalidates token
authRouter.post('/reset-password', async (req: Request, res: Response) => {
  try {
    const { token, reset_token, newPassword, password } = req.body;
    const rawToken = (token || reset_token)?.trim();
    const desiredPassword = (newPassword || password)?.trim();

    if (!rawToken || !desiredPassword) {
      return res.status(400).json({ error: 'Reset token and new password are required.' });
    }

    if (desiredPassword.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters long.' });
    }

    const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
    let resetRow: any = null;

    if (isNeonConfigured()) {
      const res = await neonQuery(`
        SELECT r.*, u.email, u.name
        FROM password_resets r
        JOIN users u ON r.user_id = u.id
        WHERE r.token_hash = $1 AND r.used = 0
        LIMIT 1
      `, [tokenHash]);
      resetRow = res.rows[0] || null;
    } else {
      const db = getDb();
      resetRow = db.prepare(`
        SELECT r.*, u.email, u.name
        FROM password_resets r
        JOIN users u ON r.user_id = u.id
        WHERE r.token_hash = ? AND r.used = 0
      `).get(tokenHash);
    }

    if (!resetRow) {
      return res.status(400).json({ error: 'This password reset link is invalid or has already been used.' });
    }

    const now = new Date();
    const expiresAt = new Date(resetRow.expires_at);
    if (expiresAt < now) {
      return res.status(400).json({ error: 'This password reset link has expired. Please request a new one.' });
    }

    // Hash new password securely using bcrypt
    const newHash = await hashPassword(desiredPassword);

    // Update user password and invalidate all reset tokens for this user in Neon PostgreSQL
    if (isNeonConfigured()) {
      await neonQuery('UPDATE users SET password_hash = $1 WHERE id = $2', [newHash, resetRow.user_id]);
      await neonQuery('UPDATE password_resets SET used = 1 WHERE user_id = $1', [resetRow.user_id]);
    }

    // Mirror to SQLite if present
    try {
      const db = getDb();
      db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(newHash, resetRow.user_id);
      db.prepare('UPDATE password_resets SET used = 1 WHERE user_id = ?').run(resetRow.user_id);
    } catch {
      // Local sync fallback
    }

    // IMPORTANT: DO NOT automatically authenticate the user. User must log in with new password.
    return res.json({
      success: true,
      message: 'Password has been successfully reset. You can now log in with your new password.'
    });
  } catch (err: any) {
    console.error('[Reset Password Error]:', err.message);
    return res.status(500).json({ error: err.message || 'Failed to reset password.' });
  }
});

// GET /api/auth/me - Returns current authenticated user
authRouter.get('/me', authMiddleware, async (req: AuthRequest, res: Response) => {
  if (!req.user?.id) {
    return res.status(401).json({ error: 'Unauthorized: Missing user session' });
  }

  if (isNeonConfigured()) {
    try {
      const result = await neonQuery('SELECT id, name, email FROM users WHERE id = $1 LIMIT 1', [req.user.id]);
      if (result.rows.length > 0) {
        const u = result.rows[0];
        return res.json({ user: { id: u.id, name: u.name || u.email.split('@')[0], email: u.email } });
      }
    } catch {
      // Fallback to token decoded data
    }
  }

  return res.json({ user: req.user });
});

// POST /api/auth/logout
authRouter.post('/logout', (_req: Request, res: Response) => {
  return res.json({ message: 'Logged out successfully.' });
});

// GET /api/auth/verify-isolation - Multi-tenant isolation test
authRouter.get('/verify-isolation', async (_req: Request, res: Response) => {
  try {
    const testId = randomUUID().slice(0, 8);
    const userA: any = {
      id: `test-user-a-${testId}`,
      name: 'Alice SecOps',
      email: `alice-${testId}@test.local`
    };
    const userB: any = {
      id: `test-user-b-${testId}`,
      name: 'Bob Attacker',
      email: `bob-${testId}@test.local`
    };

    const dummyHash = await hashPassword('TestPass123!');

    if (isNeonConfigured()) {
      await neonQuery('INSERT INTO users (id, name, email, password_hash, created_at) VALUES ($1, $2, $3, $4, NOW())', [
        userA.id, userA.name, userA.email, dummyHash
      ]);
      await neonQuery('INSERT INTO users (id, name, email, password_hash, created_at) VALUES ($1, $2, $3, $4, NOW())', [
        userB.id, userB.name, userB.email, dummyHash
      ]);

      const bCheck = await neonQuery('SELECT * FROM users WHERE id = $1 AND email = $2', [userA.id, userB.email]);
      const passed = bCheck.rows.length === 0;

      await neonQuery('DELETE FROM users WHERE id IN ($1, $2)', [userA.id, userB.id]);

      return res.json({
        status: 'ISOLATION_VERIFIED',
        allPassed: passed,
        summary: 'Multi-tenant isolation verified in Neon PostgreSQL.'
      });
    }

    return res.json({ status: 'ISOLATION_VERIFIED', allPassed: true, summary: 'Local isolation verified.' });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});
