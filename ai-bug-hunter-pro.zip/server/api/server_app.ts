import express, { Express, Request, Response, NextFunction } from 'express';
import { authRouter } from './auth_routes.ts';
import { repoRouter } from './repo_routes.ts';
import { scanRouter } from './scan_routes.ts';
import { issueRouter } from './issue_routes.ts';
import { aiRouter } from './ai_routes.ts';
import { reportRouter } from './report_routes.ts';
import { statsRouter } from './stats_routes.ts';

export function createServerApp(): Express {
  const app = express();

  // Disable x-powered-by header
  app.disable('x-powered-by');

  // CORS Middleware: Allow all valid origins, headers, and methods with preflight OPTIONS handling
  app.use((req: Request, res: Response, next: NextFunction) => {
    const origin = req.headers.origin || '*';
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization, Range');
    res.setHeader('Access-Control-Expose-Headers', 'Content-Length, Content-Range');
    res.setHeader('Access-Control-Max-Age', '86400');

    if (req.method === 'OPTIONS') {
      return res.status(204).end();
    }
    next();
  });

  // Body Parsing Middleware (large limit for payload handling)
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // Basic API request logging
  app.use((req: Request, _res: Response, next: NextFunction) => {
    if (req.path.startsWith('/api')) {
      const timestamp = new Date().toISOString().split('T')[1].slice(0, 8);
      console.log(`[API ${timestamp}] ${req.method} ${req.originalUrl || req.url}`);
    }
    next();
  });

  // Health check endpoint (explicitly required: GET /api/health returning { "status": "ok" })
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({
      status: 'ok',
      service: 'AI Bug Hunter Pro SAST Engine',
      timestamp: new Date().toISOString()
    });
  });

  // API Routes
  app.use('/api/auth', authRouter);
  app.use('/api/repositories', repoRouter);
  app.use('/api/scans', scanRouter);
  app.use('/api/issues', issueRouter);
  app.use('/api/ai', aiRouter);
  app.use('/api/reports', reportRouter);
  app.use('/api/stats', statsRouter);

  // Global Code Review alias endpoint matching POST /api/code-review
  app.post('/api/code-review', (req: Request, res: Response, next: NextFunction) => {
    req.url = '/code-review';
    aiRouter(req, res, next);
  });

  // Catch-all 404 for unhandled API routes: ALWAYS return JSON, never fall through to HTML
  app.all('/api/*', (req: Request, res: Response) => {
    res.status(404).json({
      success: false,
      error: `API endpoint not found: ${req.method} ${req.originalUrl || req.url}`
    });
  });

  // Global Error Handler for API routes: ALWAYS return JSON
  app.use((err: any, req: Request, res: Response, _next: NextFunction) => {
    console.error(`[SERVER ERROR] ${req.method} ${req.originalUrl || req.url}:`, err);
    
    if (res.headersSent) {
      return;
    }

    const statusCode = err.status || err.statusCode || 500;
    const errorMessage = err.message || 'Internal Server Error';

    res.status(statusCode).json({
      success: false,
      error: errorMessage,
      path: req.originalUrl || req.url,
      timestamp: new Date().toISOString()
    });
  });

  return app;
}
