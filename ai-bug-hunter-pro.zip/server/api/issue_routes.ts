import { Router, Response } from 'express';
import { getDb } from '../db/database.ts';
import { authMiddleware, AuthRequest } from '../auth/auth.ts';

export const issueRouter = Router();

// Enforce authentication on all issue/finding endpoints
issueRouter.use(authMiddleware);

// GET /api/issues - strictly isolated to findings belonging to current user
issueRouter.get('/', (req: AuthRequest, res: Response) => {
  try {
    const db = getDb();
    const userId = req.user!.id;
    const {
      severity,
      category,
      scanner,
      status,
      scan_id,
      repository_id,
      search,
      sort_by = 'severity',
      order = 'asc'
    } = req.query;

    let query = `
      SELECT i.*, s.repository_id, r.name as repo_name, s.started_at as scan_date,
        a.id as ai_analysis_id, a.explanation as ai_explanation
      FROM issues i
      JOIN scans s ON i.scan_id = s.id
      JOIN repositories r ON s.repository_id = r.id
      LEFT JOIN ai_analysis a ON i.id = a.issue_id
      WHERE r.user_id = ?
    `;

    const params: any[] = [userId];

    if (scan_id) {
      query += ' AND i.scan_id = ?';
      params.push(scan_id);
    }
    if (repository_id) {
      query += ' AND s.repository_id = ?';
      params.push(repository_id);
    }
    if (severity) {
      query += ' AND i.severity = ?';
      params.push(severity);
    }
    if (category) {
      query += ' AND i.category = ?';
      params.push(category);
    }
    if (scanner) {
      query += ' AND i.scanner = ?';
      params.push(scanner);
    }
    if (status) {
      query += ' AND i.status = ?';
      params.push(status);
    }
    if (search) {
      query += ' AND (i.title LIKE ? OR i.description LIKE ? OR i.file_path LIKE ? OR i.cwe LIKE ?)';
      const term = `%${search}%`;
      params.push(term, term, term, term);
    }

    if (sort_by === 'severity') {
      query += ` ORDER BY
        CASE i.severity
          WHEN 'CRITICAL' THEN 1
          WHEN 'HIGH' THEN 2
          WHEN 'MEDIUM' THEN 3
          WHEN 'LOW' THEN 4
          ELSE 5
        END ${order === 'desc' ? 'DESC' : 'ASC'}, i.created_at DESC`;
    } else if (sort_by === 'date') {
      query += ` ORDER BY i.created_at ${order === 'asc' ? 'ASC' : 'DESC'}`;
    } else if (sort_by === 'file') {
      query += ` ORDER BY i.file_path ${order === 'desc' ? 'DESC' : 'ASC'}, i.line_number ASC`;
    } else {
      query += ' ORDER BY i.created_at DESC';
    }

    const issues = db.prepare(query).all(...params);

    return res.json({
      issues,
      totalCount: issues.length
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// GET /api/issues/:id - strictly returns finding only if owned by user
issueRouter.get('/:id', (req: AuthRequest, res: Response) => {
  try {
    const db = getDb();
    const userId = req.user!.id;

    const issue: any = db.prepare(`
      SELECT i.*, s.repository_id, r.name as repo_name, r.source as repo_source, r.branch as repo_branch,
        a.id as ai_analysis_id, a.explanation as ai_explanation, a.impact as ai_impact,
        a.suggested_fix as ai_fix, a.generated_tests as ai_tests, a.created_at as ai_created_at
      FROM issues i
      JOIN scans s ON i.scan_id = s.id
      JOIN repositories r ON s.repository_id = r.id
      LEFT JOIN ai_analysis a ON i.id = a.issue_id
      WHERE i.id = ? AND r.user_id = ?
    `).get(req.params.id, userId);

    if (!issue) {
      return res.status(404).json({ error: 'Issue finding not found' });
    }

    return res.json({ issue });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// PATCH /api/issues/:id - strictly updates finding only if owned by user
issueRouter.patch('/:id', (req: AuthRequest, res: Response) => {
  try {
    const { status } = req.body;
    if (!['OPEN', 'CONFIRMED', 'RESOLVED', 'FALSE_POSITIVE'].includes(status)) {
      return res.status(400).json({ error: 'Invalid status value. Must be OPEN, CONFIRMED, RESOLVED, or FALSE_POSITIVE.' });
    }

    const db = getDb();
    const userId = req.user!.id;

    const issue: any = db.prepare(`
      SELECT i.id FROM issues i
      JOIN scans s ON i.scan_id = s.id
      JOIN repositories r ON s.repository_id = r.id
      WHERE i.id = ? AND r.user_id = ?
    `).get(req.params.id, userId);

    if (!issue) {
      return res.status(404).json({ error: 'Issue not found' });
    }

    db.prepare('UPDATE issues SET status = ? WHERE id = ?').run(status, req.params.id);

    return res.json({
      message: `Issue marked as ${status}`,
      issueId: req.params.id,
      status
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

