import { Router, Request, Response, NextFunction } from 'express';
import multer from 'multer';
import { randomUUID } from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { getDb, ensureUserInDatabase } from '../db/database.ts';
import { authMiddleware, AuthRequest } from '../auth/auth.ts';
import { ScanService } from '../services/scan_service.ts';
import { discoverFiles, extractZipSafely } from '../scanners/file_extractor.ts';

export function getRepoStorageDir(userId: string, repoId: string): string {
  const dir = path.join(os.tmpdir(), 'nova_hub_repositories', userId, repoId);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  return dir;
}

const uploadStorage = multer.memoryStorage();
const upload = multer({
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB max limit
  storage: uploadStorage
});

// Middleware wrapper that handles single or multi-part uploads with clear error handling
function uploadSingleFileMiddleware(req: Request, res: Response, next: NextFunction) {
  upload.any()(req, res, (err: any) => {
    if (err) {
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(400).json({ error: 'ZIP file exceeds maximum allowed size of 50MB.' });
      }
      return res.status(400).json({ error: `File upload failed: ${err.message}` });
    }

    // Attach primary uploaded file to req.file
    const files = req.files as Express.Multer.File[] | undefined;
    if (files && files.length > 0) {
      req.file = files[0];
    }

    next();
  });
}

export const repoRouter = Router();

// Apply strict authentication to all repository operations
repoRouter.use(authMiddleware);

// GET /api/repositories - strictly returns current user's repositories
repoRouter.get('/', (req: AuthRequest, res: Response) => {
  try {
    const db = getDb();
    const userId = req.user!.id;

    const repos: any[] = db.prepare(`
      SELECT
        r.*,
        (SELECT COUNT(*) FROM scans s WHERE s.repository_id = r.id) as scan_count,
        (SELECT s.security_score FROM scans s WHERE s.repository_id = r.id ORDER BY s.started_at DESC LIMIT 1) as last_security_score,
        (SELECT s.status FROM scans s WHERE s.repository_id = r.id ORDER BY s.started_at DESC LIMIT 1) as last_scan_status,
        (SELECT s.completed_at FROM scans s WHERE s.repository_id = r.id ORDER BY s.started_at DESC LIMIT 1) as last_scan_date,
        (SELECT s.id FROM scans s WHERE s.repository_id = r.id ORDER BY s.started_at DESC LIMIT 1) as last_scan_id,
        (SELECT COUNT(*) FROM issues i JOIN scans s ON i.scan_id = s.id WHERE s.repository_id = r.id AND s.id = (
          SELECT s2.id FROM scans s2 WHERE s2.repository_id = r.id ORDER BY s2.started_at DESC LIMIT 1
        )) as total_issues
      FROM repositories r
      WHERE r.user_id = ?
      ORDER BY r.created_at DESC
    `).all(userId);

    return res.json({ repositories: repos });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// GET /api/repositories/:id - strictly verifies repository belongs to authenticated user
repoRouter.get('/:id', (req: AuthRequest, res: Response) => {
  try {
    const db = getDb();
    const userId = req.user!.id;

    const repo: any = db.prepare('SELECT * FROM repositories WHERE id = ? AND user_id = ?').get(req.params.id, userId);
    if (!repo) {
      return res.status(404).json({ error: 'Repository not found' });
    }

    const scans = db.prepare('SELECT * FROM scans WHERE repository_id = ? ORDER BY started_at DESC').all(repo.id);

    return res.json({
      repository: repo,
      scans: scans.map((s: any) => ({
        ...s,
        scanners_executed: JSON.parse(s.scanners_executed || '[]')
      }))
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// GET /api/repositories/:id/files/content - securely retrieves private source file content for owner only
repoRouter.get('/:id/files/content', (req: AuthRequest, res: Response) => {
  try {
    const db = getDb();
    const userId = req.user!.id;
    const repo: any = db.prepare('SELECT * FROM repositories WHERE id = ? AND user_id = ?').get(req.params.id, userId);
    if (!repo) {
      return res.status(404).json({ error: 'Repository not found' });
    }

    const reqPath = (req.query.path as string) || '';
    if (!reqPath) {
      return res.status(400).json({ error: 'Missing path query parameter.' });
    }

    let repoDir = getRepoStorageDir(userId, repo.id);
    if (!fs.existsSync(repoDir)) {
      repoDir = path.resolve(process.cwd(), 'data', 'repositories', userId, repo.id);
    }
    const safeRelPath = path.normalize(reqPath).replace(/^(\.\.(\/|\\|$))+/, '');
    const fullPath = path.resolve(repoDir, safeRelPath);

    // Path traversal check
    if (!fullPath.startsWith(repoDir + path.sep) && fullPath !== repoDir) {
      return res.status(403).json({ error: 'Access denied: Path traversal detected.' });
    }

    if (!fs.existsSync(fullPath) || !fs.statSync(fullPath).isFile()) {
      return res.status(404).json({ error: 'Source file not found.' });
    }

    const content = fs.readFileSync(fullPath, 'utf8');
    return res.json({ filePath: reqPath, content });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// POST /api/repositories/upload - strictly associates repo and scans with authenticated user
repoRouter.post('/upload', uploadSingleFileMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No ZIP file provided in upload. Please select a valid .zip file.' });
    }

    const filename = req.file.originalname || 'uploaded_source.zip';
    const fileSize = req.file.size || req.file.buffer.length;

    if (fileSize > 50 * 1024 * 1024) {
      return res.status(400).json({ error: 'ZIP file exceeds maximum allowed size of 50MB.' });
    }

    const customName = req.body.name || filename.replace(/\.zip$/i, '');
    const branch = req.body.branch || 'main';
    const userId = req.user!.id;
    ensureUserInDatabase(userId, req.user?.email, req.user?.name);

    const db = getDb();
    const repoId = randomUUID();

    // Create repository entry with authenticated user_id
    db.prepare(`
      INSERT INTO repositories (id, user_id, name, source, url, branch, created_at)
      VALUES (?, ?, ?, 'upload', NULL, ?, ?)
    `).run(repoId, userId, customName, branch, new Date().toISOString());

    // Safely extract ZIP into serverless-compatible temporary sandbox
    const repoDir = getRepoStorageDir(userId, repoId);
    extractZipSafely(req.file.buffer, repoDir);

    // Discover files from the extracted sandbox
    const discoveredFiles = discoverFiles(repoDir);

    // Trigger real static analysis scan pipeline
    const scanResult = await ScanService.executeScan({
      repositoryId: repoId,
      userId,
      commitHash: `${branch}@upload`,
      files: discoveredFiles
    });

    return res.status(201).json({
      repositoryId: repoId,
      scanId: scanResult.scanId,
      score: scanResult.score,
      issuesCount: scanResult.issuesCount,
      status: 'COMPLETED',
      message: 'Repository uploaded and analyzed successfully.'
    });
  } catch (err: any) {
    console.error('[UPLOAD ERROR]', err);
    return res.status(500).json({
      error: err.message || 'Failed to process and analyze uploaded repository archive'
    });
  }
});

// Helper to parse GitHub URL and extract owner, repo, and optional branch
function parseGithubUrl(rawUrl: string, requestedBranch?: string): { owner: string; repo: string; branch: string; cleanUrl: string } | null {
  const trimmed = rawUrl.trim();
  
  // 1. Shorthand "owner/repo" (e.g. "expressjs/express" or "b-nnett/grok-bot-0")
  const shorthandMatch = trimmed.match(/^([a-zA-Z0-9_\-\.]+)\/([a-zA-Z0-9_\-\.]+)$/);
  if (shorthandMatch) {
    const owner = shorthandMatch[1];
    const repo = shorthandMatch[2].replace(/\.git$/i, '');
    return {
      owner,
      repo,
      branch: requestedBranch || 'main',
      cleanUrl: `https://github.com/${owner}/${repo}`
    };
  }

  // 2. Full URL, git SSH URL, or tree branch URL
  const urlMatch = trimmed.match(/(?:https?:\/\/github\.com\/|git@github\.com:)([^\/\s]+)\/([^\/\s#\?]+)(?:\/tree\/([^\/\s#\?]+))?/i);
  if (urlMatch) {
    const owner = urlMatch[1];
    const repo = urlMatch[2].replace(/\.git$/i, '');
    const treeBranch = urlMatch[3];
    return {
      owner,
      repo,
      branch: requestedBranch || treeBranch || 'main',
      cleanUrl: `https://github.com/${owner}/${repo}`
    };
  }

  return null;
}

// POST /api/repositories/github - imports repo for authenticated user with fallback branches and PAT support
repoRouter.post('/github', async (req: AuthRequest, res: Response) => {
  try {
    const { url, branch, name, token: bodyToken, githubToken } = req.body;
    if (!url) {
      return res.status(400).json({ error: 'GitHub repository URL or "owner/repository" identifier is required.' });
    }

    const parsed = parseGithubUrl(url, branch);
    if (!parsed) {
      return res.status(400).json({
        error: 'Invalid GitHub URL. Use format "https://github.com/owner/repository" or shorthand "owner/repository".'
      });
    }

    const { owner, repo } = parsed;
    const targetBranch = branch || parsed.branch || 'main';
    const repoName = name || `${owner}/${repo}`;
    const userId = req.user!.id;
    ensureUserInDatabase(userId, req.user?.email, req.user?.name);

    const token = (bodyToken || githubToken || (req.headers['x-github-token'] as string) || process.env.GITHUB_TOKEN || '').trim();

    const headers: Record<string, string> = {
      'User-Agent': 'AI-Bug-Hunter-Pro-SAST',
      'Accept': 'application/vnd.github+json'
    };
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    // List of candidate archive URLs to attempt in order of likelihood
    const candidateUrls: { url: string; label: string; branchName: string }[] = [];

    // If a specific custom branch was requested and is not 'main', prioritize it
    if (branch && branch !== 'main') {
      candidateUrls.push({
        url: `https://api.github.com/repos/${owner}/${repo}/zipball/${encodeURIComponent(branch)}`,
        label: `branch '${branch}' (API)`,
        branchName: branch
      });
      candidateUrls.push({
        url: `https://github.com/${owner}/${repo}/archive/refs/heads/${encodeURIComponent(branch)}.zip`,
        label: `branch '${branch}' (Direct)`,
        branchName: branch
      });
    }

    // Default branch zipball (GitHub API auto-resolves default branch when no ref is passed)
    candidateUrls.push({
      url: `https://api.github.com/repos/${owner}/${repo}/zipball`,
      label: 'default branch (API)',
      branchName: targetBranch
    });

    // Direct HEAD archive
    candidateUrls.push({
      url: `https://github.com/${owner}/${repo}/archive/HEAD.zip`,
      label: 'HEAD archive (Direct)',
      branchName: targetBranch
    });

    // Standard branch names
    const commonBranches = ['main', 'master', 'trunk', 'develop'];
    for (const b of commonBranches) {
      if (b !== branch) {
        candidateUrls.push({
          url: `https://api.github.com/repos/${owner}/${repo}/zipball/${b}`,
          label: `branch '${b}' (API)`,
          branchName: b
        });
        candidateUrls.push({
          url: `https://github.com/${owner}/${repo}/archive/refs/heads/${b}.zip`,
          label: `branch '${b}' (Direct)`,
          branchName: b
        });
      }
    }

    let zipBuffer: Buffer | null = null;
    let resolvedBranch = targetBranch;
    let lastStatus = 0;
    let lastStatusText = '';

    for (const candidate of candidateUrls) {
      try {
        const fetchHeaders = candidate.url.includes('api.github.com') ? headers : { 'User-Agent': 'AI-Bug-Hunter-Pro-SAST' };
        const response = await fetch(candidate.url, {
          headers: fetchHeaders,
          redirect: 'follow'
        });

        if (response.ok) {
          const arrayBuffer = await response.arrayBuffer();
          if (arrayBuffer.byteLength > 100) {
            zipBuffer = Buffer.from(arrayBuffer);
            resolvedBranch = candidate.branchName;
            break;
          }
        } else {
          lastStatus = response.status;
          lastStatusText = response.statusText;
        }
      } catch (err: any) {
        // Continue to next candidate URL
      }
    }

    if (!zipBuffer) {
      if (lastStatus === 404 || lastStatus === 0) {
        if (!token) {
          return res.status(404).json({
            error: `Repository "${owner}/${repo}" was not found or is private. If this is a private repository, please provide a GitHub Personal Access Token (PAT) with "repo" scope, or upload a ZIP file of the repository.`
          });
        } else {
          return res.status(404).json({
            error: `Repository "${owner}/${repo}" or branch not found with the provided access token. Verify that the repository exists, the token has "repo" read permissions, or upload the repository ZIP file.`
          });
        }
      }

      if (lastStatus === 401 || lastStatus === 403) {
        return res.status(403).json({
          error: `GitHub access denied (${lastStatusText || 'Authentication required'}). If accessing a private repository or hitting GitHub rate limits, please provide a valid GitHub Personal Access Token.`
        });
      }

      return res.status(lastStatus || 500).json({
        error: `Could not download repository archive from GitHub (${lastStatusText || 'Download failed'}). Please check the repository name or upload a ZIP file.`
      });
    }

    const db = getDb();
    const repoId = randomUUID();

    db.prepare(`
      INSERT INTO repositories (id, user_id, name, source, url, branch, created_at)
      VALUES (?, ?, ?, 'github', ?, ?, ?)
    `).run(repoId, userId, repoName, parsed.cleanUrl, resolvedBranch, new Date().toISOString());

    const repoDir = getRepoStorageDir(userId, repoId);
    extractZipSafely(zipBuffer, repoDir);
    const discoveredFiles = discoverFiles(repoDir);

    if (discoveredFiles.length === 0) {
      return res.status(400).json({
        error: 'The downloaded repository archive was empty or contained no scannable source files.'
      });
    }

    const scanResult = await ScanService.executeScan({
      repositoryId: repoId,
      userId,
      commitHash: `${resolvedBranch}@github`,
      files: discoveredFiles
    });

    return res.status(201).json({
      repositoryId: repoId,
      scanId: scanResult.scanId,
      score: scanResult.score,
      issuesCount: scanResult.issuesCount,
      status: 'COMPLETED',
      message: `GitHub repository '${repoName}' (${resolvedBranch}) imported and scanned successfully.`
    });
  } catch (err: any) {
    console.error('[GITHUB ERROR]', err);
    return res.status(500).json({ error: `Failed to import GitHub repository: ${err.message}` });
  }
});

// POST /api/repositories/test-project (One-click scan of bundled vulnerable suite)
repoRouter.post('/test-project', async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    ensureUserInDatabase(userId, req.user?.email, req.user?.name);
    const testProjDir = path.resolve(process.cwd(), 'test-project');

    if (!fs.existsSync(testProjDir)) {
      return res.status(404).json({ error: 'Test project folder not found on server.' });
    }

    const files = discoverFiles(testProjDir);
    if (files.length === 0) {
      return res.status(400).json({ error: 'No source files found in test project.' });
    }

    const db = getDb();
    const repoId = randomUUID();

    db.prepare(`
      INSERT INTO repositories (id, user_id, name, source, url, branch, created_at)
      VALUES (?, ?, 'Vulnerable-Demo-Suite (Security Test Project)', 'test-project', NULL, 'main', ?)
    `).run(repoId, userId, new Date().toISOString());

    // Copy test files into serverless temporary directory
    const repoDir = getRepoStorageDir(userId, repoId);
    for (const f of files) {
      const destPath = path.resolve(repoDir, f.relativePath);
      fs.mkdirSync(path.dirname(destPath), { recursive: true });
      fs.writeFileSync(destPath, f.content);
    }

    const scanResult = await ScanService.executeScan({
      repositoryId: repoId,
      userId,
      commitHash: 'vulnerable-suite@v1.0',
      files
    });

    return res.status(201).json({
      repositoryId: repoId,
      scanId: scanResult.scanId,
      score: scanResult.score,
      issuesCount: scanResult.issuesCount,
      status: 'COMPLETED',
      message: 'Test security project loaded and scanned successfully.'
    });
  } catch (err: any) {
    console.error('[TEST-PROJECT ERROR]', err);
    return res.status(500).json({ error: err.message });
  }
});

// DELETE /api/repositories/:id - strictly deletes only owned repository
repoRouter.delete('/:id', (req: AuthRequest, res: Response) => {
  try {
    const db = getDb();
    const userId = req.user!.id;

    // Verify ownership first
    const existing: any = db.prepare('SELECT id FROM repositories WHERE id = ? AND user_id = ?').get(req.params.id, userId);
    if (!existing) {
      return res.status(404).json({ error: 'Repository not found' });
    }

    db.prepare('DELETE FROM repositories WHERE id = ? AND user_id = ?').run(req.params.id, userId);

    // Clean up stored user files
    const repoDir = path.resolve(process.cwd(), 'data', 'repositories', userId, req.params.id);
    if (fs.existsSync(repoDir)) {
      try {
        fs.rmSync(repoDir, { recursive: true, force: true });
      } catch {
        // Ignored
      }
    }

    return res.json({ message: 'Repository deleted successfully.' });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

