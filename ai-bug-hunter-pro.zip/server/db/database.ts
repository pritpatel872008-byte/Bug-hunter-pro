import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import pg from 'pg';

const { Pool } = pg;

export function isNeonConfigured(): boolean {
  const url = process.env.DATABASE_URL;
  return Boolean(url && (url.startsWith('postgres://') || url.startsWith('postgresql://')));
}

let neonPoolInstance: pg.Pool | null = null;

export function getNeonPool(): pg.Pool {
  if (!neonPoolInstance) {
    const connectionString = process.env.DATABASE_URL;
    if (!connectionString) {
      throw new Error('DATABASE_URL is not configured for Neon PostgreSQL.');
    }
    neonPoolInstance = new Pool({
      connectionString,
      ssl: { rejectUnauthorized: false }
    });
  }
  return neonPoolInstance;
}

export async function neonQuery<T = any>(text: string, params: any[] = []): Promise<pg.QueryResult<T>> {
  const pool = getNeonPool();
  return pool.query<T>(text, params);
}

export async function initNeonDatabase() {
  if (!isNeonConfigured()) return;
  try {
    const pool = getNeonPool();
    await pool.query(`
      CREATE TABLE IF NOT EXISTS users (
        id VARCHAR(255) PRIMARY KEY,
        name VARCHAR(255) DEFAULT '',
        email VARCHAR(255) UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS password_resets (
        id VARCHAR(255) PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        token_hash VARCHAR(255) NOT NULL,
        expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
        used INTEGER DEFAULT 0,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
      CREATE INDEX IF NOT EXISTS idx_password_resets_token_hash ON password_resets(token_hash);
      CREATE INDEX IF NOT EXISTS idx_password_resets_user_id ON password_resets(user_id);
    `);
    console.log('[Neon PostgreSQL] Schema verified and ready.');

    // Sync all existing Neon users to local db for session and foreign key consistency
    try {
      const allNeonUsers = await pool.query('SELECT id, name, email, password_hash, created_at FROM users');
      const db = getDb();
      for (const u of allNeonUsers.rows) {
        db.prepare(`
          INSERT OR REPLACE INTO users (id, name, email, password_hash, created_at)
          VALUES (?, ?, ?, ?, ?)
        `).run(
          u.id,
          u.name || u.email.split('@')[0],
          u.email,
          u.password_hash,
          u.created_at ? new Date(u.created_at).toISOString() : new Date().toISOString()
        );
      }
    } catch (syncErr: any) {
      console.warn('[Neon Sync] Warning syncing existing Neon users:', syncErr.message);
    }
  } catch (err: any) {
    console.error('[Neon PostgreSQL] Initialization error:', err.message);
  }
}

function resolveDatabasePath(): string {
  const envUrl = process.env.DATABASE_URL;
  if (envUrl && envUrl.trim()) {
    // If DATABASE_URL is a PostgreSQL connection string, use local bughunter.db for SQLite
    if (envUrl.startsWith('postgres://') || envUrl.startsWith('postgresql://')) {
      return path.resolve(process.cwd(), 'bughunter.db');
    }

    const cleanPath = envUrl
      .trim()
      .replace(/^sqlite:\/\/\/?/, '')
      .replace(/^sqlite:\/\//, '')
      .replace(/^sqlite:/, '');

    if (cleanPath) {
      return path.resolve(process.cwd(), cleanPath);
    }
  }

  // Default: bughunter.db in project root
  return path.resolve(process.cwd(), 'bughunter.db');
}

const DB_PATH = resolveDatabasePath();

// Ensure parent directory exists
const dbDir = path.dirname(DB_PATH);
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

let dbInstance: DatabaseSync | null = null;

export function getDb(): DatabaseSync {
  if (!dbInstance) {
    dbInstance = new DatabaseSync(DB_PATH);
    initDatabase(dbInstance);
  }
  return dbInstance;
}

// Ensure a user record exists in the local database for foreign key and indexing compatibility
export function ensureUserInDatabase(userId: string, email?: string, name?: string): void {
  if (!userId) return;
  try {
    const db = getDb();
    const existingById = db.prepare('SELECT id FROM users WHERE id = ?').get(userId);
    if (existingById) return;

    const safeEmail = (email && email.trim()) ? email.toLowerCase().trim() : `user-${userId.slice(0, 8)}@bughunter.local`;
    const safeName = (name && name.trim()) ? name.trim() : safeEmail.split('@')[0];
    const passwordHash = '$2a$10$wK8rP7Q1j6/z9h5q3X4y6u0/VwZfWfE6hM8lqJk5g7y6t8r9o0p1q';
    const createdAt = new Date().toISOString();

    const existingByEmail: any = db.prepare('SELECT id FROM users WHERE LOWER(email) = LOWER(?)').get(safeEmail);
    if (existingByEmail) {
      try {
        db.prepare('UPDATE users SET id = ? WHERE id = ?').run(userId, existingByEmail.id);
        return;
      } catch {
        // Fallback to inserting with unique identifier
      }
    }

    db.prepare(`
      INSERT OR REPLACE INTO users (id, name, email, password_hash, created_at)
      VALUES (?, ?, ?, ?, ?)
    `).run(userId, safeName, safeEmail, passwordHash, createdAt);
  } catch (err: any) {
    console.warn('[ensureUserInDatabase warning]:', err.message);
  }
}

// Initialize WAL mode and schema automatically
export function initDatabase(db: DatabaseSync = getDb()) {
  try {
    db.exec('PRAGMA journal_mode = WAL;');
    db.exec('PRAGMA foreign_keys = ON;');

    // Safe column migrations
    try {
      db.exec('ALTER TABLE scans ADD COLUMN user_id TEXT;');
    } catch {
      // Column may already exist
    }

    // Check if repositories or scans have legacy FOREIGN KEY (user_id) REFERENCES users(id)
    // which breaks when users are authenticated via Neon PostgreSQL.
    try {
      const repoSqlRow: any = db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='repositories'").get();
      if (repoSqlRow?.sql && repoSqlRow.sql.includes('REFERENCES users')) {
        db.exec('PRAGMA foreign_keys = OFF;');
        db.exec(`
          CREATE TABLE IF NOT EXISTS repositories_v2 (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            name TEXT NOT NULL,
            source TEXT NOT NULL,
            url TEXT,
            branch TEXT DEFAULT 'main',
            created_at TEXT NOT NULL
          );
          INSERT OR IGNORE INTO repositories_v2 SELECT id, user_id, name, source, url, branch, created_at FROM repositories;
          DROP TABLE repositories;
          ALTER TABLE repositories_v2 RENAME TO repositories;
          CREATE INDEX IF NOT EXISTS idx_repositories_user_id ON repositories(user_id);
        `);
        db.exec('PRAGMA foreign_keys = ON;');
      }
    } catch (migErr: any) {
      console.warn('[Repo Migration Warning]:', migErr.message);
    }

    try {
      const scanSqlRow: any = db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='scans'").get();
      if (scanSqlRow?.sql && scanSqlRow.sql.includes('REFERENCES users')) {
        db.exec('PRAGMA foreign_keys = OFF;');
        db.exec(`
          CREATE TABLE IF NOT EXISTS scans_v2 (
            id TEXT PRIMARY KEY,
            repository_id TEXT NOT NULL,
            user_id TEXT,
            commit_hash TEXT,
            status TEXT NOT NULL,
            security_score INTEGER DEFAULT 100,
            files_scanned INTEGER DEFAULT 0,
            lines_scanned INTEGER DEFAULT 0,
            scanners_executed TEXT DEFAULT '[]',
            started_at TEXT NOT NULL,
            completed_at TEXT,
            duration REAL,
            error_message TEXT,
            is_demo INTEGER DEFAULT 0,
            FOREIGN KEY (repository_id) REFERENCES repositories(id) ON DELETE CASCADE
          );
          INSERT OR IGNORE INTO scans_v2 SELECT id, repository_id, user_id, commit_hash, status, security_score, files_scanned, lines_scanned, scanners_executed, started_at, completed_at, duration, error_message, is_demo FROM scans;
          DROP TABLE scans;
          ALTER TABLE scans_v2 RENAME TO scans;
          CREATE INDEX IF NOT EXISTS idx_scans_repository_id ON scans(repository_id);
          CREATE INDEX IF NOT EXISTS idx_scans_user_id ON scans(user_id);
        `);
        db.exec('PRAGMA foreign_keys = ON;');
      }
    } catch (scanMigErr: any) {
      console.warn('[Scan Migration Warning]:', scanMigErr.message);
    }

    db.exec(`
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS repositories (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        name TEXT NOT NULL,
        source TEXT NOT NULL, -- 'upload', 'github', 'demo', 'test-project'
        url TEXT,
        branch TEXT DEFAULT 'main',
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS scans (
        id TEXT PRIMARY KEY,
        repository_id TEXT NOT NULL,
        user_id TEXT, -- direct ownership link for fast query indexing
        commit_hash TEXT,
        status TEXT NOT NULL, -- 'QUEUED', 'RUNNING', 'COMPLETED', 'FAILED', 'CANCELLED'
        security_score INTEGER DEFAULT 100,
        files_scanned INTEGER DEFAULT 0,
        lines_scanned INTEGER DEFAULT 0,
        scanners_executed TEXT DEFAULT '[]', -- JSON array of scanner names & status
        started_at TEXT NOT NULL,
        completed_at TEXT,
        duration REAL, -- in seconds
        error_message TEXT,
        is_demo INTEGER DEFAULT 0,
        FOREIGN KEY (repository_id) REFERENCES repositories(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS issues (
        id TEXT PRIMARY KEY,
        scan_id TEXT NOT NULL,
        severity TEXT NOT NULL, -- 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO'
        confidence TEXT NOT NULL, -- 'HIGH', 'MEDIUM', 'LOW'
        category TEXT NOT NULL, -- 'Injection', 'Authentication', 'Secrets', 'Cryptography', 'Dependencies', 'Code Quality'
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        file_path TEXT NOT NULL,
        line_number INTEGER NOT NULL,
        code_snippet TEXT NOT NULL,
        scanner TEXT NOT NULL, -- 'Semgrep', 'Bandit', 'ESLint', 'Gitleaks', 'DependencyCheck'
        cwe TEXT,
        recommendation TEXT NOT NULL,
        status TEXT DEFAULT 'OPEN', -- 'OPEN', 'CONFIRMED', 'RESOLVED', 'FALSE_POSITIVE'
        created_at TEXT NOT NULL,
        FOREIGN KEY (scan_id) REFERENCES scans(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS ai_analysis (
        id TEXT PRIMARY KEY,
        issue_id TEXT UNIQUE NOT NULL,
        explanation TEXT NOT NULL,
        impact TEXT NOT NULL,
        suggested_fix TEXT NOT NULL,
        generated_tests TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (issue_id) REFERENCES issues(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS dependencies (
        id TEXT PRIMARY KEY,
        scan_id TEXT NOT NULL,
        package_name TEXT NOT NULL,
        version TEXT NOT NULL,
        severity TEXT NOT NULL,
        vulnerability TEXT NOT NULL,
        FOREIGN KEY (scan_id) REFERENCES scans(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS scan_logs (
        id TEXT PRIMARY KEY,
        scan_id TEXT NOT NULL,
        message TEXT NOT NULL,
        level TEXT DEFAULT 'INFO',
        timestamp TEXT NOT NULL,
        FOREIGN KEY (scan_id) REFERENCES scans(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS password_resets (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        token_hash TEXT NOT NULL,
        expires_at TEXT NOT NULL,
        used INTEGER DEFAULT 0,
        created_at TEXT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );

      -- Fast indexes for multi-tenant query isolation
      CREATE INDEX IF NOT EXISTS idx_repositories_user_id ON repositories(user_id);
      CREATE INDEX IF NOT EXISTS idx_scans_repository_id ON scans(repository_id);
      CREATE INDEX IF NOT EXISTS idx_scans_user_id ON scans(user_id);
      CREATE INDEX IF NOT EXISTS idx_issues_scan_id ON issues(scan_id);
      CREATE INDEX IF NOT EXISTS idx_ai_analysis_issue_id ON ai_analysis(issue_id);
      CREATE INDEX IF NOT EXISTS idx_dependencies_scan_id ON dependencies(scan_id);
      CREATE INDEX IF NOT EXISTS idx_scan_logs_scan_id ON scan_logs(scan_id);
      CREATE INDEX IF NOT EXISTS idx_password_resets_token_hash ON password_resets(token_hash);
      CREATE INDEX IF NOT EXISTS idx_password_resets_user_id ON password_resets(user_id);
    `);
  } catch (err) {
    console.error('Error during database initialization:', err);
    throw err;
  }
}

// Ensure database is initialized at startup
getDb();
if (isNeonConfigured()) {
  initNeonDatabase().catch((e) => console.error('Failed to init Neon:', e.message));
}
