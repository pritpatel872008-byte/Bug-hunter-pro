import { randomUUID } from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { getDb, ensureUserInDatabase } from '../db/database.ts';
import { DiscoveredFile } from '../scanners/types.ts';
import { discoverFiles, extractZipSafely } from '../scanners/file_extractor.ts';
import { runCompleteScanPipeline } from '../scanners/orchestrator.ts';
import { calculateSecurityScore, compareScans } from './scoring.ts';

export interface CreateScanParams {
  repositoryId: string;
  userId?: string;
  commitHash?: string;
  files?: DiscoveredFile[];
  zipBuffer?: Buffer;
  isDemo?: boolean;
}

export class ScanService {
  /**
   * Initializes and executes a full end-to-end security scan synchronously or asynchronously
   */
  public static async executeScan(params: CreateScanParams): Promise<{ scanId: string; score: number; issuesCount: number }> {
    const db = getDb();
    const scanId = randomUUID();
    const startTime = Date.now();
    const startedAt = new Date().toISOString();

    // Look up repository owner user_id if not provided explicitly
    let ownerUserId = params.userId;
    if (!ownerUserId) {
      const repoRow: any = db.prepare('SELECT user_id FROM repositories WHERE id = ?').get(params.repositoryId);
      ownerUserId = repoRow?.user_id || undefined;
    }
    if (ownerUserId) {
      ensureUserInDatabase(ownerUserId);
    }

    // Create scan entry with strict user ownership
    const insertScan = db.prepare(`
      INSERT INTO scans (id, repository_id, user_id, commit_hash, status, security_score, files_scanned, lines_scanned, scanners_executed, started_at, is_demo)
      VALUES (?, ?, ?, ?, 'RUNNING', 100, 0, 0, '[]', ?, ?)
    `);
    insertScan.run(
      scanId,
      params.repositoryId,
      ownerUserId || null,
      params.commitHash || 'main@' + scanId.slice(0, 7),
      startedAt,
      params.isDemo ? 1 : 0
    );

    const logStmt = db.prepare('INSERT INTO scan_logs (id, scan_id, message, level, timestamp) VALUES (?, ?, ?, ?, ?)');
    const log = (msg: string, lvl = 'INFO') => {
      logStmt.run(randomUUID(), scanId, msg, lvl, new Date().toISOString());
    };

    let tempDir: string | null = null;

    try {
      log('Scan initialized. Starting workspace preparation...');

      let discoveredFiles: DiscoveredFile[] = [];

      if (params.zipBuffer) {
        tempDir = path.resolve(process.cwd(), 'data', 'temp_scans', ownerUserId || 'sandbox', scanId);
        log(`Extracting uploaded archive safely to isolated sandbox...`);
        extractZipSafely(params.zipBuffer, tempDir);
        discoveredFiles = discoverFiles(tempDir);
      } else if (params.files && params.files.length > 0) {
        discoveredFiles = params.files;
      } else {
        throw new Error('No files or zip payload provided for scanning.');
      }

      if (discoveredFiles.length === 0) {
        throw new Error('Repository contains no scannable text or source files.');
      }

      log(`Workspace verified. Running multi-scanner detection engines...`);

      // Run pipeline
      const pipelineResult = await runCompleteScanPipeline(discoveredFiles, log);

      // Calculate score
      const scoreBreakdown = calculateSecurityScore(pipelineResult.findings);
      log(`Calculated deterministic security score: ${scoreBreakdown.score}/100 (Grade: ${scoreBreakdown.grade})`);

      // Persist findings in a single transaction
      const insertIssue = db.prepare(`
        INSERT INTO issues (id, scan_id, severity, confidence, category, title, description, file_path, line_number, code_snippet, scanner, cwe, recommendation, status, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'OPEN', ?)
      `);

      for (const finding of pipelineResult.findings) {
        insertIssue.run(
          randomUUID(),
          scanId,
          finding.severity,
          finding.confidence,
          finding.category,
          finding.title,
          finding.description,
          finding.file_path,
          finding.line_number,
          finding.code_snippet,
          finding.scanner,
          finding.cwe || 'CWE-Other',
          finding.recommendation,
          new Date().toISOString()
        );
      }

      // Persist dependencies
      const insertDep = db.prepare(`
        INSERT INTO dependencies (id, scan_id, package_name, version, severity, vulnerability)
        VALUES (?, ?, ?, ?, ?, ?)
      `);

      for (const dep of pipelineResult.dependencies) {
        insertDep.run(randomUUID(), scanId, dep.package_name, dep.version, dep.severity, dep.vulnerability);
      }

      const durationSec = Math.round((Date.now() - startTime) / 10) / 100;
      const completedAt = new Date().toISOString();

      // Update scan to COMPLETED
      const updateScan = db.prepare(`
        UPDATE scans
        SET status = 'COMPLETED',
            security_score = ?,
            files_scanned = ?,
            lines_scanned = ?,
            scanners_executed = ?,
            completed_at = ?,
            duration = ?
        WHERE id = ?
      `);

      updateScan.run(
        scoreBreakdown.score,
        pipelineResult.filesScanned,
        pipelineResult.linesScanned,
        JSON.stringify(pipelineResult.scannersExecuted),
        completedAt,
        durationSec,
        scanId
      );

      log(`Scan completed successfully in ${durationSec}s. Found ${pipelineResult.findings.length} issues.`);

      return {
        scanId,
        score: scoreBreakdown.score,
        issuesCount: pipelineResult.findings.length
      };
    } catch (err: any) {
      log(`Fatal scan error: ${err.message}`, 'ERROR');
      const updateFailed = db.prepare(`
        UPDATE scans
        SET status = 'FAILED',
            error_message = ?,
            completed_at = ?,
            duration = ?
        WHERE id = ?
      `);
      updateFailed.run(err.message, new Date().toISOString(), Math.round((Date.now() - startTime) / 10) / 100, scanId);
      throw err;
    } finally {
      // Clean up temporary workspace safely
      if (tempDir && fs.existsSync(tempDir)) {
        try {
          fs.rmSync(tempDir, { recursive: true, force: true });
        } catch {
          // Ignored
        }
      }
    }
  }

  /**
   * Retrieves full scan details with issues, dependencies, logs, and comparison against prior scan,
   * strictly enforcing that the scan belongs to the authorized user.
   */
  public static getScanDetails(scanId: string, userId?: string) {
    const db = getDb();
    
    let query = `
      SELECT s.*, r.name as repo_name, r.source as repo_source, r.url as repo_url, r.branch as repo_branch
      FROM scans s
      JOIN repositories r ON s.repository_id = r.id
      WHERE s.id = ?
    `;
    const params: any[] = [scanId];

    if (userId) {
      query += ' AND r.user_id = ?';
      params.push(userId);
    }

    const scanStmt = db.prepare(query);
    const scan: any = scanStmt.get(...params);

    if (!scan) return null;

    const issuesStmt = db.prepare(`
      SELECT i.*, a.explanation as ai_explanation, a.impact as ai_impact, a.suggested_fix as ai_fix, a.generated_tests as ai_tests
      FROM issues i
      LEFT JOIN ai_analysis a ON i.id = a.issue_id
      WHERE i.scan_id = ?
      ORDER BY
        CASE i.severity
          WHEN 'CRITICAL' THEN 1
          WHEN 'HIGH' THEN 2
          WHEN 'MEDIUM' THEN 3
          WHEN 'LOW' THEN 4
          ELSE 5
        END ASC, i.created_at DESC
    `);
    const issues = issuesStmt.all(scanId);

    const depsStmt = db.prepare('SELECT * FROM dependencies WHERE scan_id = ?');
    const dependencies = depsStmt.all(scanId);

    const logsStmt = db.prepare('SELECT * FROM scan_logs WHERE scan_id = ? ORDER BY timestamp ASC');
    const logs = logsStmt.all(scanId);

    // Look for previous scan of same repo to calculate diff
    const prevScanStmt = db.prepare(`
      SELECT * FROM scans
      WHERE repository_id = ? AND status = 'COMPLETED' AND started_at < ?
      ORDER BY started_at DESC
      LIMIT 1
    `);
    const prevScan: any = prevScanStmt.get(scan.repository_id, scan.started_at);

    let comparison = null;
    if (prevScan) {
      const prevIssues = db.prepare('SELECT * FROM issues WHERE scan_id = ?').all(prevScan.id);
      comparison = compareScans(prevIssues, issues, prevScan.security_score, scan.security_score);
    }

    return {
      ...scan,
      scanners_executed: JSON.parse(scan.scanners_executed || '[]'),
      issues,
      dependencies,
      logs,
      comparison
    };
  }
}

