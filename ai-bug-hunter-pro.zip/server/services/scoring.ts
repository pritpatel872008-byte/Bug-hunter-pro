import { RawFinding } from '../scanners/types.ts';

export interface ScoreBreakdown {
  score: number; // 0 - 100
  grade: 'A+' | 'A' | 'B' | 'C' | 'D' | 'F';
  criticalCount: number;
  highCount: number;
  mediumCount: number;
  lowCount: number;
  infoCount: number;
  totalIssues: number;
  secretsExposed: number;
}

export interface ScanComparison {
  scoreDelta: number;
  previousScore: number;
  currentScore: number;
  newIssuesCount: number;
  fixedIssuesCount: number;
  unresolvedCount: number;
  newIssues: any[];
  fixedIssues: any[];
}

/**
 * Calculates a deterministic security score from 0 to 100.
 * Deductions:
 * - Critical: 25 points each (max penalty 75)
 * - High: 15 points each (max penalty 45)
 * - Medium: 7 points each (max penalty 30)
 * - Low: 2 points each (max penalty 15)
 * - Info: 0.5 points each (max penalty 5)
 * - Exposed Secrets multiplier: additional 10 points deduction per verified secret
 */
export function calculateSecurityScore(findings: RawFinding[]): ScoreBreakdown {
  let critical = 0;
  let high = 0;
  let medium = 0;
  let low = 0;
  let info = 0;
  let secrets = 0;

  for (const f of findings) {
    if (f.category === 'Secrets') {
      secrets += 1;
    }

    switch (f.severity) {
      case 'CRITICAL':
        critical++;
        break;
      case 'HIGH':
        high++;
        break;
      case 'MEDIUM':
        medium++;
        break;
      case 'LOW':
        low++;
        break;
      case 'INFO':
        info++;
        break;
    }
  }

  if (findings.length === 0) {
    return {
      score: 100,
      grade: 'A+',
      criticalCount: 0,
      highCount: 0,
      mediumCount: 0,
      lowCount: 0,
      infoCount: 0,
      totalIssues: 0,
      secretsExposed: 0
    };
  }

  // Weight deductions with caps to ensure balanced degradation
  const criticalDeduction = Math.min(75, critical * 25);
  const highDeduction = Math.min(45, high * 15);
  const mediumDeduction = Math.min(30, medium * 7);
  const lowDeduction = Math.min(15, low * 2);
  const infoDeduction = Math.min(5, info * 0.5);
  const secretDeduction = Math.min(40, secrets * 10);

  const totalDeduction = criticalDeduction + highDeduction + mediumDeduction + lowDeduction + infoDeduction + secretDeduction;
  const score = Math.max(0, Math.min(100, Math.round(100 - totalDeduction)));

  let grade: ScoreBreakdown['grade'] = 'F';
  if (score >= 95) grade = 'A+';
  else if (score >= 85) grade = 'A';
  else if (score >= 70) grade = 'B';
  else if (score >= 50) grade = 'C';
  else if (score >= 30) grade = 'D';
  else grade = 'F';

  return {
    score,
    grade,
    criticalCount: critical,
    highCount: high,
    mediumCount: medium,
    lowCount: low,
    infoCount: info,
    totalIssues: findings.length,
    secretsExposed: secrets
  };
}

/**
 * Compares two consecutive scans for the same repository to track resolution progress.
 */
export function compareScans(previousIssues: any[], currentIssues: any[], prevScore: number, currScore: number): ScanComparison {
  const prevMap = new Map<string, any>();
  for (const issue of previousIssues) {
    const key = `${issue.file_path}:${issue.title}:${issue.line_number}`;
    prevMap.set(key, issue);
  }

  const currMap = new Map<string, any>();
  const newIssues: any[] = [];

  for (const issue of currentIssues) {
    const key = `${issue.file_path}:${issue.title}:${issue.line_number}`;
    currMap.set(key, issue);
    if (!prevMap.has(key)) {
      newIssues.push(issue);
    }
  }

  const fixedIssues: any[] = [];
  for (const [key, issue] of prevMap.entries()) {
    if (!currMap.has(key)) {
      fixedIssues.push(issue);
    }
  }

  return {
    scoreDelta: currScore - prevScore,
    previousScore: prevScore,
    currentScore: currScore,
    newIssuesCount: newIssues.length,
    fixedIssuesCount: fixedIssues.length,
    unresolvedCount: currentIssues.length,
    newIssues,
    fixedIssues
  };
}
