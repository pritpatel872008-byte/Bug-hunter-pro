import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createServerApp } from './server/api/server_app.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = createServerApp();
const PORT = process.env.PORT || 3000;

// Serve static frontend assets from dist in production
const distPath = path.resolve(__dirname, 'dist');
app.use(express.static(distPath));

// Fallback to index.html for SPA client-side routing
app.get('*', (_req, res) => {
  res.sendFile(path.join(distPath, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`AI Bug Hunter Pro server running on http://0.0.0.0:${PORT}`);
});
