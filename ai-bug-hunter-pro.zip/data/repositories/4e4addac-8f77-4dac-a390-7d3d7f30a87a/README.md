# Security Vulnerability Test Suite (FOR SECURITY TESTING ONLY)

⚠️ **WARNING: INTENTIONALLY VULNERABLE CODE - FOR SECURITY TESTING ONLY** ⚠️

This sample project contains deliberately crafted security flaws and bad coding practices designed to validate and benchmark static analysis (SAST) engines, secret scanners, and AI vulnerability remediation in AI Bug Hunter Pro.

### Included Vulnerabilities:
1. **SQL Injection (SQLi):** Direct string formatting in database queries (`app.py`, `api_handlers.ts`).
2. **Command Injection:** Unsanitized parameters passed to `os.system()` and `subprocess.Popen(shell=True)`.
3. **Hardcoded Secrets & API Keys:** Live AWS access keys, GitHub PAT, JWT secret strings, and Stripe API keys (`app.py`, `auth_service.js`, `api_handlers.ts`).
4. **Weak Cryptography:** MD5 hashing for passwords and `Math.random()` for security tokens.
5. **Insecure Deserialization:** Remote code execution risk via Python `pickle.loads()`.
6. **Cross-Site Scripting (DOM XSS):** Direct unescaped user input passed to `innerHTML`.
7. **Path Traversal:** File reads from user-supplied file path parameters without directory validation.
8. **Server-Side Request Forgery (SSRF):** Outgoing HTTP requests to unvalidated user-controlled endpoints.
9. **Known Vulnerable Dependencies:** Outdated packages in `package.json` and `requirements.txt`.
