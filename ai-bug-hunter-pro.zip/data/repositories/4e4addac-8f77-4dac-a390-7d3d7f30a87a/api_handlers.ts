// FOR SECURITY TESTING ONLY - INTENTIONALLY VULNERABLE
import fs from 'fs';
import axios from 'axios';
import { Request, Response } from 'express';

// VULNERABILITY 1: Hardcoded Stripe Live Secret Key
export const STRIPE_API_KEY = "sk_live_51NyTestSecretKey9876543210ABCDEF";

// VULNERABILITY 2: Path Traversal (Arbitrary File Read)
export function handleDownloadReport(req: Request, res: Response) {
  const fileName = req.query.file as string;
  // Path traversal: directly accessing dynamic file path from user query
  const fileContent = fs.readFileSync("/var/data/reports/" + fileName, "utf8");
  res.send(fileContent);
}

// VULNERABILITY 3: Server-Side Request Forgery (SSRF)
export async function handleWebhookProxy(req: Request, res: Response) {
  const targetUrl = req.body.url;
  // SSRF: Fetching untrusted URL directly without hostname validation or loopback filtering
  const response = await axios.get(targetUrl);
  res.json(response.data);
}

// VULNERABILITY 4: SQL Injection in TypeScript handler
export async function queryUserRecords(dbClient: any, roleFilter: string) {
  // Direct SQL query concatenation
  const query = `SELECT id, email, role FROM members WHERE role = '${roleFilter}'`;
  return await dbClient.query(query);
}
