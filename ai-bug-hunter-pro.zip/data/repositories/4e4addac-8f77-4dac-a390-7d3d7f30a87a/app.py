# FOR SECURITY TESTING ONLY - INTENTIONALLY VULNERABLE
import os
import subprocess
import pickle
import hashlib
import sqlite3
from flask import Flask, request, jsonify

app = Flask(__name__)

# VULNERABILITY 1: Hardcoded AWS Credentials
AWS_ACCESS_KEY_ID = "AKIAIOSFODNN7EXAMPLE"
AWS_SECRET_ACCESS_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"

# VULNERABILITY 2: SQL Injection via f-string
@app.route('/users/search', methods=['GET'])
def search_user():
    username = request.args.get('username', '')
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    # SQLi flaw: direct string formatting
    query = f"SELECT * FROM users WHERE username = '{username}'"
    cursor.execute(query)
    results = cursor.fetchall()
    return jsonify(results)

# VULNERABILITY 3: Command Injection via os.system and subprocess
@app.route('/network/ping', methods=['POST'])
def ping_host():
    host = request.json.get('host', '127.0.0.1')
    # Command injection flaw
    os.system("ping -c 1 " + host)
    # Secondary subprocess shell=True flaw
    subprocess.Popen(f"traceroute {host}", shell=True)
    return jsonify({"status": "pinged"})

# VULNERABILITY 4: Insecure Deserialization via pickle
@app.route('/session/load', methods=['POST'])
def load_session():
    data = request.data
    # Insecure deserialization can execute arbitrary code
    user_session = pickle.loads(data)
    return jsonify({"session": str(user_session)})

# VULNERABILITY 5: Weak Hashing Algorithm (MD5) for Passwords
def hash_password(password: str) -> str:
    # MD5 has collision attacks and is broken for passwords
    return hashlib.md5(password.encode()).hexdigest()

# VULNERABILITY 6: Dynamic code execution via eval
@app.route('/calculate', methods=['GET'])
def calculate_expression():
    expr = request.args.get('expr', '0')
    # eval() flaw
    result = eval(expr)
    return jsonify({"result": result})

if __name__ == '__main__':
    # VULNERABILITY 7: Bind to all interfaces (0.0.0.0) and debug mode enabled
    app.run(host='0.0.0.0', port=5000, debug=True)
