// FOR SECURITY TESTING ONLY - INTENTIONALLY VULNERABLE
const jwt = require('jsonwebtoken');

// VULNERABILITY 1: Hardcoded JWT Secret Key
const JWT_SECRET = "super_secret_jwt_key_12345";

function generateSessionToken(userId, role) {
  // Signs with hardcoded secret
  return jwt.sign({ userId, role }, JWT_SECRET, { expiresIn: '1h' });
}

// VULNERABILITY 2: Cryptographically weak random token generation
function generatePasswordResetToken() {
  // Math.random() is predictable and unsafe for security tokens
  const token = Math.floor(Math.random() * 1000000000).toString();
  return token;
}

// VULNERABILITY 3: DOM XSS via innerHTML injection
function renderUserProfile(containerElement, userDisplayName) {
  // Direct innerHTML assignment of untrusted user input
  containerElement.innerHTML = "<h2>Welcome, " + userDisplayName + "</h2>";
}

// VULNERABILITY 4: Dynamic Code Execution with eval()
function parseUserDataExpression(expressionString) {
  // eval execution
  return eval("(" + expressionString + ")");
}

// VULNERABILITY 5: Loose equality on authentication check
function verifyAdminAccess(providedToken, secretToken) {
  // Loose equality (==) can lead to type coercion bypasses
  if (providedToken == secretToken) {
    return true;
  }
  return false;
}

module.exports = {
  generateSessionToken,
  generatePasswordResetToken,
  renderUserProfile,
  parseUserDataExpression,
  verifyAdminAccess
};
